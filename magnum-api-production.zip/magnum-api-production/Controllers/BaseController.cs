﻿using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace EXLETAPI.Controllers
{
    [ApiController]
    public abstract class BaseController : ControllerBase
    {
        private ILog _logger;
        protected ILog Logger => _logger ??= HttpContext?.RequestServices.GetService<ILog>();
    }
}

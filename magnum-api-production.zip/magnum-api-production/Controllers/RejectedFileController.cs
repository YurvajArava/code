﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{

    [ApiController]
    public class RejectedFileController : ControllerBase
    {
        private readonly IRejectedFiles objReject;
        private ILog logger;
        public RejectedFileController(IRejectedFiles _objReject, ILog logger)
        {
            objReject = _objReject;
            this.logger = logger;
        }
        /// <summary>
        /// Electricity Workflow Get record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetRejecteddata")]
        public ActionResult<RejectedFiles> GetRejecteddata(RejectedFileSearch model)
        {
            try
            {

                logger.Information("Rejected Files DATA GetRejecteddata");
                return StatusCode((int)HttpStatusCode.OK, objReject.GetRejectedData(model));

            }
            catch (Exception ex)
            {
                logger.Error("Rejected Files DATA GetRejecteddata- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }



    }
}

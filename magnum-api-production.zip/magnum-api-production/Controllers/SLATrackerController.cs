﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EXLETAPI.Controllers
{
    // [Route("api/[controller]")]
    //[ApiController]
    public class SLATrackerController : BaseController
    {

        private ISLATracker sLATracker;

        public SLATrackerController(ISLATracker _sLATracker)
        {
            sLATracker = _sLATracker;
        }

        [HttpPost]
        [Route("api/{controller}/GetSLARecords")]
        public ActionResult<SLATracker> GetSLARecords(SLASearch objInput)
        {
            try
            {
                Logger.Information("SLA Tracker GetSLARecords");
                return StatusCode((int)HttpStatusCode.OK, sLATracker.SearchSLARecords(objInput));
            }
            catch (Exception ex)
            {
                Logger.Error("SLA Tracker GetSLARecords- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPut]
        [Route("api/{controller}/UpdateData/{json?}")]
        public IActionResult UpdateData(object json, int iUserId)
        {
            try
            {
                Logger.Information("SLATracker -UpdateData");
                string jsondata = json.ToString();
                //List<FollowUp> dt = JsonConvert.DeserializeObject<List<FollowUp>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, sLATracker.SLATrackerUpdateETData(jsondata, iUserId));
            }
            catch (Exception ex)
            {
                Logger.Error("SLATracker -UpdateData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
    }
}

﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{

    public class GSOPCController : BaseController
    {
        private readonly IGSOPC _gSopC;
        public GSOPCController(IGSOPC gSOPC)
        {
            _gSopC = gSOPC;
        }

        [HttpPost]
        [Route("api/{controller}/GetCCompensationData")]
        public ActionResult GetCCompensationData(GsopCSearchModel objInput)
        {
            try
            {
                Logger.Information("CCompensation GetCCompensationData");
                return StatusCode((int)HttpStatusCode.OK, _gSopC.GetGsopCData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("CCompensation  GetCCompensationData Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
    }
}

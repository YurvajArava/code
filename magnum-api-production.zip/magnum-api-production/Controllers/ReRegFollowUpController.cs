﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{

    [ApiController]
    public class ReRegFollowUpController : BaseController
    {
        private readonly IReRegFollowUp objReReg;
        public ReRegFollowUpController(IReRegFollowUp _objReReg)
        {
            objReReg = _objReReg;
        }

        [HttpPost]
        [Route("api/{controller}/GetReRegFollowUpData")]
        public ActionResult<ReRegFollowUp> GetReRegFollowUpData(ReRegSearch objInput)
        {
            try
            {

                Logger.Information("Get records for ReRegFollowUp GetReRegFollowUpData");
                return StatusCode((int)HttpStatusCode.OK, objReReg.GetReRegFollowUpData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("Get records for ReRegFollowUp GetReRegFollowUpData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/UpdateReRegFollowUpData/{json?}")]
        public IActionResult UpdateReRegFollowUpData(object json, int userid)
        {
            try
            {
                Logger.Information("ReReg follow up update  -UpdateReRegFollowUpData");
                string jsondata = json.ToString();
                List<ReRegFollowUpUpdate> dt = JsonConvert.DeserializeObject<List<ReRegFollowUpUpdate>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objReReg.UpdateReRegFollowUpData(dt, userid));
            }
            catch (Exception ex)
            {
                Logger.Error("ReReg follow up update   -UpdateReRegFollowUpData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/GetReRegFollowUp")]
        public ActionResult<ReRegFollowUp> GetReRegFollowUp(ReRegSearch objInput)
        {
            try
            {
                Logger.Information("ReRegistration-Search stagging Records");


                return StatusCode((int)HttpStatusCode.OK, objReReg.GetReRegFollowUpData(objInput));
            }
            catch (Exception ex)
            {
                ex.ToString();
                Logger.Information("ReRegistration Search followUp records- Error" + ex.ToString());
                return null;
            }

        }


    }
}

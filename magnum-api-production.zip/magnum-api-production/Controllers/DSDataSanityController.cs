﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class DSDataSanityController : BaseController
    {

        private IDSDataSanity _dSDataSanity;
        public DSDataSanityController(IDSDataSanity dSDataSanity)
        {
            _dSDataSanity = dSDataSanity;
        }
        /// <summary>
        /// Data Sanity Get Record
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetStaggingRecords")]
        public ActionResult<DataSanityModel> GetStaggingRecords()
        {
            try
            {
                Logger.Information("Data Sanity GetStaggingRecords");
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.GetStaggingRecords());
            }
            catch (Exception ex)
            {
                Logger.Information("Data Sanity GetStaggingRecords- Error" + ex.ToString());
                return null;
            }


        }
        /// <summary>
        /// Data Sanity Search function
        /// </summary>
        /// <param name="id"></param>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetStaggingRecords/{Search}")]
        public ActionResult<DataSanityModel> GetStaggingRecords(Search search)
        {
            try
            {
                Logger.Information("DataSanity-Search stagging Records");


                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.SearchStaggingRecords(search.MPXN, search.sdate, search.edate));
            }
            catch (Exception ex)
            {
                Logger.Information("Data Sanity SearchStaggingRecords- Error" + ex.ToString());
                return null;
            }

        }
        [HttpPost]
        [Route("api/{controller}/UpdateStaggingRecords/{json?}")]
        public IActionResult UpdateStaggingRecords(object json, int UserId)
        {
            try
            {
                Logger.Information("DCF Data Sanity  -UpdateStaggingRecords");
                string jsondata = json.ToString();
                List<DataSanityUpdate> dt = JsonConvert.DeserializeObject<List<DataSanityUpdate>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.UpdateStaggingRecords(dt, UserId));
            }
            catch (Exception ex)
            {
                Logger.Error("DCF Data Sanity  -UpdateStaggingRecords- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/DeleteStaggingRecords/{json?}")]
        public IActionResult DeleteStaggingRecords(object json, int UserId)
        {
            try
            {
                Logger.Information("DCF Data Sanity  -DeleteStaggingRecords");
                string jsondata = json.ToString();
                List<DataSanityUpdate> dt = JsonConvert.DeserializeObject<List<DataSanityUpdate>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.DeleteStaggingRecords(dt, UserId));
            }
            catch (Exception ex)
            {
                Logger.Error("DCF Data Sanity  -DeleteStaggingRecords- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        [HttpGet]
        [Route("api/{controller}/SapActionRecords")]
        public ActionResult<SapAction> SapActionRecords()
        {
            try
            {
                Logger.Information("Sap Action  SapActionRecords");
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.SapActionRecords());
            }
            catch (Exception ex)
            {
                Logger.Information("Sap Action SapActionRecords- Error" + ex.ToString());
                return null;
            }

        }
        [HttpPost]
        [Route("api/{controller}/UpdateSapData/{json?}")]
        public IActionResult UpdateSapData(object json)
        {
            try
            {
                Logger.Information("DCF Data Sanity  -UpdateSapData");
                string jsondata = json.ToString();
                List<SapActionUpdate> dt = JsonConvert.DeserializeObject<List<SapActionUpdate>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.UpdateSapData(dt));
            }
            catch (Exception ex)
            {
                Logger.Error("DCF Data Sanity  -UpdateSapData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpGet]
        [Route("api/{controller}/DcfEmailRecords")]
        public ActionResult<DcfEmail> DcfEmailRecords()
        {
            try
            {
                Logger.Information("DcfEmailRecords  call");
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.DcfEmailRecords());
            }
            catch (Exception ex)
            {

                Logger.Information("DcfEmailRecords call- Error" + ex.ToString());
                return null;
            }

        }

        [HttpGet]
        [Route("api/{controller}/TodayRecords")]
        public ActionResult<DcfEmail> TodayRecords()
        {
            try
            {
                Logger.Information("Today Record Count  call");
                return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.TodayRecords());
            }
            catch (Exception ex)
            {

                Logger.Information("Today Record Count call- Error" + ex.ToString());
                return null;
            }

        }
        /// <summary>
        /// Data Sanity Get Record
        /// </summary>
        /// <returns></returns>
        //[HttpGet]
        //[Route("api/{controller}/GetCraeteFileRecords")]
        //public ActionResult<DataSanityModel> GetCreateFileRecords()
        [HttpPost]
        [Route("api/{controller}/GetCraeteFileRecords/{json?}")]
        public ActionResult<DataSanityModel> GetCreateFileRecords(string sdate, string edate)
        {
            try
            {
                Logger.Information("Data Sanity GetCraeteFileRecords");
                //return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.GetCreateFileRecords());
                 return StatusCode((int)HttpStatusCode.OK, _dSDataSanity.GetCreateFileRecords(sdate,edate));
            }
            catch (Exception ex)
            {

                Logger.Information("Data Sanity GetCraeteFileRecords- Error" + ex.ToString());
                return null;
            }


        }
    }
}

﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    [ApiController]
    public class ElectricityWorkFlowController : BaseController
    {

        private readonly IElecWorkFlow objelecw;
        public ElectricityWorkFlowController(IElecWorkFlow _objelecw)
        {
            objelecw = _objelecw;
        }
        /// <summary>
        /// Electricity Workflow Get record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetElectricitydata")]
        public ActionResult<ElecticityWorkFlowModel> GetElectricitydata(ElecSearchCriteria objInput)
        {
            try
            {

                Logger.Information("Electricity Workflow GetElectricitydata");
                return StatusCode((int)HttpStatusCode.OK, objelecw.GetElecData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("Electricity Workflow GetElectricitydata- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }




        /// <summary>
        /// Electricity workflow Generate Excel and send email to ops
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        //[HttpPost]
        //[Route("api/{controller}/GenerateFile/{json?}")]
        //public IActionResult GenerateFile(object json)
        //{
        //    //string wwroot = _hostingEnvironment.WebRootPath;
        //    try
        //    {
        //        Logger.Information("Electricity workflow Generate Excel send email to ops");
        //        object jsondata = json;
        //        var dt = JsonConvert.DeserializeObject<DataTable>(jsondata.ToString());
        //        //create Excel File
        //        var spath = Path.Combine(Path.Combine(Directory.GetCurrentDirectory(), "Files"), "App_Data", "Elec.xlsx");
        //        if (OpenXml.CreateExcelDocument(dt, spath))
        //        {
        //            //in ftp case
        //            // File_ET_Header fh = _ftpOperations.WriteFiletoFTP(spath);
        //            //Email("");

        //            //UpdateStageCode(json);
        //            return Ok(HttpStatusCode.OK);
        //        }
        //        else
        //        {
        //            return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status417ExpectationFailed);
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        Logger.Error("Electricity workflow Generate Excel send email to ops- Error " + ex.ToString());
        //        return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());

        //    }

        //}

        [HttpPost]
        [Route("api/{controller}/UpdateElecticityWorkFlow/{json?}")]
        public IActionResult UpdateElecticityWorkFlow(object json)
        {
            try
            {
                Logger.Information("Electricity Workflow Update records  -UpdateElecticityWorkFlow");
                string jsondata = json.ToString();
                List<ElectircityWorkFlowUpdate> dt = JsonConvert.DeserializeObject<List<ElectircityWorkFlowUpdate>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objelecw.UpdateElecticityWorkFlow(dt));
            }
            catch (Exception ex)
            {
                Logger.Error("Electricity Workflow Update records   -UpdateElecticityWorkFlow- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


    }
}

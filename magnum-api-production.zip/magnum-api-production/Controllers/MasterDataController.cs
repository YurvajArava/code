﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class MasterDataController : BaseController
    {
        private readonly IETStatus _etstatusService;
        private readonly ICommonMaster _commonmasterService;
        private readonly IReasonMaster _reasonmasterService;
        private readonly ICancelReason _cancelreasonService;
        private readonly IOtherSupplier _othersupplierService;
        private readonly ILetterMasters _lettermastersService;
        private readonly IExclusion _exclusion;
        //private readonly IHolidayMaster _holidaymasterService;
        public MasterDataController(IETStatus etstatus, ICommonMaster commonmaster, IReasonMaster reasonmaster, ILetterMasters letterMasters, IOtherSupplier othersupplier, ICancelReason cancelreason, IExclusion exclusion)
        {
            _etstatusService = etstatus;
            _commonmasterService = commonmaster;
            _reasonmasterService = reasonmaster;
            _cancelreasonService = cancelreason;
            _othersupplierService = othersupplier;
            _lettermastersService = letterMasters;
            _exclusion = exclusion;
            //_holidaymasterService = holidayMaster;

        }


        #region "ET Status"

        /// <summary>
        ///ET Status- GetData
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetETStatusData")]
        public ActionResult<ETStatusModel> GetETStatusData()
        {
            try
            {
                Logger.Information("ET Status- GetETStatusData Method");
                return StatusCode((int)HttpStatusCode.OK, _etstatusService.GetAllETStatus());
            }
            catch (Exception ex)
            {
                Logger.Error("ET Status- GetETStatusData Method-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// ET Status- Get By Id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetETStatusById/{Id?}")]
        public ActionResult GetETStatusById(int Id)
        {
            try
            {
                Logger.Information("ET Status- GetETStatusById");
                return StatusCode((int)HttpStatusCode.OK, _etstatusService.GetETStatusById(Id));
            }
            catch (Exception ex)
            {
                Logger.Error("ET Status- GetETStatusById Method-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }



        /// <summary>
        /// ET Status- CreateETStatus
        /// </summary>
        /// <param name="eTStatusModel"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/CreateETStatus")]
        public ActionResult CreateETStatus([FromBody] ETStatusModel eTStatusModel)
        {
            try
            {
                Logger.Information("ET Status- CreateETStatus");
                return StatusCode((int)HttpStatusCode.OK, _etstatusService.AddETStatus(eTStatusModel));
            }
            catch (Exception ex)
            {

                Logger.Error("ET Status- CreateETStatus-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }

        /// <summary>
        /// ET Status- Update
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="eTStatusModel"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateETStatus/{Id?}")]
        public ActionResult UpdateETStatus(int Id, [FromBody] ETStatusModel eTStatusModel)
        {
            try
            {
                Logger.Information("ET Status- UpdateETStatus");

                return StatusCode((int)HttpStatusCode.OK, _etstatusService.UpdateETStatus(eTStatusModel));
            }
            catch (Exception ex)
            {
                Logger.Error("ET Status- UpdateETStatus Method-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        #endregion

        #region

        /// <summary>
        /// Cancel Reason -GetCancelReasonById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetCancelReasonById/{id}")]
        public ActionResult<CancelReason> GetCancelReasonById(int id)
        {
            try
            {

                Logger.Information("Cancel Reason -GetCancelReasonById");
                return StatusCode((int)HttpStatusCode.OK, _cancelreasonService.GetCancelReasonById(id));
            }
            catch (Exception ex)
            {
                Logger.Error("Cancel Reason -GetCancelReasonById-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }


        }


        /// <summary>
        /// Cancel Reason -GetCancelReason
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetCancelReason")]
        public ActionResult<CancelReason> GetCancelReason()
        {
            try
            {
                Logger.Information("Cancel Reason- GetCancelReason");
                return StatusCode((int)HttpStatusCode.OK, _cancelreasonService.GetCancelReason());
            }
            catch (Exception ex)
            {
                Logger.Error("Cancel Reason -GetCancelReason-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }


        }
        /// <summary>
        /// Cancel Reason -create
        /// </summary>
        /// <param name="CancelReason"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/AddCancelReason")]
        public ActionResult AddCancelReason([FromBody] CancelReason CancelReason)
        {
            try
            {
                Logger.Information("Cancel Reason-AddCancelReason");
                return StatusCode((int)HttpStatusCode.OK, _cancelreasonService.AddCancelReason(CancelReason));
            }
            catch (Exception ex)
            {
                Logger.Error("Cancel Reason -AddCancelReason-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Cancel Reason- Update
        /// </summary>
        /// <param name="id"></param>
        /// <param name="CancelReason"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateCancelReason/{id}")]
        public ActionResult UpdateCancelReason(int id, [FromBody] CancelReason CancelReason)
        {
            try
            {
                Logger.Information("Cancel Reason- UpdateCancelReason");
                return StatusCode((int)HttpStatusCode.OK, _cancelreasonService.UpdateCancelReason(CancelReason));
            }
            catch (Exception ex)
            {
                Logger.Error("Cancel Reason -UpdateCancelReason-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        #endregion


        #region

        /// <summary>
        /// Common Master GetCommonMasterById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetCommonMasterById/{id}")]
        public ActionResult<CommonMaster> GetCommonMasterById(int id)
        {
            try
            {
                Logger.Information("Common Master GetCommonMasterById");
                //return _Commonmaster.GetCommonMaster();
                return StatusCode((int)HttpStatusCode.OK, _commonmasterService.GetCommonMasterById(id));
            }
            //return (IEnumerable<CommonMaster>)Ok();
            catch (Exception ex)
            {
                Logger.Error("Common Master GetCommonMasterById-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Common Master GetCommonMaster
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetCommonMaster")]
        public ActionResult<CommonMaster> GetCommonMaster()
        {
            try
            {
                Logger.Information("Common Master GetCommonMaster");
                //return _Commonmaster.GetCommonMaster();

                return StatusCode((int)HttpStatusCode.OK, _commonmasterService.GetCommonMaster());
            }
            catch (Exception ex)
            {
                Logger.Error("Common Master GetCommonMaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }


        }

        /// <summary>
        /// Common Master create 
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        // POST api/<CommonMasterController>
        [HttpPost]
        [Route("api/{controller}/createcommonmaster")]
        public ActionResult createcommonmaster([FromBody] CommonMaster commonMaster)
        {
            try
            {
                Logger.Information("Common Master createcommonmaster");

                return StatusCode((int)HttpStatusCode.OK, _commonmasterService.AddCommonMaster(commonMaster));
            }
            catch (Exception ex)
            {
                Logger.Error("Common Master createcommonmaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }



        /// <summary>
        /// common master update
        /// </summary>
        /// <param name="id"></param>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        // PUT api/<CommonMasterController>/5
        [HttpPut]
        [Route("api/{controller}/updatecommonmaster/{id}")]
        public ActionResult updatecommonmaster(int id, [FromBody] CommonMaster commonMaster)
        {
            try
            {
                Logger.Information("Common Master updatecommonmaster functionality");

                return StatusCode((int)HttpStatusCode.OK, _commonmasterService.UpdateCommonMaster(commonMaster));

            }
            catch (Exception ex)
            {
                Logger.Error("Common Master updatecommonmaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        #endregion
        #region customer Letter Generation

        /// <summary>
        /// Get Filtered Data For Customer Letter 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        // PUT api/<LetterMasterController>/5
        [HttpPost]
        [Route("api/{controller}/GetCustomerLetterData/{id}")]
        public ActionResult GetDataForCustomerLetter(int id, [FromBody] CustomerLetterFilters CletterFilters)
        {
            try
            {
                Logger.Information("Customer Letter - GetDataForCustomerLetter");
                return StatusCode((int)HttpStatusCode.OK, _lettermastersService.GetDataForCustomerLetter(CletterFilters));

            }
            catch (Exception ex)
            {
                Logger.Error("Customer Letter - GetDataForCustomerLetter" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }

        #endregion

        //        #region

        //        /// <summary>
        //        /// Holidays -GetHolidays
        //        /// </summary>
        //        /// <returns></returns>
        //        [HttpGet]
        //        [Route("api/{controller}/GetHolidays")]
        //        public ActionResult<HolidaysMaster> GetHolidays()
        //        {
        //            try
        //            {
        //                Logger.Information("Holidays -GetHolidays record");
        //                return StatusCode((int)HttpStatusCode.OK, _holidaymasterService.GetHolidays());
        //            }
        //            catch (Exception ex)
        //            {
        //                Logger.Error("Holidays -GetHolidays-Error" + ex.ToString());
        //                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
        //            }


        //        }
        //        #endregion


        #region


        /// <summary>
        /// Letter Master-GetLetterMaster
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetLetterMaster")]
        public ActionResult<LetterMaster> GetLetterMaster()
        {
            try
            {
                Logger.Information("Letter Master- GetLetterMaster");
                return StatusCode((int)HttpStatusCode.OK, _lettermastersService.GetLetterMaster());
            }
            catch (Exception ex)
            {
                Logger.Error("Letter Master- GetLetterMaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Letter Master-GetLetterMasterById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET api/<LetterMasterController>/5
        [HttpGet]
        [Route("api/{controller}/GetLetterMasterById/{id}")]
        public ActionResult<LetterMaster> GetLetterMasterById(int id)
        {

            try
            {
                Logger.Information("Letter Master- GetLetterMasterById");
                return StatusCode((int)HttpStatusCode.OK, _lettermastersService.GetLetterMasterById(id));
            }
            catch (Exception ex)
            {
                Logger.Error("Letter Master- GetLetterMasterById-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
            //return (IEnumerable<CommonMaster>)Ok();

        }

        /// <summary>
        /// Letter Master-Post
        /// </summary>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        // POST api/<LetterMasterController>
        [HttpPost]
        [Route("api/{controller}/createlettermaster")]
        public ActionResult createlettermaster([FromBody] LetterMaster letterMaster)
        {
            try
            {
                Logger.Information("Letter Master- createlettermaster");
                return StatusCode((int)HttpStatusCode.OK, _lettermastersService.AddLetterMaster(letterMaster));

            }
            catch (Exception ex)
            {
                Logger.Error("Letter Master- createlettermaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }


        /// <summary>
        /// Letter Master-Update
        /// </summary>
        /// <param name="id"></param>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        // PUT api/<LetterMasterController>/5
        [HttpPut]
        [Route("api/{controller}/UpdateLetterMaster/{id}")]
        public ActionResult UpdateLetterMaster(int id, [FromBody] LetterMaster letterMaster)
        {
            try
            {
                Logger.Information("Letter Master- UpdateLetterMaster Method");
                return StatusCode((int)HttpStatusCode.OK, _lettermastersService.UpdateLetterMaster(letterMaster));

            }
            catch (Exception ex)
            {
                Logger.Error("Letter Master- UpdateLetterMaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }

        #endregion



        #region


        /// <summary>
        /// Reason Master Get Reason Master By Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetReasonMasterById/{id}")]
        public ActionResult<ReasonMaster> GetReasonMasterById(int id)
        {
            try
            {
                Logger.Information("Reason Master -GetReason Master ById");

                return StatusCode((int)HttpStatusCode.OK, _reasonmasterService.GetReasonMasterById(id));
            }
            catch (Exception ex)
            {
                Logger.Error("Letter Master- GetReason Master ById-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Reason Master Get function
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetReasonMaster")]
        public ActionResult<ReasonMaster> GetReasonMaster()
        {
            try
            {
                Logger.Information("Reason Master -GetReason Master");
                return StatusCode((int)HttpStatusCode.OK, _reasonmasterService.GetReasonMaster());

            }
            catch (Exception ex)
            {
                Logger.Error("Reason Master -GetReason Master-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }


        }



        /// <summary>
        /// Reason Master CreateReasonMaster function
        /// </summary>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/CreateReasonMaster")]
        public ActionResult CreateReasonMaster([FromBody] ReasonMaster reasonMaster)
        {
            try
            {
                Logger.Information("Reason Master -CreateReasonMaster");
                return StatusCode((int)HttpStatusCode.OK, _reasonmasterService.AddReasonMaster(reasonMaster));

            }
            catch (Exception ex)
            {
                Logger.Error("Reason Master -CreateReasonMaster -Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// reason master update function
        /// </summary>
        /// <param name="id"></param>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateReasonMaster/{id}")]
        public ActionResult UpdateReasonMaster(int id, [FromBody] ReasonMaster reasonMaster)
        {
            try
            {
                Logger.Information("Reason Master -UpdateReasonMaster functionality");

                return StatusCode((int)HttpStatusCode.OK, _reasonmasterService.UpdateReasonMaster(reasonMaster));
            }
            catch (Exception ex)
            {
                Logger.Error("Reason Master -UpdateReasonMaster -Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion


        #region
        /// <summary>
        /// Other Supplier GetOtherSupplierById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetOtherSupplierById/{id}")]
        public ActionResult<OtherSupplier> GetOtherSupplierById(int id)
        {
            try
            {
                Logger.Information("Other Supplier- GetOtherSupplierById");
                return StatusCode((int)HttpStatusCode.OK, _othersupplierService.GetOtherSupplierById(id));
            }

            catch (Exception ex)
            {
                Logger.Error("Other Supplier- GetOtherSupplierById" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }



        /// <summary>
        /// Other Supplier GetOtherSupplier
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetOtherSupplier")]
        public ActionResult<OtherSupplier> GetOtherSupplier()
        {
            try
            {
                Logger.Information("Other Supplier- GetOtherSupplier");
                return StatusCode((int)HttpStatusCode.OK, _othersupplierService.GetOtherSupplier());
            }
            catch (Exception ex)
            {

                Logger.Error("Other Supplier- GetOtherSupplier" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Other Supplier create
        /// </summary>
        /// <param name="otherSupplier"></param>
        /// <returns></returns>

        // POST api/<OtherSupplierController>
        [HttpPost]
        [Route("api/{controller}/OtherSupplierCreate")]
        public ActionResult OtherSupplierCreate([FromBody] OtherSupplier otherSupplier)
        {
            try
            {
                Logger.Information("Other Supplier- OtherSupplierCreate");
                return StatusCode((int)HttpStatusCode.OK, _othersupplierService.AddOtherSupplier(otherSupplier));

            }
            catch (Exception ex)
            {
                Logger.Error("Other Supplier- OtherSupplierCreate-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }




        /// <summary>
        /// other supplier update
        /// </summary>
        /// <param name="id"></param>
        /// <param name="otherSupplier"></param>
        /// <returns></returns>
        // PUT api/<OtherSupplierController>/5
        [HttpPut]
        [Route("api/{controller}/OtherSupplierUpdate/{id}")]
        public ActionResult OtherSupplierUpdate(int id, [FromBody] OtherSupplier otherSupplier)
        {
            try
            {
                Logger.Information("Other Supplier- Update functionality");
                return StatusCode((int)HttpStatusCode.OK, _othersupplierService.UpdateOtherSupplier(otherSupplier));
                //return _otherSupplier.AddOtherSupplier(otherSupplier);
            }
            catch (Exception ex)
            {
                Logger.Error("Other Supplier- Other Supplier- Update-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion
        #region
        /// <summary>
        /// GetExclusion Master Get function
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GetExclusion")]
        public ActionResult<Exclusion> GetExclusion()
        {
            try
            {
                Logger.Information("Exclusion Master -GetReason Master");
                return StatusCode((int)HttpStatusCode.OK, _exclusion.GetExclusion());

            }
            catch (Exception ex)
            {
                Logger.Error("Exclusion Master-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }


        }
        [HttpGet]
        [Route("api/{controller}/GetExclusionById/{id}")]
        public ActionResult<Exclusion> GetExclusionById(int id)
        {
            try
            {
                Logger.Information("Exclusion Master GetExclusionById");
                //return _Commonmaster.GetCommonMaster();
                return StatusCode((int)HttpStatusCode.OK, _exclusion.GetExclusionById(id));
            }
            //return (IEnumerable<CommonMaster>)Ok();
            catch (Exception ex)
            {
                Logger.Error("Exclusion Master GetExclusionById-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        /// <summary>
        /// Exclusion Master create 
        /// </summary>
        /// <param name="Exclusion Master"></param>
        /// <returns></returns>
        // POST api/<ExclusionMasterController>
        [HttpPost]
        [Route("api/{controller}/createExclusionmaster")]
        public ActionResult createExclusionmaster([FromBody] Exclusion exclusion)
        {
            try
            {
                Logger.Information("Exclusion Master createExclusionmaster");

                return StatusCode((int)HttpStatusCode.OK, _exclusion.AddExclusion(exclusion));
            }
            catch (Exception ex)
            {
                Logger.Error("Exclusion Master createExclusionmaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPut]
        [Route("api/{controller}/updateExclusionmaster/{id}")]
        public ActionResult updateExclusionmaster(int id, [FromBody] Exclusion exclusion)
        {
            try
            {
                Logger.Information("Exclusion Master updateExclusionmaster functionality");
                return StatusCode((int)HttpStatusCode.OK, _exclusion.UpdateExclusion(exclusion));

            }
            catch (Exception ex)
            {
                Logger.Error("Exclusion Master updateExclusionmaster-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        #endregion
    }
}

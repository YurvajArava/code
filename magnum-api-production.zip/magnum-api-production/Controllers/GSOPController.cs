﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    // [Route("api/[controller]")]
    [ApiController]
    public class GSOPController : BaseController
    {
        private readonly IGSOP objgsop;
        public GSOPController(IGSOP _objgsop)
        {
            objgsop = _objgsop;
        }

        #region Standard A1
        [HttpPost]
        [Route("api/{controller}/GetGSOPAoneData")]
        public ActionResult<GSOPStandardAone> GetGSOPAoneData(GSOPA1Search objInput)
        {
            try
            {
                Logger.Information("GSOPAone  GetGSOPAoneData");
                return StatusCode((int)HttpStatusCode.OK, objgsop.GetGSOPAoneData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("GSOPAone  GetGSOPAoneData Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPost]
        [Route("api/{controller}/GetCompensationDetail/RefId/CompType")]
        public ActionResult<CompensationDetail> GetCompensationDetail(long RefId, string CompType)
        {
            try
            {
                Logger.Information("GSOPAone  GetCompensationDetail");
                return StatusCode((int)HttpStatusCode.OK, objgsop.GetCompensationDetail(RefId, CompType));

            }
            catch (Exception ex)
            {
                Logger.Error("GSOPAone  GetCompensationDetail Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPost]
        [Route("api/{controller}/UpdateCompensationDetail")]
        public ActionResult UpdateCompensationDetail(CompensationDetail objInput)
        {
            try
            {
                Logger.Information("GSOPAone  UpdateCompensationDetail");
                return StatusCode((int)HttpStatusCode.OK, objgsop.UpdateCompensationDetail(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("GSOPAone  UpdateCompensationDetail Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/ImportGsopData")]
        public IActionResult ImportGsopData(GsopStandardAUpdateViewModel objInput)
        {
            try
            {
                Logger.Information("GsopStandardA1 -ImportStandardA1Data");
                return StatusCode((int)HttpStatusCode.OK, objgsop.ImportGsopData(objInput));
            }
            catch (Exception ex)
            {
                Logger.Error("GsopStandardA1 -ImportStandardA1Data- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion

        #region Standard B
        [HttpPost]
        [Route("api/{controller}/GetGSOPBData")]
        public ActionResult<GSOPStandardB> GetGSOPBData(GsopBSearch objInput)
        {
            try
            {
                Logger.Information("GSOPB  GetGSOPBData");
                return StatusCode((int)HttpStatusCode.OK, objgsop.GetGSOPBData(objInput));
            }
            catch (Exception ex)
            {
                Logger.Error("GSOPB  GetGSOPB Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        #endregion

        #region Standard BD

        [HttpPost]
        [Route("api/{controller}/GetGSOPBDData")]
        public ActionResult<GSOPStandardBD> GetGSOPBDData(GsopBDSearch objInput)
        {
            try
            {
                Logger.Information("GSOPB  GetGSOPBDData");
                return StatusCode((int)HttpStatusCode.OK, objgsop.GetGSOPBDData(objInput));
            }
            catch (Exception ex)
            {
                Logger.Error("GSOPB  GetGSOPBD Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        #endregion

        [HttpPost]
        [Route("api/{controller}/UploadGSOPRecords/{json?}")]
        public ActionResult<SapAction> UploadGSOPRecords(object json)
        {
            try
            {
                Logger.Information("GSOP Standard A1 data upload");
                string jsondata = json.ToString();
                List<GSOPStandardAone> data = JsonConvert.DeserializeObject<List<GSOPStandardAone>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objgsop.UploadGSOPRecords(data));
            }
            catch (Exception ex)
            {
                Logger.Information("Sap Action SapActionRecords- Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPost]
        [Route("api/{controller}/UpdateGSOPRecords/{json?}")]
        public IActionResult UpdateGSOPRecords(object json, int userid)
        {
            try
            {
                Logger.Information("GSOP Common Upload  -UpdateGSOPRecords");
                string jsondata = json.ToString();
                List<CompensationDetail> dt = JsonConvert.DeserializeObject<List<CompensationDetail>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objgsop.UpdateGSOPRecords(dt, userid));
            }
            catch (Exception ex)
            {
                Logger.Error("GSOP Common Upload  -UpdateGSOPRecords- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPost]
        [Route("api/{controller}/UpdateGSOPA1Records/{json?}")]
        public IActionResult UpdateGSOPA1Records(object json, int userid)
        {
            try
            {
                Logger.Information("GSOP StandardA1 Upload  -UpdateGSOPRecords");
                string jsondata = json.ToString();
                List<CompensationDetail> dt = JsonConvert.DeserializeObject<List<CompensationDetail>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objgsop.UpdateGSOPA1Records(dt, userid));
            }
            catch (Exception ex)
            {
                Logger.Error("GSOP StandardA1  -UpdateGSOPRecords- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
    }
}

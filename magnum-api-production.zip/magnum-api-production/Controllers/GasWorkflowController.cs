﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    [ApiController]
    public class GasWorkflowController : BaseController
    {
        private readonly IGasWorkflow objgasw;
        public GasWorkflowController(IGasWorkflow _objgasw)
        {
            objgasw = _objgasw;
        }
        /// <summary>
        /// Gas workflow  get data
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetGasData")]
        public ActionResult<GasworkflowModel> GetGasData(GasSearchCriteria model)
        {
            try
            {
                Logger.Information("Gas workflow  GetGasData");
                return StatusCode((int)HttpStatusCode.OK, objgasw.GetGasData(model));

            }
            catch (Exception ex)
            {
                Logger.Error("Gas workflow  GetGasData Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Gas workflow Generate Excel and send email to ops
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        //[HttpPost]
        //[Route("api/{controller}/ReceiveData/{json?}")]
        //public IActionResult ReceiveData(object json)
        //{
        //    //string wwroot = _hostingEnvironment.WebRootPath;
        //    try
        //    {
        //        Logger.Information("Gas workflow Generate Excel send email to ops");
        //        object jsondata = json;
        //        var dt = JsonConvert.DeserializeObject<DataTable>(jsondata.ToString());
        //        //create Excel File
        //        var spath = Path.Combine(Path.Combine(Directory.GetCurrentDirectory(), "Files"), "App_Data", "Gas.xlsx");
        //        if (OpenXml.CreateExcelDocument(dt, spath))
        //        {
        //            //in ftp case
        //            // File_ET_Header fh = _ftpOperations.WriteFiletoFTP(spath);
        //            //Email("");

        //            UpdateStageCode (json);
        //            return Ok(HttpStatusCode.OK);
        //        }
        //        else
        //        {
        //            return StatusCode(Microsoft.AspNetCore.Http.StatusCodes.Status417ExpectationFailed);
        //        }
        //        //create CSV File
        //        //FileProcessing fp = new FileProcessing();
        //        //var spath = Path.Combine(Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "App_Data", "BG.csv");
        //        //if (fp.TableToCSV(dt, spath))
        //        //{
        //        //    return Ok(HttpStatusCode.NotModified);

        //        //}
        //        //else
        //        //{
        //        //    return Ok(HttpStatusCode.OK);
        //        //}
        //    }
        //    catch (Exception ex)
        //    {
        //        //Comman.WriteError(ex, wwroot);
        //        //return StatusCode(600);
        //        Logger.Error("Gas workflow Generate Excel send email to ops- Error " + ex.ToString());
        //        return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());

        //    }

        //}





        /// <summary>
        /// UpdateStageCode
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        //[HttpPut]
        //[Route("api/{controller}/UpdatewfgData/{json?}")]
        //public IActionResult UpdatewfgData(object json)
        //{
        //    try
        //    {
        //        Logger.Information("Gas Workflow -UpdatewfgData");
        //        string jsondata = json.ToString();
        //        List<GasWorkFlowUpdateModel> dt = JsonConvert.DeserializeObject<List<GasWorkFlowUpdateModel>>(jsondata);
        //        return StatusCode((int)HttpStatusCode.OK, objgasw.UpdatewfgData(dt));
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Error("Gas Workflow -UpdatewfgData- Error " + ex.ToString());
        //        return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
        //    }
        //}

        /// <summary>
        /// UpdateStageCode
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateStageCode/{json?}")]
        public IActionResult UpdateStageCode(object json)
        {
            try
            {
                Logger.Information("Gas Workflow -UpdateStageCode");
                string jsondata = json.ToString();
                List<GasWorkFlowUpdateModel> dt = JsonConvert.DeserializeObject<List<GasWorkFlowUpdateModel>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, objgasw.UpdateStageCode(dt));
            }
            catch (Exception ex)
            {
                Logger.Error("Gas Workflow -UpdateStageCode- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpGet]
        [Route("api/{controller}/GetProcessedCount")]
        public IActionResult GetProcessedCount()
        {
            try
            {
                Logger.Information("Gas workflow  GetGasData");
                return StatusCode((int)HttpStatusCode.OK, objgasw.GetExcelDataCount());
            }
            catch (Exception ex)
            {
                Logger.Error("Gas Workflow -GetProcessedData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/GenerateDataforOps")]
        public IActionResult GenerateDataforOps(string RefIds, int UserId)
        {
            try
            {
                Logger.Information("Gas Workflow -Generate file");

                return StatusCode((int)HttpStatusCode.OK, objgasw.GenerateDataforOps(RefIds, UserId));
            }
            catch (Exception ex)
            {
                Logger.Error("Gas Workflow -UpdateStageCode- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #region
        /// <summary>
        /// Other Supplier GetOtherSupplier
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/GenerateRetData")]
        public ActionResult GenerateRetData()
        {
            try
            {
                Logger.Information("Other Supplier- GetRetData");
                return StatusCode((int)HttpStatusCode.OK, objgasw.GenerateRetData());
            }
            catch (Exception ex)
            {

                Logger.Error("Other Supplier- GetRetData" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        /// <summary>
        /// UpdateStageCode
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateRetData")]
        public IActionResult UpdateRetData(string RefIds, string fileName, string strType, int UserId)
        {
            try
            {
                Logger.Information("Gas Workflow -UpdateRetData");
                return StatusCode((int)HttpStatusCode.OK, objgasw.UpdateRetData(RefIds, fileName, strType, UserId));
            }
            catch (Exception ex)
            {
                Logger.Error("Gas Workflow -UpdateRetData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion
    }
}

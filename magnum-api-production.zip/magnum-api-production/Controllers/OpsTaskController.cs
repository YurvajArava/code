﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{
    public class OpsTaskController : BaseController
    {
        private readonly IOpsTask _objTask;
        public OpsTaskController(IOpsTask objTask)
        {
            _objTask = objTask;
        }

        [HttpPost]
        [Route("api/{controller}/SearchedRecords")]
        public ActionResult<OpsTask> SearchedRecords(OpsTaskSearch objInput)
        {
            try
            {
                Logger.Information("OpsTask SearchedRecords");
                return StatusCode((int)HttpStatusCode.OK, _objTask.SearchRecords(objInput));
            }
            catch (Exception ex)
            {
                Logger.Error("OpsTask  SearchedRecords Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/GetByMPRN")]
        public ActionResult<OpsTask> GetByMPRN(long iRefId, int iEnergySupplyId, int iUserId)
        {
            try
            {
                Logger.Information("OpsTask GetByMPRN");
                return StatusCode((int)HttpStatusCode.OK, _objTask.GetByMPRN(iRefId, iEnergySupplyId, iUserId));
            }
            catch (Exception ex)
            {
                Logger.Error("OpsTask  GetByMPRN Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPut]
        [Route("api/{controller}/UpdateETData/{json?}")]
        public IActionResult UpdateETData(object json, int iUserId, int iEnergyId)
        {
            try
            {
                Logger.Information("OpsTask -UpdateETData");
                string jsondata = json.ToString();
                //List<FollowUp> dt = JsonConvert.DeserializeObject<List<FollowUp>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, _objTask.OpsTaskUpdateETData(jsondata, iUserId, iEnergyId));
            }
            catch (Exception ex)
            {
                Logger.Error("OpsTask -UpdateETData- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
    }
}

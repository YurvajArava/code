﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]

    public class UserController : BaseController
    {

        private readonly IUser objuser;

        private readonly IUserRoleMap objuserrolemap;
        public UserController(IUser _objuser, IUserRoleMap _objuserrolemap)
        {

            objuser = _objuser;
            objuserrolemap = _objuserrolemap;
        }

        #region UserRegistration

        /// <summary>
        /// Get Users Details
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/getdata")]
        public ActionResult<UserModel> GetData()
        {
            try
            {

                Logger.Information("Users Management -Get Data");
                return StatusCode((int)HttpStatusCode.OK, objuser.GetAllUser());

            }
            catch (Exception ex)
            {
                Logger.Error("Users Management -Get Data Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


        /// <summary>
        /// Get User Details By Id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/{controller}/getbyid/{Id?}")]
        public ActionResult GetById(int Id)
        {
            try
            {
                Logger.Information("Users Management -GetById");
                return StatusCode((int)HttpStatusCode.OK, objuser.GetUserById(Id));
            }
            catch (Exception ex)
            {
                Logger.Error("Users Management -GetById Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }



        /// <summary>
        /// Create New User
        /// </summary>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/create")]
        public ActionResult Create([FromBody] UserModel userMaster)
        {
            try
            {
                Logger.Information("Users Management -Create");
                return StatusCode((int)HttpStatusCode.OK, objuser.AddUserMaster(userMaster));
            }
            catch (Exception ex)
            {
                Logger.Error("Users Management -Create Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }

        }


        /// <summary>
        /// Update User functionality
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/Update/{Id?}")]
        public ActionResult Update(int Id, [FromBody] UserModel userMaster)
        {
            try
            {
                Logger.Information("Users Management -Update");
                return StatusCode((int)HttpStatusCode.OK, objuser.UpdateUserMaster(userMaster));
            }
            catch (Exception ex)
            {
                Logger.Error("Users Management -Update Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion

        /// <summary>
        /// User Get by LanId
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetByLanId/{Id?}")]
        public ActionResult GetByLanId(string Id)
        {
            try
            {
                Logger.Information("Users Management -Get By LanId-" + Id);
                return StatusCode((int)HttpStatusCode.OK, objuser.GetByLanId(Id));
            }

            catch (Exception ex)
            {
                Logger.Error("Users Management -Get By LanId-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());

            }


        }

        /// <summary>
        /// Role Mapping GetRoleFunction 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetRoleFunction/{Id}/{UserId}")]
        public ActionResult<UserRoleMap> GetRoleFunction(int Id, int UserId)
        {
            try
            {

                Logger.Information("Role Mapping -GetRoleFunction");
                return StatusCode((int)HttpStatusCode.OK, objuserrolemap.GetAllFunction(Id, UserId));
            }
            catch (Exception ex)
            {
                Logger.Error("Role Mapping -GetRoleFunction-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #region Role Mapping

        /// <summary>
        /// Role Mapping GetRoleFunction 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/{controller}/GetRoleFunction/{Id}")]
        public ActionResult<UserRoleMap> GetRoleFunction(int Id)
        {
            try
            {
                Logger.Information("Role Mapping -GetRoleFunction");
                return StatusCode((int)HttpStatusCode.OK, objuserrolemap.GetAllFunction(Id));
            }
            catch (Exception ex)
            {
                Logger.Error("Role Mapping -GetRoleFunction-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        /// <summary>
        /// Role Mapping Update
        /// </summary>
        /// <param name="RoleID"></param>
        /// <param name="UserRoleMap"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("api/{controller}/UpdateRoleMapping/{Id?}")]
        public ActionResult UpdateRoleMapping(int RoleID, [FromBody] List<UserRoleMap> UserRoleMap)
        {
            try
            {
                Logger.Information("Role Mapping -UpdateRoleMapping");
                return StatusCode((int)HttpStatusCode.OK, objuserrolemap.UpdateUserRoleMap(RoleID, UserRoleMap));
            }
            catch (Exception ex)
            {
                Logger.Error("Role Mapping -UpdateRoleMapping-Error" + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        #endregion
    }
}

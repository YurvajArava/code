﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{
    
    [ApiController]
    public class ReportTableController : ControllerBase
    {
        private readonly IReportTable objReport;
        private ILog logger;
        public ReportTableController(IReportTable _objReport, ILog logger)
        {
            objReport = _objReport;
            this.logger = logger;
        }
        
        [HttpPost]
[Route("api/{controller}/GetCustomerLetterReport")]
public ActionResult GetCustomerLetterReport(ReportTablesSearch model)
{
try
{
logger.Information("Report Data GetReportdata");
return StatusCode((int)HttpStatusCode.OK, objReport.GetCustomerLetterReport(model));



}
catch (Exception ex)
{
logger.Error("Report DATA GetReportdata- Error " + ex.ToString());
return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
}
}
        
        [HttpPost]
        [Route("api/{controller}/GetReportRETdata")]
        public ActionResult GetReportRETdata(ReportTablesSearch model)
        {
            try
            {
                logger.Information("Report Data GetReportdata");
                return StatusCode((int)HttpStatusCode.OK, objReport.GetReportRETTables(model));

            }
            catch (Exception ex)
            {
                logger.Error("Report DATA GetReportdata- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
      
  
      
        [HttpPost]
        [Route("api/{controller}/GetReportUSRTables")]
        public ActionResult GetReportUSRTables(ReportTablesSearch model)
        {
            try
            {
                logger.Information("Report Data GetReportdata");
                return StatusCode((int)HttpStatusCode.OK, objReport.GetReportUSRTables(model));

            }
            catch (Exception ex)
            {
                logger.Error("Report DATA GetReportdata- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }


    }
}


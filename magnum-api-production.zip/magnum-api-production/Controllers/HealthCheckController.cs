using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860



namespace EXLETAPI.Controllers
{
[Route("api/[controller]")]
[ApiController]
public class HealthCheckController : BaseController
{
// GET: api/<HealthCheckController>
private readonly IConfiguration _configuration;
//[HttpGet]
//public string Get()
//{
// return "API working";
//}



public HealthCheckController(IConfiguration Iconfig)
{
_configuration = Iconfig;
}



[HttpGet]
public string GetKeyValue()
{
try
{



Console.WriteLine("Started");
var value = "test";

//value = _configuration["DBconnectionstring"];
value = _configuration["sqlconnectionstringapi"];
// value = ConfigurationManager.AppSettings["keyvaulturl"];
//SecretClientOptions options = new SecretClientOptions() { Retry = { Delay = TimeSpan.FromSeconds(2), MaxDelay = TimeSpan.FromSeconds(16), MaxRetries = 5, Mode = RetryMode.Exponential } };
//var client = new SecretClient(new Uri("https://vault09282021.vault.azure.net/"), new DefaultAzureCredential(), null);
//KeyVaultSecret secret = client.GetSecret("TestDB");
//string secretValue = secret.Value;
Console.WriteLine(value);
return "Value for Secret [DBconnection] is : " + value;
}
catch (Exception)
{



throw;
}



}
}
}

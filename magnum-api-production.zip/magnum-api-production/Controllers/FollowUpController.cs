using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;

namespace EXLETAPI.Controllers
{
    [ApiController]
    public class FollowUpController : BaseController
    {
        private readonly IFollowUp _objFollowUp;
        public FollowUpController(IFollowUp objFollowUp)
        {
            _objFollowUp = objFollowUp;
        }

        [HttpPost]
        [Route("api/{controller}/GetFollowUpData")]
        public ActionResult<FollowUp> GetFollowUpData(FollowUpSearchAttribute objInput)
        {
            try
            {
                Logger.Information("FollowUp GetFollowUpData");
                return StatusCode((int)HttpStatusCode.OK, _objFollowUp.GetFollowUpData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("FollowUp  GetFollowUpData Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/GetFollowUpOps")]
        public ActionResult<FollowUp> GetFollowUpOps()
        {
            try
            {
                Logger.Information("FollowUp GetFollowUpOps");
                return StatusCode((int)HttpStatusCode.OK, _objFollowUp.GetOpsData());

            }
            catch (Exception ex)
            {
                Logger.Error("FollowUp  GetFollowUpOps Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPost]
        [Route("api/{controller}/GetFollowUpTypes")]
        public ActionResult<FollowUpTypes> GetFollowUpTypes()
        {
            try
            {
                Logger.Information("FollowUp GetFollowUpTypes");
                return StatusCode((int)HttpStatusCode.OK, _objFollowUp.GetFollowUpTypes());

            }
            catch (Exception ex)
            {
                Logger.Error("FollowUp  GetFollowUpTypes Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

        [HttpPut]
        [Route("api/{controller}/UpdateFollowUpOps/{json?}")]
        public IActionResult UpdateFollowUpOps(object json, int iUserId)
        {
            try
            {
                Logger.Information("FollowUp -UpdateFollowUpOps");
                string jsondata = json.ToString();
                //List<FollowUp> dt = JsonConvert.DeserializeObject<List<FollowUp>>(jsondata);
                return StatusCode((int)HttpStatusCode.OK, _objFollowUp.UpdateFollowUpOps(jsondata, iUserId));
            }
            catch (Exception ex)
            {
                Logger.Error("FollowUp -UpdateFollowUpOps- Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
        [HttpPost]
[Route("api/{controller}/UpdateFollowUpRecords/{json?}")]
public IActionResult UpdateFollowUpRecords(object json, int userid)
{
try
{
Logger.Information("GSOP StandardA1 Upload -UpdateGSOPRecords");
string jsondata = json.ToString();
List<FollowSdepUpdate> dt = JsonConvert.DeserializeObject<List<FollowSdepUpdate>>(jsondata);
return StatusCode((int)HttpStatusCode.OK, _objFollowUp.UpdateFollowUpRecords(dt, userid));
}
catch (Exception ex)
{
Logger.Error("GSOP StandardA1 -UpdateGSOPRecords- Error " + ex.ToString());
return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
}
}
    }
}

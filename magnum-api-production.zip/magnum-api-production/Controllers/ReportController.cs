﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace EXLETAPI.Controllers
{
    public class ReportController : BaseController
    {
        private readonly IReport _report;
        public ReportController(IReport report)
        {
            _report = report;
        }

        [HttpPost]
        [Route("api/{controller}/GetMonthlyReport")]
        public ActionResult GetMonthlyReport(MonthlyRptSearchModel objInput)
        {
            try
            {
                Logger.Information("ReportController GetMonthlyReport");
                return StatusCode((int)HttpStatusCode.OK, _report.GetMonthlyReportData(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("ReportController  GetMonthlyReport Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }

       [HttpPost]
        [Route("api/{controller}/GetWeeklyReport")]
        public ActionResult GetWeeklyReport(WeeklyRptSearchModel objInput)
        {
        //objInput.StartDate = null;
        //objInput.EndDate = null;
        //objInput.ThreadType = "New";
        try
        {
        Logger.Information("ReportController GetWeeklyReport");
        return StatusCode((int)HttpStatusCode.OK, _report.GetWeeklyReportData(objInput));



        }
        catch (Exception ex)
        {
        Logger.Error("ReportController GetWeeklyReport Error " + ex.ToString());
        return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
        }
        }
        
        [HttpPost]
        [Route("api/{controller}/GetWeeklyReportOutStanding")]
        public ActionResult GetWeeklyReportOutStanding(WeeklyRptSearchModel objInput)
        {
        //objInput.StartDate = null;
        //objInput.EndDate = null;
        //objInput.ThreadType = "New";
        try
        {
        Logger.Information("ReportController GetWeeklyReport");
        return StatusCode((int)HttpStatusCode.OK, _report.GetWeeklyReportDataOutstanding(objInput));



        }
        catch (Exception ex)
        {
        Logger.Error("ReportController GetWeeklyReport Error " + ex.ToString());
        return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
        }
        }
        
        [HttpPost]
        [Route("api/{controller}/CompensationReport")]
        
        public ActionResult CompensationReport(CompSearch objInput)
        {
            try
            {
                Logger.Information("ReportController CompensationReport");
                return StatusCode((int)HttpStatusCode.OK, _report.CompensationReport(objInput));

            }
            catch (Exception ex)
            {
                Logger.Error("ReportController  CompensationReport Error " + ex.ToString());
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.ToString());
            }
        }
    }
}

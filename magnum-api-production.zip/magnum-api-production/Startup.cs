using EXLETAPI.DataAccess;
using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using NLog;
using System;
using System.IO;
using System.Text;

namespace EXLETAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            LogManager.LoadConfiguration(System.String.Concat(Directory.GetCurrentDirectory(), "/nlog.config"));
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();
            services.AddControllers();

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "EXLETAPI",
                    Version = "v2",
                    Description = "EXLETAPI",
                });
                //options.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());

            });


            // configure strongly typed settings object
            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));

            // configure DI for application services
            services.AddTransient<ICommonMaster, CommonMasterDAL>();
            services.AddTransient<IOtherSupplier, OtherSupplierDAL>();
            services.AddTransient<ILetterMasters, LetterMasterDAL>();
            services.AddTransient<IReRegFollowUp, ReRegFollowUpDAL>();
            // services.AddDbContext<DataContext>(x => x.u("TestDb"));
            services.AddControllers().AddJsonOptions(x => x.JsonSerializerOptions.IgnoreNullValues = true);

            // configure strongly typed settings objects
            var appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            // configure jwt authentication
            var appSettings = appSettingsSection.Get<AppSettings>();
            var key = Encoding.ASCII.GetBytes(appSettings.Key);
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                    ClockSkew = TimeSpan.Zero
                };
            });

            services.AddTransient<ILog, LogNLog>();
            //code merge section
            services.AddTransient<IUser, UserDAL>();
            services.AddTransient<IRoles, RoleDAL>();
            services.AddSingleton<ILog, LogNLog>();
            services.AddTransient<IUserRoleMap, UserRoleMapDAL>();
            services.AddTransient<IReasonMaster, ReasonMasterDAL>();
            services.AddTransient<ICancelReason, CancelReasonDAL>();
            services.AddTransient<IDSDataSanity, DataSanityDAL>();
            services.AddTransient<IETStatus, ETStatusDAL>();
            services.AddTransient<IExclusion, ExclusionDAL>();
            services.AddTransient<IGasWorkflow, GasWorkFlowDAL>();
            services.AddTransient<IElecWorkFlow, ElecWorkFlowDAL>();
            services.AddTransient<IGSOP, GSOPDAL>();
            services.AddTransient<ISLATracker, SLATrackerDAL>();
            services.AddTransient<IReRegFollowUp, ReRegFollowUpDAL>();
            services.AddTransient<IFollowUp, FollowUpDAL>();
            services.AddTransient<IRejectedFiles, RejectedFilesDAL>();
            services.AddTransient<IGSOPC, GSOPCDAL>();
            services.AddTransient<IReport, ReportDAL>();
            services.AddTransient<IExclusion, ExclusionDAL>();
            services.AddTransient<IOpsTask, OpsTaskDAL>();
            services.AddTransient<IReportTable, ReportTableDAL>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {


            //context.Users.Add(new User { Id = 101, LanId = "CORP\\pa_riteshp1", FirstName = "ritesh", LastName = "pandey" });
            //context.SaveChanges();
            //global cors policy
            app.UseCors(x => x
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader());

            // custom jwt auth middleware
            //app.UseMiddleware<JwtMiddleware>();
            // app.UseEndpoints(x => x.MapControllers());
            app.UseSwagger();


            app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v2/swagger.json", "EXLETAPI"));

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            //app.UseEndpoints(endpoints=>
            //{

            //    endpoints.MapControllerRoute(name: "default", pattern: "{controller}/{action}/{id?}");
            //});

            app.UseEndpoints(x => x.MapControllers());

        }
    }
}

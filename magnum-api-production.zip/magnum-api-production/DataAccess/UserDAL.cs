﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class UserDAL : BaseDAL, IUser
    {
        //private string connectionString;
        public UserDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetAllUser
        /// </summary>
        /// <returns></returns>
        public List<UserModel> GetAllUser()

        {
            try
            {
                List<UserModel> lstuser = new List<UserModel>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Usm_GetData", con);
                    cmd.Parameters.AddWithValue("@Id", 0);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        UserModel UserModel = new UserModel();
                        UserModel.ID = Convert.ToInt32(rdr["ID"]);
                        UserModel.LanId = rdr["LanId"].ToString();
                        UserModel.FirstName = rdr["FirstName"].ToString();
                        UserModel.LastName = rdr["LastName"].ToString();
                        UserModel.Email = rdr["Email"].ToString();
                        UserModel.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        UserModel.Title = rdr["Title"].ToString();
                        UserModel.RoleId = Convert.ToInt32(rdr["RoleId"]);
                        lstuser.Add(UserModel);

                    }
                    con.Close();

                }
                return lstuser;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GetUserById
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        public UserModel GetUserById(int Id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    UserModel userdata = new UserModel();
                    SqlCommand cmd = new SqlCommand("Usp_Usm_GetData", con);
                    cmd.Parameters.AddWithValue("@Id", Id);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        int ID = rdr.GetInt32(0);

                        if (ID == Id)
                        {
                            userdata.ID = Convert.ToInt32(rdr["ID"]);
                            userdata.LanId = rdr["LanId"].ToString();
                            userdata.FirstName = rdr["FirstName"].ToString();
                            userdata.LastName = rdr["LastName"].ToString();
                            userdata.Email = rdr["Email"].ToString();
                            userdata.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                            userdata.Title = rdr["Title"].ToString();
                            userdata.RoleId = Convert.ToInt32(rdr["RoleId"]);
                            userdata.Roles = new[]
{
     new SelectListItem { Value = "1", Text = "Admin" },
     new SelectListItem { Value = "2", Text = "Staff" },
  };
                        }
                        userdata.Titles = new[]
{
     new SelectListItem { Value = "Mr.", Text = "Mr." },
     new SelectListItem { Value = "Mrs.", Text = "Mrs." },
  };
                    }

                    con.Close();
                    return userdata;
                }

            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// add user
        /// </summary>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        public UserModel AddUserMaster(UserModel userMaster)
        {
            try
            {
                string @Result = string.Empty;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_AddUser, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", userMaster.ID);
                    cmd.Parameters.AddWithValue("@LanID", userMaster.LanId);
                    cmd.Parameters.AddWithValue("@Title", userMaster.Title);
                    cmd.Parameters.AddWithValue("@FirstName", userMaster.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", userMaster.LastName);
                    cmd.Parameters.AddWithValue("@Email", userMaster.Email);
                    cmd.Parameters.AddWithValue("@RoleID", userMaster.RoleId);
                    cmd.Parameters.AddWithValue("@UserID", userMaster.UserId);
                    cmd.Parameters.AddWithValue("@IsActive", userMaster.IsActive);
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;
                    userMaster.Message = @Result;
                    return userMaster;
                }


            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// update user
        /// </summary>
        /// <param name="userMaster"></param>
        /// <returns></returns>
        public UserModel UpdateUserMaster(UserModel userMaster)
        {
            try
            {
                string @Result = string.Empty;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Usm_CreateUser", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", userMaster.ID);
                    cmd.Parameters.AddWithValue("@LanID", userMaster.LanId);
                     cmd.Parameters.AddWithValue("@Title", userMaster.Title);
                     cmd.Parameters.AddWithValue("@FirstName", userMaster.FirstName);
                     cmd.Parameters.AddWithValue("@LastName", userMaster.LastName);
                     cmd.Parameters.AddWithValue("@Email", userMaster.Email);
                     cmd.Parameters.AddWithValue("@RoleID", userMaster.RoleId);
                     //cmd.Parameters.AddWithValue("@UserID", 102);
                     cmd.Parameters.AddWithValue("@UserID", userMaster.ID);
                    cmd.Parameters.AddWithValue("@IsActive", userMaster.IsActive);
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;
                    userMaster.Message = @Result;

                }
                return userMaster;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// user
        /// </summary>
        /// <param name="LanID"></param>
        /// <returns></returns>
        public string DeleteUserMaster(string LanID)
        {
            try
            {
                string @Result = string.Empty;

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_UserAction", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LanID", LanID);
                    cmd.Parameters.AddWithValue("@FirstName", "");
                    cmd.Parameters.AddWithValue("@LastName", "");
                    cmd.Parameters.AddWithValue("@Email", "");
                    cmd.Parameters.AddWithValue("@IsActive", false);
                    cmd.Parameters.AddWithValue("@Title", "");
                    cmd.Parameters.AddWithValue("@ActionType", "Delete");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;

                }
                return @Result;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// GetByLanId
        /// </summary>
        /// <param name="LanId"></param>
        /// <returns></returns>
        public UserModel GetByLanId(string LanId)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    UserModel userdata = new UserModel();
                    // SqlCommand cmd = new SqlCommand();
                    // cmd.CommandType = CommandType.Text;
                    SqlCommand cmd = new SqlCommand("Usp_Master_GetDetailsWithLanID", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@LanID", LanId);
                    // cmd.CommandText = "Select * from Tbl_UserMaster where LanID=+ LanId";
                    cmd.Connection = con;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        string Id = rdr.GetString(1);

                        if (Id == LanId)
                        {
                            userdata.ID = Convert.ToInt32(rdr["ID"]);
                            userdata.LanId = rdr["LanId"].ToString();
                            userdata.FirstName = rdr["FirstName"].ToString();
                            userdata.LastName = rdr["LastName"].ToString();
                            userdata.Email = rdr["Email"].ToString();
                            userdata.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                            userdata.Title = rdr["Title"].ToString();
                            userdata.RoleId = Convert.ToInt32(rdr["RoleId"]);
                            userdata.Roles = new[]
{
     new SelectListItem { Value = "1", Text = "Admin" },
     new SelectListItem { Value = "2", Text = "Staff" },
  };
                        }

                        userdata.Titles = new[]
    {
     new SelectListItem { Value = "Mr.", Text = "Mr." },
     new SelectListItem { Value = "Mrs.", Text = "Mrs." },
  };
                    }
                    con.Close();

                    return userdata;
                }

            }
            catch
            {
                throw;
            }
        }
    }
}

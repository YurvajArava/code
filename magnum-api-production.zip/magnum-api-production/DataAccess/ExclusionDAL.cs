﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ExclusionDAL : BaseDAL, IExclusion
    {
        //// static string connectionString;
        List<Exclusion> exclusion1 = new List<Exclusion>();
        public ExclusionDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// AddExclusionMaster
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>

        public Exclusion AddExclusion(Exclusion exclusion)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", exclusion.ID);
                cmd.Parameters.AddWithValue("@Code", exclusion.code);
                cmd.Parameters.AddWithValue("@Exclusion", exclusion.Exclusions);
                cmd.Parameters.AddWithValue("@Example", exclusion.Example);
                cmd.Parameters.AddWithValue("@Standard", exclusion.Standard);
                cmd.Parameters.AddWithValue("@IsActive", exclusion.IsActive);
                cmd.Parameters.AddWithValue("@UserId", exclusion.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "ExclusionMaster");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return exclusion;
        }


        /// <summary>
        /// common
        /// </summary>
        /// <param name="Exclusion Master"></param>
        /// <returns></returns>

        public IEnumerable<Exclusion> GetExclusion()
        {

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Master_GetData", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "Exclusion");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Exclusion exclusion = new Exclusion();
                        exclusion.ID = Convert.ToInt32(rdr["ID"].ToString());
                        exclusion.code = rdr["code"].ToString();
                        exclusion.Exclusions = rdr["Exclusion"].ToString();
                        exclusion.Example = rdr["Example"].ToString();
                        exclusion.Standard = rdr["Standard"].ToString();
                        exclusion.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        exclusion1.Add(exclusion);

                    }
                    con.Close();



                }
                return exclusion1;
            }
            catch
            {
                throw;
            }


        }

        public Exclusion GetExclusionById(int id)
        {
            Exclusion exclusion = new Exclusion();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@Calling_Type", "Exclusion");
                //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    exclusion.ID = Convert.ToInt32(rdr["ID"].ToString());
                    exclusion.code = rdr["code"].ToString();
                    exclusion.Exclusions = rdr["Exclusion"].ToString();
                    exclusion.Example = rdr["Example"].ToString();
                    exclusion.Standard = rdr["Standard"].ToString();
                    exclusion.IsActive = Convert.ToBoolean(rdr["IsActive"]);

                }

                con.Close();

                return exclusion;

            }

        }
        /// <summary>
        /// Update Exclusion Master
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        public Exclusion UpdateExclusion(Exclusion exclusion)
        {


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Usp_Master_Action", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", exclusion.ID);
                cmd.Parameters.AddWithValue("@Code", exclusion.code);
                cmd.Parameters.AddWithValue("@Exclusions", exclusion.Exclusions);
                //cmd.Parameters.AddWithValue("@Value", commonMaster.Value);
                cmd.Parameters.AddWithValue("@Example", exclusion.Example);
                cmd.Parameters.AddWithValue("@Standard", exclusion.Standard);
                cmd.Parameters.AddWithValue("@IsActive", exclusion.IsActive);
                cmd.Parameters.AddWithValue("@UserId", exclusion.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "ExclusionMaster");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return exclusion;

        }
    }
}

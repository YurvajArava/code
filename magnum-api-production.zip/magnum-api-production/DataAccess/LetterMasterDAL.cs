﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
namespace EXLETAPI.DataAccess
{
    public class LetterMasterDAL : BaseDAL, ILetterMasters
    {
        //static string connectionString;

        List<LetterMaster> letterMasterList = new List<LetterMaster>();
        public LetterMasterDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        public IEnumerable<CustomerLetterData> GetDataForCustomerLetter(CustomerLetterFilters CLetterFilter)
        {
            List<CustomerLetterData> lst = new List<CustomerLetterData>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Usp_GetCustomerLetterGeneratationData", con);
                if (CLetterFilter.StartDate != null || CLetterFilter.EndDate != null)
                {
                    CLetterFilter.StartDate = DateTime.ParseExact(CLetterFilter.StartDate, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    CLetterFilter.EndDate = DateTime.ParseExact(CLetterFilter.EndDate, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                }

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Supply", CLetterFilter.EnergySupply);
                //cmd.Parameters.AddWithValue("@RecordType", CLetterFilter.RecordType);
                cmd.Parameters.AddWithValue("@LetterType", CLetterFilter.LetterType);
                cmd.Parameters.AddWithValue("@StartDate", CLetterFilter.StartDate);
                cmd.Parameters.AddWithValue("@EndDate", CLetterFilter.EndDate);

                //cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                //cmd.Parameters["@result"].Direction = ParameterDirection.Output;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CustomerLetterData cst = new CustomerLetterData();
                    cst.RefID = Convert.ToInt32(rdr["RefID"].ToString());
                    cst.MPXN = rdr["MPXN"].ToString();
                    cst.Energy_Supply = rdr["Energy_Supply"].ToString();
                    cst.Initial_Contact = rdr["Initial_Contact"].ToString();
                    cst.RecievedDate = rdr["RecievedDate"].ToString();
                    cst.ICCD = rdr["ICCD"].ToString();
                    cst.Track_Code = rdr["Track_Code"].ToString();
                    cst.Title = rdr["Title"].ToString();
                    cst.initial = rdr["initial"].ToString();
                    cst.Surname = rdr["Surname"].ToString();
                    cst.Region = rdr["Region"].ToString();
                    cst.Address1 = rdr["Address1"].ToString();
                    cst.Address2 = rdr["Address2"].ToString();
                    cst.Address3 = rdr["Address3"].ToString();
                    cst.Address4 = rdr["Address4"].ToString();
                    cst.Address5 = rdr["Address5"].ToString();
                    cst.LetterCode = rdr["LetterCode"].ToString();
                    cst.D5_Letter_Code = rdr["D5_Letter_Code"].ToString();
                    cst.D5_Sent_Date = rdr["D5_Sent_Date"].ToString();//(DateTime?)(DateTime?)((rdr["D5_Sent_Date"] == DBNull.Value) ? null : rdr["D5_Sent_Date"]);
                    cst.D20_Letter_Code = rdr["D20_Letter_Code"].ToString();
                    cst.D20_Send_Date = rdr["D20_Send_Date"].ToString();// ((rdr["D20_Send_Date"] == DBNull.Value) ? null : rdr["D20_Send_Date"]);
                    cst.D20_Interim_Letter_Code = rdr["D20_Interim_Letter_Code"].ToString();
                    cst.D20_Interim_Send_Date = rdr["D20_Interim_Send_Date"].ToString(); //(DateTime?)((rdr["D20_Interim_Send_Date"] == DBNull.Value) ? null : rdr["D20_Interim_Send_Date"]);
                    cst.Code = rdr["Code"].ToString();
                    lst.Add(cst);

                }
                con.Close();

            }

            return lst;
        }

        /// <summary>
        /// AddLetterMaster
        /// </summary>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        public LetterMaster AddLetterMaster(LetterMaster letterMaster)
        {


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", "");
                cmd.Parameters.AddWithValue("@Code", letterMaster.LetterCode);
                cmd.Parameters.AddWithValue("@Description", letterMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", letterMaster.IsActive);
                //cmd.Parameters.AddWithValue("@EnergySupply", "");
                cmd.Parameters.AddWithValue("@Energy_Supply", letterMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", letterMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Letter");
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return letterMaster;
        }
        /// <summary>
        /// letter master
        /// </summary>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        public LetterMaster DeleteLetterMaster(LetterMaster letterMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", letterMaster.ID);
                cmd.Parameters.AddWithValue("@Code", letterMaster.LetterCode);
                cmd.Parameters.AddWithValue("@Description", letterMaster.Description);
                cmd.Parameters.AddWithValue("@Is_Active", letterMaster.IsActive);
                //cmd.Parameters.AddWithValue("@Energy_SupplyID", letterMaster.Energy_SupplyID);
                cmd.Parameters.AddWithValue("@Energy_Supply", letterMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", letterMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Letter");
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
            return letterMaster;

        }
        /// <summary>
        /// GetLetterMaster
        /// </summary>
        /// <returns></returns>
        public IEnumerable<LetterMaster> GetLetterMaster()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "Letter");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        LetterMaster letterMaster = new LetterMaster();
                        letterMaster.ID = Convert.ToInt32(rdr["ID"].ToString());
                        //letterMaster.LetterCode = rdr["Category"].ToString();// because category column have d20 etc.
                        letterMaster.LetterCode = rdr["LetterCode"].ToString();
                        letterMaster.Description = rdr["Description"].ToString();
                        letterMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        letterMaster.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                        // letterMaster.EnergySupply = rdr["EnergySupply"].ToString();
                        letterMasterList.Add(letterMaster);

                    }
                    con.Close();



                }
                return letterMasterList;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// GetLetterMasterById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public LetterMaster GetLetterMasterById(int id)
        {
            LetterMaster letterMaster = new LetterMaster();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@Calling_Type", "Letter");
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    letterMaster.ID = Convert.ToInt32(rdr["ID"].ToString());
                    letterMaster.LetterCode = rdr["LetterCode"].ToString();
                    letterMaster.Description = rdr["Description"].ToString();
                    letterMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                    letterMaster.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                    // letterMaster.EnergySupply = rdr["EnergySupply"].ToString();
                    letterMasterList.Add(letterMaster);

                }
                con.Close();


                return letterMaster;

            }
        }
        /// <summary>
        /// UpdateLetterMaster
        /// </summary>
        /// <param name="letterMaster"></param>
        /// <returns></returns>
        public LetterMaster UpdateLetterMaster(LetterMaster letterMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", letterMaster.ID);
                cmd.Parameters.AddWithValue("@Code", letterMaster.LetterCode);
                cmd.Parameters.AddWithValue("@Description", letterMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", letterMaster.IsActive);
                //cmd.Parameters.AddWithValue("@Energy_SupplyID", letterMaster.Energy_SupplyID);
                cmd.Parameters.AddWithValue("@Energy_Supply", letterMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", letterMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Letter");
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return letterMaster;
        }
    }
}


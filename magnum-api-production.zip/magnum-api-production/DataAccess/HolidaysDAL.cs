﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class HolidaysDAL : IHolidayMaster
    {
        static string connectionString;

        List<HolidaysMaster> holidaysList = new List<HolidaysMaster>();
        public HolidaysDAL(IConfiguration configuration)
        {
            connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetHolidays
        /// </summary>
        /// <returns></returns>
        public IEnumerable<HolidaysMaster> GetHolidays()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Ms_Master_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "Holiday");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        HolidaysMaster holidaysMaster = new HolidaysMaster();
                        holidaysMaster.ID = Convert.ToInt32(rdr["ID"].ToString());
                        holidaysMaster.Date = Convert.ToDateTime(rdr["Date"].ToString());

                        holidaysMaster.Description = rdr["Description"].ToString();
                        holidaysMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        holidaysList.Add(holidaysMaster);

                    }
                    con.Close();



                }
                return holidaysList;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// GetHolidaysByYear
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        HolidaysMaster IHolidayMaster.GetHolidaysByYear(DateTime year)
        {
            throw new NotImplementedException();
        }
    }
}

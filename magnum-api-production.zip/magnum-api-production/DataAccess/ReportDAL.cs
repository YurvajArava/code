using System;
using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ReportDAL : BaseDAL, IReport
    {
        //private string connectionString;
        public ReportDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }

        /// <summary>
        /// GetMonthlyReport
        /// </summary>
        /// <param name="objInput">MonthlyReportSearch Model</param>
        /// <returns>List of Data</returns>
        public IList<MonthlyReport> GetMonthlyReportData(MonthlyRptSearchModel objInput)
        {
            try
            {
                List<MonthlyReport> reportData = new List<MonthlyReport>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_MonthlyReport, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_FuelType", objInput.EnergySupplyId);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@I_StartDate", objInput.ICCDStartDate);
                    cmd.Parameters.AddWithValue("@I_EndDate", objInput.ICCDEndDate);
                    cmd.Parameters.AddWithValue("@P_LtrType", objInput.LetterTypeId);
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    con.Open();


                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            MonthlyReport objReport = new MonthlyReport();
                            objReport.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            objReport.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            objReport.DOT = DbDataHelper.GetNullableDateTime(rdr, "DOT");
                            objReport.CustomerType = DbDataHelper.GetString(rdr, "CustomerType");
                            objReport.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                            objReport.EnergySupply = DbDataHelper.GetString(rdr, "EnergySupply");
                            objReport.InitialContact = DbDataHelper.GetString(rdr, "Initial_Contact");
                            objReport.ContactMethod = DbDataHelper.GetString(rdr, "Contact_Method");
                            objReport.EtType = DbDataHelper.GetString(rdr, "ET_Type");
                            objReport.Origin = DbDataHelper.GetString(rdr, "Origin");
                            objReport.Region = DbDataHelper.GetString(rdr, "Region");
                            objReport.CustomerName = DbDataHelper.GetString(rdr, "ContactName");
                            //objReport.Address = DbDataHelper.GetString(rdr, "Address");
                            objReport.CallerName = DbDataHelper.GetString(rdr, "Caller_Name");
                            objReport.HomeTel = DbDataHelper.GetString(rdr, "HomeTeL");
                            objReport.ContactTel = DbDataHelper.GetString(rdr, "ContactTel");
                            objReport.C1Reference = DbDataHelper.GetString(rdr, "C1_Reference");
                            objReport.PaymentMethod = DbDataHelper.GetString(rdr, "Payment_Method");
                            objReport.SalesRepId = DbDataHelper.GetString(rdr, "Sales_Rep_Id");
                            objReport.CancellationReasonId = DbDataHelper.GetNullableInt(rdr, "Cancellation_Reason");
                            objReport.CancellationReason = DbDataHelper.GetString(rdr, "CanCategory");
                            objReport.CancellationReasonSubCategory = DbDataHelper.GetString(rdr, "Cancellation_Reason_SubCategory");
                            objReport.CancellationReasonSubCategory = DbDataHelper.GetString(rdr, "SubCanCategory");
                            objReport.Supplier = DbDataHelper.GetString(rdr, "Supplier");
                            objReport.OtherSupplier = DbDataHelper.GetString(rdr, "OtherSupplier");
                            objReport.IoContactName = DbDataHelper.GetString(rdr, "IO_Contact_Name");
                            objReport.ReadingType = DbDataHelper.GetString(rdr, "ReadingType");
                            objReport.ReasonforReturn = DbDataHelper.GetString(rdr, "Reason_for_Return");
                            objReport.Status = DbDataHelper.GetString(rdr, "Status");
                            objReport.AssociatedOrganisationId = DbDataHelper.GetString(rdr, "Associated_Organisation_ID");
                            objReport.RoContactName = DbDataHelper.GetString(rdr, "RO_Contact_Name");
                            objReport.MeterSerialNumber = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                            objReport.MeterReading = DbDataHelper.GetString(rdr, "Meter_Reading");
                            objReport.MeterReadingType= DbDataHelper.GetString(rdr, "Meter_Reading_Type");
                            objReport.MeterReadingDate = DbDataHelper.GetString(rdr, "Meter_Reading_Date");
                            objReport.MeterRegisterId = DbDataHelper.GetString(rdr, "Meter_Register_ID");
                            objReport.RecordRejectionAcceptanceCode = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                            objReport.BgComments = DbDataHelper.GetString(rdr, "BG_Comments");
                            objReport.LetterCode = DbDataHelper.GetString(rdr, "LetterCode");
                           // objReport.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
                            objReport.FileName = DbDataHelper.GetString(rdr, "FileName");
                            objReport.TrackCode = DbDataHelper.GetString(rdr, "Track_Code");
                            objReport.WithEffDate = DbDataHelper.GetString(rdr, "WithEffDate");
                            objReport.EffSettDate = DbDataHelper.GetNullableDateTime(rdr, "EffSettDate");
                            objReport.ESRSStatus = DbDataHelper.GetString(rdr, "ESRSStatus");
                            objReport.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                            objReport.StageCode = DbDataHelper.GetString(rdr, "StageCode");
                            objReport.Stage = DbDataHelper.GetString(rdr, "Stage");
                            objReport.IsActive = DbDataHelper.GetBoolean(rdr, "IsActive");
                            objReport.MKTFLAG = DbDataHelper.GetString(rdr, "MKT_FLAG");
                            objReport.MKTFileName = DbDataHelper.GetString(rdr, "MKT_FileName");
                            objReport.ThreadCode = DbDataHelper.GetString(rdr, "ThreadCode");
                            objReport.ResponseReceived = DbDataHelper.GetString(rdr, "ResponseReceived");
                            objReport.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                            objReport.CompensationAgreed = DbDataHelper.GetString(rdr, "Compensation_Agreed");
                            objReport.FailedQuality = DbDataHelper.GetBoolean(rdr, "FailedQuality");
                            objReport.FinalRead = DbDataHelper.GetString(rdr, "FinalRead");
                            objReport.NSSAccRef = DbDataHelper.GetString(rdr, "NSS_Acc_Ref");
                            objReport.NSSInputDate = DbDataHelper.GetNullableDateTime(rdr, "NSS_Input_Date");
                            objReport.AgentId = DbDataHelper.GetString(rdr, "Agent_Id");
                            objReport.PaymentMethod = DbDataHelper.GetString(rdr, "Payment_Method");
                            objReport.PromotionalReference = DbDataHelper.GetString(rdr, "Promotional_Reference");
                            objReport.SalesRepId = DbDataHelper.GetString(rdr, "Sales_Rep_Id");
                            objReport.SalesChannel = DbDataHelper.GetString(rdr, "Sales_Channel");
                            objReport.SalesLocation = DbDataHelper.GetString(rdr, "Sales_Location");
                            objReport.System = DbDataHelper.GetString(rdr, "System");
                            objReport.D20SendDate = DbDataHelper.GetNullableDateTime(rdr, "D20_Send_Date");
                            objReport.D20InterimSendDate = DbDataHelper.GetNullableDateTime(rdr, "D20_Interim_Send_Date");
                            objReport.D5SendDate = DbDataHelper.GetNullableDateTime(rdr, "D5_Sent_Date");
                            objReport.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                            objReport.Title = DbDataHelper.GetString(rdr, "Title");
                            objReport.Initial = DbDataHelper.GetString(rdr, "Initial");
                            objReport.SurName = DbDataHelper.GetString(rdr, "SurName");
                            objReport.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            objReport.Address2 = DbDataHelper.GetString(rdr, "Address2");
                            objReport.Address3 = DbDataHelper.GetString(rdr, "Address3");
                            objReport.Address4 = DbDataHelper.GetString(rdr, "Address4");
                            objReport.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            objReport.UpdatedBy = DbDataHelper.GetString(rdr, "UpdatedBy");
                            objReport.UpdatedOn = DbDataHelper.GetNullableDateTime(rdr, "UpdatedOn");
                            objReport.BusinessPartner = DbDataHelper.GetString(rdr, "Business_partner");
                            objReport.SalesOrderDesc = DbDataHelper.GetString(rdr, "SalesOrderDesc");
                            objReport.PremiseNumber = DbDataHelper.GetString(rdr, "PremiseNumber");
                            objReport.RecordInError = DbDataHelper.GetBoolean(rdr, "RecordInError");
                            objReport.InitsuppId = DbDataHelper.GetString(rdr, "InitSuppID");
                            objReport.CancellationReasonAdditionalInfo = DbDataHelper.GetString(rdr, "Cancellation_Reason_Additional_Info");
                            objReport.CSENameVerbal = DbDataHelper.GetString(rdr, "CSE_Name_Verbal");
                            objReport.GasTransporter = DbDataHelper.GetString(rdr, "Gas_Transporter");
                            objReport.InitOrgId = DbDataHelper.GetString(rdr, "InitOrgID");
                            objReport.ReferenceNumber = DbDataHelper.GetString(rdr, "Reference_Number");
                            reportData.Add(objReport);
                        }
                    }
                    con.Close();

                }
                return reportData;
            }
            catch
            {
                throw;
            }
        }


        public IList<WeeklyReport> GetWeeklyReportDataOutstanding(WeeklyRptSearchModel objInput)
        {
        try
        {
        List<WeeklyReport> reportData = new List<WeeklyReport>();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
        // SqlCommand cmd = new SqlCommand("Usp_Weekly_Report", con);
        SqlCommand cmd = new SqlCommand("Usp_Weekly_Report_New", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
        cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
        cmd.Parameters.AddWithValue("@ThreadType", objInput.ThreadType);
        con.Open();




        using (IDataReader rdr = cmd.ExecuteReader())
        {
        while (rdr.Read())
        {
        WeeklyReport objReport = new WeeklyReport();



        objReport.MPXN = DbDataHelper.GetString(rdr, "MPXN");
        objReport.ThreadCode = DbDataHelper.GetString(rdr, "ThreadCode");
        //objReport.TotalEt = DbDataHelper.GetNullableInt(rdr, "TotalEt");
        // objReport.WReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
        objReport.WReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "ReceivedDate");
        // objReport.WReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "ReceivedDate");
        reportData.Add(objReport);
        }
        }
        con.Close();



        }
        return reportData;
        }
        catch (Exception ex)
        {
        throw;
        }
        }


        /// <summary>
        /// GetWeeklyReport
        /// </summary>
        /// <param name="objInput">WeeklyReportSearch Model</param>
        /// <returns>List of Data</returns>
        public IList<WeeklyReport> GetWeeklyReportData(WeeklyRptSearchModel objInput)
        {
        try
        {
        List<WeeklyReport> reportData = new List<WeeklyReport>();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
        // SqlCommand cmd = new SqlCommand("Usp_Weekly_Report", con);
        SqlCommand cmd = new SqlCommand("Usp_Weekly_Report_New", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
        cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
        cmd.Parameters.AddWithValue("@ThreadType", objInput.ThreadType);
        con.Open();

        using (IDataReader rdr = cmd.ExecuteReader())
        {
        while (rdr.Read())
        {
       WeeklyReport objReport = new WeeklyReport();



//objReport.MPXN = DbDataHelper.GetString(rdr, "MPXN");
objReport.ThreadCode = DbDataHelper.GetString(rdr, "ThreadCode");
objReport.TotalEt = DbDataHelper.GetInt(rdr, "TotalEt");
// objReport.WReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
// objReport.WReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "ReceivedDate");
reportData.Add(objReport);
        }
        }
        con.Close();



        }
        return reportData;
        }
        catch(Exception ex)
        {
        throw;
        }
        }
        public IList<CompensationReport> CompensationReport(CompSearch objInput)
        {
            try
            {
                List<CompensationReport> reportData = new List<CompensationReport>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.sp_CompensationData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@P_Type", objInput.CompType);
                    con.Open();


                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            CompensationReport objReport = new CompensationReport();
                            objReport.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            objReport.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                            objReport.EnergySupply = DbDataHelper.GetString(rdr, "Product");
                            objReport.InitiatedBy = DbDataHelper.GetString(rdr, "InitiatedBy");
                            objReport.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                            objReport.DOT = DbDataHelper.GetNullableDateTime(rdr, "DOT");
                            objReport.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                            objReport.FileSendDate = DbDataHelper.GetNullableDateTime(rdr, "FileSendDate");
                            objReport.Status = DbDataHelper.GetString(rdr, "Status");
                            objReport.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                            objReport.ContractAccount = DbDataHelper.GetString(rdr, "ContractAccount");
                            objReport.BusinessPartner = DbDataHelper.GetString(rdr, "BusinessPartner");
                            objReport.SupplierCode = DbDataHelper.GetString(rdr, "SupplierCode");
                            objReport.ETType = DbDataHelper.GetString(rdr, "ETType");
                            objReport.ReasonforReturn = DbDataHelper.GetString(rdr, "ReasonforReturn");
                            objReport.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                            objReport.SSD = DbDataHelper.GetString(rdr, "SSD");
                            objReport.SalesOrderDesc = DbDataHelper.GetString(rdr,"SalesOrderDesc");
                            objReport.CompensationDate = DbDataHelper.GetNullableDateTime(rdr, "CompensationDate");
                            objReport.CompGivenStatus = DbDataHelper.GetString(rdr, "CompGivenStatus");
                            objReport.SdepResponseRecd = DbDataHelper.GetNullableDateTime(rdr, "SdepResponseRecd");
                            objReport.SdepName = DbDataHelper.GetString(rdr, "SdepName");
                            objReport.SdepAddress= DbDataHelper.GetString(rdr, "SdepAddress");
                            objReport.D5followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D5_FollowUp_SendDate");
                            objReport.D10followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D10_FollowUp_SendDate");
                            objReport.D15followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D15_FollowUp_SendDate");

                            objReport.Title = DbDataHelper.GetString(rdr, "Title");
                            objReport.Initial = DbDataHelper.GetString(rdr, "Initial");
                            objReport.SurName = DbDataHelper.GetString(rdr, "SurName");
                            objReport.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            objReport.Address2 = DbDataHelper.GetString(rdr, "Address2");
                            objReport.Address3 = DbDataHelper.GetString(rdr, "Address3");
                            objReport.Address4 = DbDataHelper.GetString(rdr, "Address4");
                            objReport.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            objReport.UpdatedBy = DbDataHelper.GetString(rdr, "UpdatedBy");
                            objReport.UpdatedOn = DbDataHelper.GetDateTime(rdr, "UpdatedOn");
                            reportData.Add(objReport);
                        }
                    }
                    con.Close();

                }
                return reportData;
            }
            catch
            {
                throw;
            }
        }
    }
}

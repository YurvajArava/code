﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ReasonMasterDAL : BaseDAL, IReasonMaster
    {
        //static string connectionString;

        List<ReasonMaster> reasonMastersList = new List<ReasonMaster>();
        public ReasonMasterDAL(IConfiguration configuration) : base(configuration)
        {
            // connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// AddReasonMaster
        /// </summary>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        public ReasonMaster AddReasonMaster(ReasonMaster reasonMaster)
        {


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", reasonMaster.MID);
                cmd.Parameters.AddWithValue("@Code", reasonMaster.Code);
                cmd.Parameters.AddWithValue("@Description", reasonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", reasonMaster.IsActive);
                cmd.Parameters.AddWithValue("@UserId", reasonMaster.UserId);
                cmd.Parameters.AddWithValue("@Energy_Supply", reasonMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@Calling_Type", "REASON_RETURN");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return reasonMaster;
        }
        /// <summary>
        /// DeleteReasonMaster
        /// </summary>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        public ReasonMaster DeleteReasonMaster(ReasonMaster reasonMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", reasonMaster.MID);
                cmd.Parameters.AddWithValue("@Code", reasonMaster.Code);

                cmd.Parameters.AddWithValue("@Description", reasonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", reasonMaster.IsActive);
                cmd.Parameters.AddWithValue("@UserId", reasonMaster.UserId);
                cmd.Parameters.AddWithValue("@Energy_Supply", reasonMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@Calling_Type", "REASON_RETURN");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
            return reasonMaster;

        }
        /// <summary>
        /// GetReasonMaster
        /// </summary>
        /// <returns></returns>

        public IEnumerable<ReasonMaster> GetReasonMaster()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "REASON_RETURN");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        ReasonMaster reason = new ReasonMaster();
                        reason.MID = Convert.ToInt32(rdr["ID"].ToString());
                        reason.Code = rdr["Code"].ToString();

                        reason.Description = rdr["Description"].ToString();
                        reason.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        reason.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());

                        reasonMastersList.Add(reason);

                    }
                    con.Close();



                }
                return reasonMastersList;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// GetReasonMasterById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ReasonMaster GetReasonMasterById(int id)
        {
            ReasonMaster reasonMaster = new ReasonMaster();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@Calling_Type", "REASON_RETURN");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        int ID = rdr.GetInt32(0);
                        if (ID == id)
                        {
                            reasonMaster.MID = Convert.ToInt32(rdr["ID"].ToString());
                            reasonMaster.Code = rdr["Code"].ToString();

                            reasonMaster.Description = rdr["Description"].ToString();
                            reasonMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                            reasonMaster.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                            reasonMaster.EnergySupplies = new[]
        {
      new SelectListItem { Value = "1", Text = "GAS" },
     new SelectListItem { Value = "2", Text = "Electricity" },

  };

                        }
                        con.Close();

                        return reasonMaster;
                    }
                    return reasonMaster;
                }
            }
            catch
            {
                throw;

            }
        }
        /// <summary>
        /// UpdateReasonMaster
        /// </summary>
        /// <param name="reasonMaster"></param>
        /// <returns></returns>
        public ReasonMaster UpdateReasonMaster(ReasonMaster reasonMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string @Result = "";
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", reasonMaster.MID);
                cmd.Parameters.AddWithValue("@Code", reasonMaster.Code);

                cmd.Parameters.AddWithValue("@Description", reasonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", reasonMaster.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", reasonMaster.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", reasonMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "REASON_RETURN");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                @Result = (string)cmd.Parameters["@Result"].Value;
            }
            return reasonMaster;
        }
    }
}


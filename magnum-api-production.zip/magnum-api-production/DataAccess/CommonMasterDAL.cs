﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class CommonMasterDAL : BaseDAL, ICommonMaster
    {
        //static string connectionString;

        List<CommonMaster> commonMasterList = new List<CommonMaster>();
        public CommonMasterDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// AddCommonMaster
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        public CommonMaster AddCommonMaster(CommonMaster commonMaster)
        {


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", commonMaster.ID);
                cmd.Parameters.AddWithValue("@Type", commonMaster.Type);
                cmd.Parameters.AddWithValue("@Value", commonMaster.Value);
                cmd.Parameters.AddWithValue("@Description", commonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", commonMaster.IsActive);
                cmd.Parameters.AddWithValue("@UserId", commonMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Common");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return commonMaster;
        }
        /// <summary>
        /// common
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        public CommonMaster DeleteCommonMaster(CommonMaster commonMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", commonMaster.ID);
                cmd.Parameters.AddWithValue("@Type", commonMaster.Type);
                cmd.Parameters.AddWithValue("@Value", commonMaster.Value);
                cmd.Parameters.AddWithValue("@Description", commonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", commonMaster.IsActive);
                cmd.Parameters.AddWithValue("@UserId", commonMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Common");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
            return commonMaster;

        }
        /// <summary>
        /// GetCommonMaster
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CommonMaster> GetCommonMaster()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "Common");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CommonMaster commonMaster = new CommonMaster();
                        commonMaster.ID = Convert.ToInt32(rdr["ID"].ToString());
                        commonMaster.Type = rdr["Type"].ToString();
                        commonMaster.Value = rdr["Value"].ToString();
                        commonMaster.Description = rdr["Description"].ToString();
                        commonMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        commonMaster.EnergySupply = DbDataHelper.GetInt(rdr, "Energy_Supply");
                        commonMasterList.Add(commonMaster);

                    }
                    con.Close();



                }
                return commonMasterList;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// GetCommonMasterById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CommonMaster GetCommonMasterById(int id)
        {
            CommonMaster commonMaster = new CommonMaster();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@Calling_Type", "Common");
                //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {

                    commonMaster.ID = Convert.ToInt32(rdr["ID"].ToString());
                    commonMaster.Type = rdr["Type"].ToString();
                    commonMaster.Value = rdr["Value"].ToString();
                    commonMaster.Description = rdr["Description"].ToString();
                    commonMaster.IsActive = Convert.ToBoolean(rdr["IsActive"]);

                    commonMaster.Types = new[]
                                {
                        new SelectListItem { Value = "EnergySupply", Text = "EnergySupply" },
                        new SelectListItem { Value = "PaymentMethod", Text = "PaymentMethod" },
                  };
                }
                con.Close();

                return commonMaster;

            }

        }
        /// <summary>
        /// UpdateCommonMaster
        /// </summary>
        /// <param name="commonMaster"></param>
        /// <returns></returns>
        public CommonMaster UpdateCommonMaster(CommonMaster commonMaster)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", commonMaster.ID);
                cmd.Parameters.AddWithValue("@Value", commonMaster.Value);
                cmd.Parameters.AddWithValue("@Type", commonMaster.Type);
                //cmd.Parameters.AddWithValue("@Value", commonMaster.Value);
                cmd.Parameters.AddWithValue("@Description", commonMaster.Description);
                cmd.Parameters.AddWithValue("@IsActive", commonMaster.IsActive);
                cmd.Parameters.AddWithValue("@UserId", commonMaster.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Common");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return commonMaster;
        }
    }
}

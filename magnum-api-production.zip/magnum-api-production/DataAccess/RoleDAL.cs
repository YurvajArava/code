﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class RoleDAL : BaseDAL, IRoles
    {
        //private string connectionString;
        public RoleDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }


        /// <summary>
        /// GetAllRoles
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Roles> GetAllRoles()
        {
            try
            {
                List<Roles> lstroles = new List<Roles>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_RolesAction", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RoleID", "");
                    cmd.Parameters.AddWithValue("@RoleName", "");
                    cmd.Parameters.AddWithValue("@Description", "");
                    cmd.Parameters.AddWithValue("@IsActive", "");
                    cmd.Parameters.AddWithValue("@ActionType", "");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Roles roles = new Roles();
                        roles.RoleID = Convert.ToInt32(rdr["RoleID"]);
                        roles.RoleName = rdr["RoleName"].ToString();
                        roles.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        roles.Description = rdr["Description"].ToString();
                        lstroles.Add(roles);

                    }
                    con.Close();

                }
                return lstroles;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// AddRoles
        /// </summary>
        /// <param name="tbl_roles"></param>
        /// <returns></returns>
        public string AddRoles(Roles tbl_roles)
        {
            try
            {
                string @Result = string.Empty;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_RolesAction", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RoleID", tbl_roles.RoleID);
                    cmd.Parameters.AddWithValue("@RoleName", tbl_roles.RoleName);
                    cmd.Parameters.AddWithValue("@IsActive", tbl_roles.IsActive);
                    cmd.Parameters.AddWithValue("@Description", tbl_roles.Description);
                    cmd.Parameters.AddWithValue("@ActionType", "Insert");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;

                }
                return @Result;
            }
            catch
            {
                throw;
            }
        }

        public string UpdateRoles(Roles tbl_roles)
        {
            try
            {
                string @Result = string.Empty;

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_RolesAction", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RoleID", tbl_roles.RoleID);
                    cmd.Parameters.AddWithValue("@RoleName", tbl_roles.RoleName);
                    cmd.Parameters.AddWithValue("@Description", tbl_roles.Description);
                    cmd.Parameters.AddWithValue("@IsActive", tbl_roles.IsActive);
                    cmd.Parameters.AddWithValue("@ActionType", "Update");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;

                }
                return @Result;
            }
            catch
            {
                throw;
            }
        }
        public string DeleteRoles(int RoleID)
        {
            try
            {
                string @Result = string.Empty;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_RolesAction", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RoleID", RoleID);
                    cmd.Parameters.AddWithValue("@RoleName", "");
                    cmd.Parameters.AddWithValue("@IsActive", "");
                    cmd.Parameters.AddWithValue("@Description", "");
                    cmd.Parameters.AddWithValue("@ActionType", "Delete");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;

                }
                return @Result;
            }
            catch
            {
                throw;
            }
        }
    }
}

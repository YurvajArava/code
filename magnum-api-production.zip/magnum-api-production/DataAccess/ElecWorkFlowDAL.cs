﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ElecWorkFlowDAL : BaseDAL, IElecWorkFlow
    {

        //private string connectionString;
        public ElecWorkFlowDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetElecData
        /// </summary>
        /// <param name="Mpan"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
      /*  public IEnumerable<ElecticityWorkFlowModel> GetElecData(ElecSearchCriteria objInput)
        {
            try
            {
                List<ElecticityWorkFlowModel> lstelecdata = new List<ElecticityWorkFlowModel>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {


                    SqlCommand cmd = new SqlCommand(DbConstants.sp_GetElectricityData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Mpan", objInput.MPAN);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_ICCD", objInput.ICCD);
                    cmd.Parameters.AddWithValue("@P_SupplierCode", objInput.SupplierCode);
                    cmd.Parameters.AddWithValue("@P_StageCode", objInput.StageCode);
                    con.Open();
                    SqlCommand cmd = new SqlCommand(DbConstants.sp_GetElectricityData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MPRN", objInput.MPAN);
                    cmd.Parameters.AddWithValue("@Energy", objInput.Energy);
                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@ICCD", objInput.ICCD);
                    cmd.Parameters.AddWithValue("@SupplierCode", objInput.SupplierCode);
                    cmd.Parameters.AddWithValue("@StageCode", objInput.StageCode);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                    
                       ElecticityWorkFlowModel elecmodel = new ElecticityWorkFlowModel();
                        elecmodel.RefId = Convert.ToInt32(rdr["RefID"]);
                        elecmodel.EnergySupply = rdr["Energy_Supply"].ToString();
                        elecmodel.BatchIdentifier = rdr["Batch_Identifier"].ToString();
                        elecmodel.MPAN = DbDataHelper.GetString(rdr, "MPAN");
                        elecmodel.HouseNumber = rdr["House_Number"].ToString();
                        elecmodel.StreetName = rdr["Street_Name"].ToString();
                        elecmodel.PostCode = rdr["PostCode"].ToString();
                        elecmodel.EffectiveFromSettlementDateForNewSupplier = DbDataHelper.GetDateTimeToString(rdr, "Effective_From_Settlement_Date_For_New_Supplier");
                        elecmodel.InitialCustomerContactDate = DbDataHelper.GetDateTimeToString(rdr, "Initial_Customer_Contact_Date");
                        elecmodel.InitiatingSupplierId = rdr["Initiating_Supplier_Id"].ToString();
                        elecmodel.AssociatedSupplierId = rdr["Associated_Supplier_Id"].ToString();
                        elecmodel.CustomerName = rdr["Customer_Name"].ToString();
                        elecmodel.CustomerTelephoneNumber = rdr["Customer_Telephone_Number"].ToString();
                        elecmodel.CustomerRequestsNoContact = rdr["Customer_Requests_No_Contact"].ToString();
                        elecmodel.ReasonForReturn = rdr["Reason_For_Return"].ToString();
                        elecmodel.StatusForErroneousTransfer = rdr["Status_of_Erroneous_Transfer"].ToString();
                        elecmodel.AdditionalInformation = rdr["Additional_Information"].ToString();
                        elecmodel.MeterSerialNumber = rdr["Meter_Serial_Number"].ToString();
                        elecmodel.MeterReadingType = rdr["Meter_Reading_Type"].ToString();
                        elecmodel.MeterReadingId = rdr["Meter_Register_Id"].ToString();
                        elecmodel.MeterReadingDate = rdr["Meter_Reading_Date"].ToString(); //DbDataHelper.GetDateTimeToString(rdr, "Meter_Reading_Date");
                        elecmodel.MeterReading = rdr["Meter_Reading"].ToString();
                        elecmodel.FileReceivedDate = DbDataHelper.GetDateTimeToString(rdr, "File_Received_Date");
                        elecmodel.StageCode = rdr["StageCode"].ToString();
                        elecmodel.Stage = rdr["Stage"].ToString();
                        elecmodel.Duplicate = DbDataHelper.GetBoolean(rdr, "Duplicate");
                        elecmodel.CreatedBy = rdr["CreatedBy"].ToString();
                        elecmodel.CreatedOn = DbDataHelper.GetDateTimeToString(rdr, "CreatedOn");
                        elecmodel.UpdatedBy = rdr["UpdatedBy"].ToString();
                        if (rdr["UpdatedOn"] != DBNull.Value)
                        {
                            elecmodel.UpdatedOn = DbDataHelper.GetDateTimeToString(rdr, "UpdatedOn");//Convert.ToDateTime(rdr["UpdatedOn"]);
                        }

                        elecmodel.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        ElecticityWorkFlowModel elecmodel = new ElecticityWorkFlowModel();
                        elecmodel.RefId = Convert.ToInt32(rdr["RefID"]);
                        elecmodel.MPAN = DbDataHelper.GetString(rdr, "MPAN");
                        elecmodel.EnergySupply = rdr["Energy_Supply"].ToString();
                        elecmodel.BatchIdentifier = rdr["Batch_Identifier"].ToString();
                        elecmodel.MPAN = DbDataHelper.GetString(rdr, "MPAN");
                        elecmodel.HouseNumber = rdr["House_Number"].ToString();
                        elecmodel.StreetName = rdr["Street_Name"].ToString();
                        elecmodel.PostCode = rdr["PostCode"].ToString();
                        elecmodel.EffectiveFromSettlementDateForNewSupplier = DbDataHelper.GetNullableDateTime(rdr, "Effective_From_Settlement_Date_For_New_Supplier");
                        elecmodel.InitialCustomerContactDate = DbDataHelper.GetNullableDateTime(rdr, "Initial_Customer_Contact_Date");
                        elecmodel.InitiatingSupplierId = rdr["Initiating_Supplier_Id"].ToString();
                        elecmodel.AssociatedSupplierId = rdr["Associated_Supplier_Id"].ToString();
                        elecmodel.CustomerName = rdr["Customer_Name"].ToString();
                        elecmodel.CustomerTelephoneNumber = rdr["Customer_Telephone_Number"].ToString();
                        elecmodel.CustomerRequestsNoContact = rdr["Customer_Requests_No_Contact"].ToString();
                        elecmodel.ReasonForReturn = rdr["Reason_For_Return"].ToString();
                        elecmodel.StatusForErroneousTransfer = rdr["Status_of_Erroneous_Transfer"].ToString();
                        elecmodel.AdditionalInformation = rdr["Additional_Information"].ToString();
                        elecmodel.MeterSerialNumber = rdr["Meter_Serial_Number"].ToString();
                        elecmodel.MeterReadingType = rdr["Meter_Reading_Type"].ToString();
                        elecmodel.MeterReadingId = rdr["Meter_Register_Id"].ToString();
                        //elecmodel.MeterReadingDate = rdr["Meter_Reading_Date"].ToString(); //DbDataHelper.GetDateTimeToString(rdr, "Meter_Reading_Date");
                        elecmodel.MeterReadingDate = DbDataHelper.GetNullableDateTime(rdr, "Meter_Reading_Date");
                        elecmodel.MeterReading = rdr["Meter_Reading"].ToString();
                        elecmodel.FileReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "File_Received_Date");
                        elecmodel.StageCode = rdr["StageCode"].ToString();
                        elecmodel.Stage = rdr["Stage"].ToString();
                        elecmodel.Duplicate = DbDataHelper.GetBoolean(rdr, "Duplicate");
                        elecmodel.CreatedBy = rdr["CreatedBy"].ToString();
                        elecmodel.CreatedOn = DbDataHelper.GetNullableDateTime(rdr, "CreatedOn");
                        elecmodel.UpdatedBy = rdr["UpdatedBy"].ToString();
                        if (rdr["UpdatedOn"] != DBNull.Value)
                        {
                            elecmodel.UpdatedOn = DbDataHelper.GetNullableDateTime(rdr, "UpdatedOn");//Convert.ToDateTime(rdr["UpdatedOn"]);
                        }

                        elecmodel.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        //lstelecdata.Add(elecmodel);
                       lstelecdata.Add(elecmodel);

                    }

                    con.Close();

                }
                return lstelecdata;
            }
            catch (Exception ex)
            {
                ex.ToString();
                return null;
            }

        }*/
        
        public IEnumerable<ElecticityWorkFlowModel> GetElecData(ElecSearchCriteria objInput)
{
try
{
List<ElecticityWorkFlowModel> lstelecdata = new List<ElecticityWorkFlowModel>();
using (SqlConnection con = new SqlConnection(connectionString))
{




// SqlCommand cmd = new SqlCommand(DbConstants.sp_GetElectricityData, con);
SqlCommand cmd = new SqlCommand("usp_GetElecGasOSROSIData", con);
//SqlCommand cmd = new SqlCommand("Usp_USR_Getdata", con);
cmd.CommandType = CommandType.StoredProcedure;
//cmd.Parameters.AddWithValue("@P_Mpan", objInput.MPAN);
//cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
//cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
//cmd.Parameters.AddWithValue("@P_ICCD", objInput.ICCD);
//cmd.Parameters.AddWithValue("@P_SupplierCode", objInput.SupplierCode);
//cmd.Parameters.AddWithValue("@P_StageCode", objInput.StageCode);
cmd.Parameters.AddWithValue("@MPRN", objInput.MPAN);
cmd.Parameters.AddWithValue("@Energy", "Elec");
cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
cmd.Parameters.AddWithValue("@ICCD", objInput.ICCD);
cmd.Parameters.AddWithValue("@SupplierCode", objInput.SupplierCode);
cmd.Parameters.AddWithValue("@StageCode", objInput.StageCode);
con.Open();
SqlDataReader rdr = cmd.ExecuteReader();
while (rdr.Read())
{
ElecticityWorkFlowModel elecmodel = new ElecticityWorkFlowModel();
elecmodel.RefId = Convert.ToInt32(rdr["RefID"]);
elecmodel.EnergySupply = rdr["Energy_Supply"].ToString();
elecmodel.BatchIdentifier = rdr["Batch_Identifier"].ToString();
elecmodel.MPAN = DbDataHelper.GetString(rdr, "MPAN");
elecmodel.HouseNumber = rdr["House_Number"].ToString();
elecmodel.StreetName = rdr["Street_Name"].ToString();
elecmodel.PostCode = rdr["PostCode"].ToString();
elecmodel.EffectiveFromSettlementDateForNewSupplier = DbDataHelper.GetDateTimeToString(rdr, "Effective_From_Settlement_Date_For_New_Supplier");
elecmodel.InitialCustomerContactDate = DbDataHelper.GetDateTimeToString(rdr, "Initial_Customer_Contact_Date");
elecmodel.InitiatingSupplierId = rdr["Initiating_Supplier_Id"].ToString();
elecmodel.AssociatedSupplierId = rdr["Associated_Supplier_Id"].ToString();
elecmodel.CustomerName = rdr["Customer_Name"].ToString();
elecmodel.Et_Type = DbDataHelper.GetString(rdr, "Et_Type");
elecmodel.CustomerTelephoneNumber = rdr["Customer_Telephone_Number"].ToString();
elecmodel.CustomerRequestsNoContact = rdr["Customer_Requests_No_Contact"].ToString();
elecmodel.ReasonForReturn = rdr["Reason_For_Return"].ToString();
elecmodel.StatusForErroneousTransfer = rdr["Status_of_Erroneous_Transfer"].ToString();
elecmodel.AdditionalInformation = rdr["Additional_Information"].ToString();
elecmodel.MeterSerialNumber = rdr["Meter_Serial_Number"].ToString();
elecmodel.MeterReadingType = rdr["Meter_Reading_Type"].ToString();
elecmodel.MeterReadingId = rdr["Meter_Register_Id"].ToString();
elecmodel.MeterReadingDate = rdr["Meter_Reading_Date"].ToString(); //DbDataHelper.GetDateTimeToString(rdr, "Meter_Reading_Date");
elecmodel.MeterReading = rdr["Meter_Reading"].ToString();
elecmodel.FileReceivedDate = DbDataHelper.GetDateTimeToString(rdr, "File_Received_Date");
elecmodel.StageCode = rdr["StageCode"].ToString();
elecmodel.Stage = rdr["Stage"].ToString();
elecmodel.Duplicate = DbDataHelper.GetBoolean(rdr, "Duplicate");
elecmodel.CreatedBy = rdr["CreatedBy"].ToString();
elecmodel.CreatedOn = DbDataHelper.GetDateTimeToString(rdr, "CreatedOn");
elecmodel.UpdatedBy = rdr["UpdatedBy"].ToString();
if (rdr["UpdatedOn"] != DBNull.Value)
{
elecmodel.UpdatedOn = DbDataHelper.GetDateTimeToString(rdr, "UpdatedOn");//Convert.ToDateTime(rdr["UpdatedOn"]);
}



elecmodel.IsActive = Convert.ToBoolean(rdr["IsActive"]);
lstelecdata.Add(elecmodel);



}



con.Close();



}
return lstelecdata;
}
catch (Exception ex)
{
ex.ToString();
return null;
}



}
        
        

        public string UpdateElecticityWorkFlow(List<ElectircityWorkFlowUpdate> data)
        {
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_USR_DataSanity", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Value", json);
                    cmd.Parameters.AddWithValue("@UserId", 101);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return null;
                }
            }
            catch
            {
                throw;
            }
        }

    }
}

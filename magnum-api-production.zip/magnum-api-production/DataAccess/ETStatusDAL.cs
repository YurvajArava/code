﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ETStatusDAL : BaseDAL, IETStatus
    {
        //private string connectionString;
        public ETStatusDAL(IConfiguration configuration) : base(configuration)
        {
            // connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetAllETStatus
        /// </summary>
        /// <returns></returns>
        public List<ETStatusModel> GetAllETStatus()
        {
            try
            {
                List<ETStatusModel> lstetstatus = new List<ETStatusModel>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "STATUS");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        ETStatusModel etsmodel = new ETStatusModel();
                        etsmodel.ID = Convert.ToInt32(rdr["ID"]);
                        etsmodel.Code = rdr["Code"].ToString();
                        etsmodel.Description = rdr["Description"].ToString();
                        etsmodel.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        etsmodel.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"]);
                        lstetstatus.Add(etsmodel);

                    }

                    con.Close();

                }
                return lstetstatus;
            }
            catch
            {
                throw;
            }

        }


        /// <summary>
        /// GetETStatusById
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public ETStatusModel GetETStatusById(int Id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    ETStatusModel statusdata = new ETStatusModel();
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.Parameters.AddWithValue("@Calling_Type", "STATUS");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        int ID = rdr.GetInt32(0);

                        if (ID == Id)
                        {
                            statusdata.ID = Convert.ToInt32(rdr["ID"]);
                            statusdata.Code = rdr["Code"].ToString();
                            statusdata.Description = rdr["Description"].ToString();
                            statusdata.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                            statusdata.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"]);
                            //statusdata.Energy_Supply = Convert.ToInt32 (rdr["Energy_Supply"]);
                            statusdata.EnergySupplies = new[]
{
        new SelectListItem { Value = "1", Text = "GAS" },
     new SelectListItem { Value = "2", Text = "Electricity" },

  };

                        }

                        con.Close();
                        return statusdata;
                    }
                    return statusdata;
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// AddETStatus
        /// </summary>
        /// <param name="Master"></param>
        /// <returns></returns>
        public ETStatusModel AddETStatus(ETStatusModel Master)
        {
            try
            {
                string @Result = "";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", Master.ID);
                    cmd.Parameters.AddWithValue("@Code", Master.Code);
                    cmd.Parameters.AddWithValue("@Description", Master.Description);
                    cmd.Parameters.AddWithValue("@IsActive", Master.IsActive);

                    cmd.Parameters.AddWithValue("@Energy_Supply", Master.EnergySupply);
                    cmd.Parameters.AddWithValue("@UserId", Master.UserId);
                    cmd.Parameters.AddWithValue("@Calling_Type", "STATUS");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;

                    return Master;
                }


            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// UpdateETStatus
        /// </summary>
        /// <param name="Master"></param>
        /// <returns></returns>
        public ETStatusModel UpdateETStatus(ETStatusModel Master)
        {
            try
            {
                string @Result = "";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Id", Master.ID);
                    cmd.Parameters.AddWithValue("@Code", Master.Code);
                    // cmd.Parameters.AddWithValue("@Description", Master.Description);
                    // cmd.Parameters.AddWithValue("@Energy_Supply", Master.EnergySupply);
                    cmd.Parameters.AddWithValue("@IsActive", Master.IsActive);
                    cmd.Parameters.AddWithValue("@UserId", Master.UserId);
                    cmd.Parameters.AddWithValue("@Calling_Type", "STATUS");
                    cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    @Result = (string)cmd.Parameters["@Result"].Value;


                }
                return Master;
            }
            catch
            {
                throw;
            }
        }

    }
}

using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{

    public class SLATrackerDAL : BaseDAL, ISLATracker
    {
        //private string connectionString;

        List<SLATracker> slaList = new List<SLATracker>();
        public SLATrackerDAL(IConfiguration configuration) : base(configuration)
        {
        }

        public IEnumerable<SLATracker> SearchSLARecords(SLASearch objInput)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_SearchSLA", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@Response", objInput.Response);
                    cmd.Parameters.AddWithValue("@ICCD", objInput.ICCD);
                    cmd.Parameters.AddWithValue("@MPXN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@EnergySupply", objInput.EnergySupplyId);
                    cmd.Parameters.AddWithValue("@LetterCategoryId", objInput.LetterCategoryId);
                    cmd.Parameters.AddWithValue("@Action", objInput.InitiationTypeId);

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                       SLATracker SLA = new SLATracker();
SLA.RefId = DbDataHelper.GetInt64(rdr, "refid");
SLA.MPXN = DbDataHelper.GetString(rdr, "MPXN");
SLA.ICCD = DbDataHelper.GetNullableDateTime(rdr, "Initiation Received Date");
SLA.Received = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
SLA.Product = DbDataHelper.GetString(rdr, "Energy Supply");
SLA.Delay = rdr["Delay"].ToString();
SLA.D5Sent = DbDataHelper.GetNullableDateTime(rdr, "D5 Sent Date");
SLA.D5Letter = DbDataHelper.GetString(rdr, "D5 Letter Type");
SLA.Remarks = DbDataHelper.GetString(rdr, "Remarks");
SLA.D5Comments = DbDataHelper.GetString(rdr, "D5 Comments");
SLA.D5DaysfromICCD = rdr["D5 Days from ICCD"].ToString();
SLA.D5DaysfromReceivedDate = rdr["D5 Days from Received Date"].ToString();
SLA.D20InterimLettersentDate = DbDataHelper.GetNullableDateTime(rdr, "D-20 Interim Letter Sent Date");
SLA.D20InterimLetterType = rdr["D20 Interim Letter Type"].ToString();
SLA.SLA = rdr["SLA"].ToString();
SLA.D20InterimComments = rdr["D20 Interim Comments"].ToString();
SLA.D20LetterSentDate = DbDataHelper.GetNullableDateTime(rdr, "D20 Letter Sent Date");
SLA.D20LetterType = rdr["D20 Letter Type"].ToString();
SLA.D20DaysfromICCD = rdr["D20 Days from ICCD"].ToString();
SLA.D20DaysfromReceivedDate = rdr["Days from Received Date"].ToString();
SLA.Sentfilename = rdr["Sent file name"].ToString();
SLA.Filesentdate = DbDataHelper.GetNullableDateTime(rdr, "File sent date");
SLA.InitiationSLA = rdr["File SLA"].ToString();
SLA.FileRemarks = rdr["File Remarks"].ToString();
SLA.D20Comments = rdr["D20Comments"].ToString();
//SLA.InitiationReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "Initiation Received Date");
SLA.ReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
SLA.Fuel = rdr["Fuel"].ToString();
SLA.ETType = rdr["ET_Type"].ToString();
SLA.ResponseSendDate = DbDataHelper.GetNullableDateTime(rdr, "Response Send Date");
SLA.InitiationSLARemarks = rdr["Initiation SLA Remarks"].ToString();
SLA.DayfromInitiation = rdr["Day from Initiation"].ToString();
SLA.InitiationSLAComments = rdr["Initiation SLA Comments"].ToString();
SLA.energysupply = rdr["Energy_Supply"].ToString();
SLA.Responsesla = 0;
slaList.Add(SLA);
                    }
                    con.Close();



                }
                return slaList;
            }
            catch
            {
                throw;
            }
        }
        public SLAUpdate SLATrackerUpdateETData(string jsonData, int iUserId)
        {
            SLAUpdate _output = new SLAUpdate();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("usp_SLATracker_Update", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Data", jsonData);
                    cmd.Parameters.AddWithValue("@P_UserId", iUserId);
                    cmd.Parameters.Add("@P_UpdStatusCode", SqlDbType.Int);
                    cmd.Parameters["@P_UpdStatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_UpdStatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_UpdStatusMsg"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    _output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_UpdStatusCode"].Value);
                    _output.StatusMessage = cmd.Parameters["@P_UpdStatusMsg"].Value.ToString();
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
            return _output;
        }
    }
}

﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class CancelReasonDAL : BaseDAL, ICancelReason
    {
        //static string connectionString;
        List<CancelReason> CancelReasonsList = new List<CancelReason>();
        public CancelReasonDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }

        /// <summary>
        /// AddCancelReason
        /// </summary>
        /// <param name="CancelReason"></param>
        /// <returns></returns>
        public CancelReason AddCancelReason(CancelReason CancelReason)
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", CancelReason.ID);
                cmd.Parameters.AddWithValue("@Type", CancelReason.Type);
                cmd.Parameters.AddWithValue("@Code", CancelReason.Code);
                cmd.Parameters.AddWithValue("@Description", CancelReason.Description);
                cmd.Parameters.AddWithValue("@IsActive", CancelReason.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", CancelReason.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", CancelReason.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "CANCEL_REASON");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return CancelReason;
        }
        /// <summary>
        /// DeleteCancelReason
        /// </summary>
        /// <param name="CancelReason"></param>
        /// <returns></returns>
        public CancelReason DeleteCancelReason(CancelReason CancelReason)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", CancelReason.ID);
                cmd.Parameters.AddWithValue("@Type", CancelReason.Type);
                cmd.Parameters.AddWithValue("@Code", CancelReason.Code);
                cmd.Parameters.AddWithValue("@Description", CancelReason.Description);
                cmd.Parameters.AddWithValue("@IsActive", CancelReason.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", CancelReason.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", CancelReason.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "CANCEL_REASON");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
            return CancelReason;

        }
        /// <summary>
        /// GetCancelReason
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CancelReason> GetCancelReason()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "CANCEL_REASON");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        CancelReason CancelReason = new CancelReason();
                        CancelReason.ID = Convert.ToInt32(rdr["ID"].ToString());
                        CancelReason.Type = rdr["Type"].ToString();
                        CancelReason.Code = rdr["Code"].ToString();
                        CancelReason.Description = rdr["Description"].ToString();
                        CancelReason.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        CancelReason.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                        CancelReasonsList.Add(CancelReason);

                    }
                    con.Close();



                }
                return CancelReasonsList;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// GetCancelReasonById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CancelReason GetCancelReasonById(int id)
        {
            CancelReason CancelReason = new CancelReason();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", id);
                cmd.Parameters.AddWithValue("@Calling_Type", "CANCEL_REASON");

                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {


                    CancelReason.ID = Convert.ToInt32(rdr["ID"].ToString());
                    CancelReason.Type = rdr["Type"].ToString();
                    CancelReason.Code = rdr["Code"].ToString();
                    CancelReason.Description = rdr["Description"].ToString();
                    CancelReason.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                    CancelReason.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());


                    CancelReason.EnergySupplies = new[]
{
    new SelectListItem { Value = "1", Text = "GAS" },
     new SelectListItem { Value = "2", Text = "Electricity" },

  };

                    CancelReason.Types = new[]
{
     new SelectListItem { Value = "CancelReason", Text = "CancelReason" },
             new SelectListItem { Value = "CancelSubReason", Text = "CancelSubReason" },
  };





                }
                con.Close();

                return CancelReason;

            }
        }
        /// <summary>
        /// UpdateCancelReason
        /// </summary>
        /// <param name="CancelReason"></param>
        /// <returns></returns>
        public CancelReason UpdateCancelReason(CancelReason CancelReason)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string @Result = "";

                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", CancelReason.ID);
                cmd.Parameters.AddWithValue("@Type", CancelReason.Type);
                cmd.Parameters.AddWithValue("@Code", CancelReason.Code);
                cmd.Parameters.AddWithValue("@Description", CancelReason.Description);
                cmd.Parameters.AddWithValue("@IsActive", CancelReason.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", CancelReason.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", CancelReason.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "CANCEL_REASON");
                cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                cmd.Parameters["@Result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                @Result = (string)cmd.Parameters["@Result"].Value;

            }
            return CancelReason;
        }
    }
}

﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class GasWorkFlowDAL : BaseDAL, IGasWorkflow
    {
        //private string connectionString;
        string @ReturnMessage = string.Empty;
        List<GasworkflowModel> lstgasdata = null;
        public GasWorkFlowDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetGasData
        /// </summary>
        /// <param name="Mprn"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        public IEnumerable<GasworkflowModel> GetGasData(GasSearchCriteria objInput)
        {
            try
            {
                lstgasdata = new List<GasworkflowModel>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                   /* SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetGasData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Mprn", objInput.MPRN);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_ICCD", objInput.ICCD);
                    cmd.Parameters.AddWithValue("@P_SupplierCode", objInput.SupplierCode);
                    cmd.Parameters.AddWithValue("@P_StageCode", objInput.StageCode);*/
                    //SqlCommand cmd = new SqlCommand(DbConstants.sp_GetElectricityData, con);
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetGasData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MPRN", objInput.MPRN);
                   // cmd.Parameters.AddWithValue("@Energy", objInput.Energy);
                     cmd.Parameters.AddWithValue("@Energy","Gas");
                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@ICCD", objInput.ICCD);
                    cmd.Parameters.AddWithValue("@SupplierCode", objInput.SupplierCode);
                    cmd.Parameters.AddWithValue("@StageCode", objInput.StageCode);
                    con.Open();
                   // con.Open();


                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            GasworkflowModel gasmodel = new GasworkflowModel();
                            gasmodel.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            gasmodel.EnergySupply = DbDataHelper.GetString(rdr, "Energy_Supply");
                            gasmodel.RecordTypeIdentifier = DbDataHelper.GetString(rdr, "Record_Type_Identifier");
                            gasmodel.InitialContact = DbDataHelper.GetString(rdr, "Initiating_Organisation_ID");
                            gasmodel.IoContactName = DbDataHelper.GetString(rdr, "IO_Contact_Name");
                            gasmodel.ReferenceNumber = DbDataHelper.GetString(rdr, "Reference_Number");
                            gasmodel.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            gasmodel.Et_Type = DbDataHelper.GetString(rdr, "Et_Type");
                            gasmodel.Address1 = DbDataHelper.GetString(rdr, "House_Number");
                            gasmodel.Address2 = DbDataHelper.GetString(rdr, "Street_Name");
                            gasmodel.Address5 = DbDataHelper.GetString(rdr, "PostCode");
                            gasmodel.CustomerName = DbDataHelper.GetString(rdr, "Customer_Name");
                            gasmodel.ContactTel = DbDataHelper.GetString(rdr, "Customer_Telephone_Number");
                            gasmodel.CustomerRequestsNewSupplier = DbDataHelper.GetString(rdr, "Customer_Requests_NoContact_From_NewSupplier");
                            gasmodel.DateOfTransfer = DbDataHelper.GetNullableDateTime(rdr, "Date_Of_Transfer");
                            gasmodel.ICCD = DbDataHelper.GetNullableDateTime(rdr, "Initial_Customer_Contact_Date");
                            gasmodel.ReasonforReturn = DbDataHelper.GetString(rdr, "reason_for_return");
                            gasmodel.Status = DbDataHelper.GetString(rdr, "status_response");
                            gasmodel.AssociatedOrganisationId = DbDataHelper.GetString(rdr, "Responding_Associated_Organisation_ID");
                            gasmodel.RoContactName = DbDataHelper.GetString(rdr, "RO_Contact_Name");
                            gasmodel.MeterSerialNumber = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                            gasmodel.MeterReading = DbDataHelper.GetString(rdr, "Meter_Reading");
                            gasmodel.MeterReadingDate = DbDataHelper.GetString(rdr, "Meter_Reading_Date");
                            gasmodel.MeterReadingType = DbDataHelper.GetString(rdr, "Meter_Reading_Type");
                            gasmodel.RecordRejectionAcceptanceCode = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                            gasmodel.FileReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "File_Received_Date");
                            gasmodel.OsComments = DbDataHelper.GetString(rdr, "Os_Comments");
                            gasmodel.FileName = DbDataHelper.GetString(rdr, "FileName");
                            gasmodel.StageCode = DbDataHelper.GetString(rdr, "StageCode");
                            gasmodel.Stage = DbDataHelper.GetString(rdr, "Stage");
                            gasmodel.Duplicate = DbDataHelper.GetBoolean(rdr, "Duplicate");
                            gasmodel.CreatedBy = rdr["CreatedBy"].ToString();
                            gasmodel.CreatedOn = DbDataHelper.GetNullableDateTime(rdr, "CreatedOn");
                            lstgasdata.Add(gasmodel);

                        }
                    }
                    con.Close();

                }
                return lstgasdata;
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// gasworkflow update
        /// </summary>
        /// <param name="gasworkflow"></param>
        /// <returns></returns>

        public Status UpdateStageCode(List<GasWorkFlowUpdateModel> data)
        {
            try
            {
                IList<GasWorkFlowUpdateModel> model = new List<GasWorkFlowUpdateModel>();
                foreach (var item in data)
                {
                    if (item.StageCode == "OPS-OSI")
                    {
                        item.StageCode = "OPS-OSI-C";
                    }
                    else if (item.StageCode == "OPS-OSR")
                    {
                        item.StageCode = "OPS-OSR-C";
                    }
                    if (item.Energy_Supply == "Gas")
                    //if (item.Energy_Supply == 1)
                    {
                        item.Energy_Supply = "1";
                    }

                    model.Add(new GasWorkFlowUpdateModel
                    {
                        RefID = item.RefID,
                        Energy_Supply = "1",
                        MPXN = item.MPXN,
                        StageCode = item.StageCode,
                    });
                }

                var value = JsonConvert.SerializeObject(model);
                Status _output = new Status();
                // string Valaues = value.Replace(@"\", ""); 
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_UpdateStageCode, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Value", value);
                    cmd.Parameters.AddWithValue("@UserId", 100);
                    cmd.Parameters.Add("@P_StatusCode", SqlDbType.Int);
                    cmd.Parameters["@P_StatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    _output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_StatusCode"].Value);
                    _output.StatusMessage = cmd.Parameters["@P_StatusMsg"].Value.ToString();


                    con.Close();
                    return _output;
                }

            }
            catch
            {
                throw;
            }
        }

        //public Status UpdatewfgData(List<GasWorkFlowUpdateModel> data)
        //{
        //    try
        //    {
        //        IList<GasWorkFlowUpdateModel> model = new List<GasWorkFlowUpdateModel>();
        //        List<GasWorkFlowUpdateModel> listdetail = new List<GasWorkFlowUpdateModel>();
        //        foreach (var item in data)
        //        {
        //            if (item.StageCode == "OSI")
        //            {
        //                item.StageCode = "OPS-OSI";
        //            }
        //            else if (item.StageCode == "OSR")
        //            {
        //                item.StageCode = "OPS-OSR";
        //            }
        //            if (item.Energy_Supply == "Gas")
        //            //if (item.Energy_Supply == 1)
        //            {
        //                item.Energy_Supply = "1";
        //            }
        //            model.Add(new GasWorkFlowUpdateModel
        //            {
        //                RefID = item.RefID,
        //                Energy_Supply = "1",
        //                MPXN = item.MPXN,
        //                StageCode = item.StageCode,
        //            });
        //        }

        //        var value = JsonConvert.SerializeObject(model);
        //        Status _output = new Status();
        //        // string Valaues = value.Replace(@"\", ""); 
        //        using (SqlConnection con = new SqlConnection(connectionString))
        //        {
        //            SqlCommand cmd = new SqlCommand(DbConstants.SP_UpdateGasFlowData, con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddWithValue("@Value", value);
        //            cmd.Parameters.AddWithValue("@UserId", 100);
        //            cmd.Parameters.Add("@P_StatusCode", SqlDbType.Int);
        //            cmd.Parameters["@P_StatusCode"].Direction = ParameterDirection.Output;
        //            cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
        //            cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;
        //            con.Open();
        //            cmd.ExecuteNonQuery();
        //            _output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_StatusCode"].Value);
        //            _output.StatusMessage = cmd.Parameters["@P_StatusMsg"].Value.ToString();
        //            con.Close();
        //            return _output;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        ex.ToString();
        //        throw;
        //    }
        //}

        public IEnumerable<GasworkflowModel> GenerateDataforOps(string RefIds, int UserId)
        {
            try
            {
                lstgasdata = new List<GasworkflowModel>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetProcessedGWFData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_RefIds", RefIds);
                    cmd.Parameters.AddWithValue("@P_UserId", UserId);
                    cmd.Parameters.Add("@P_StatusCode", SqlDbType.Int);
                    cmd.Parameters["@P_StatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;
                    con.Open();

                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            GasworkflowModel gasmodel = new GasworkflowModel();
                            gasmodel.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            gasmodel.EnergySupply = DbDataHelper.GetString(rdr, "Energy_Supply");
                            gasmodel.RecordTypeIdentifier = DbDataHelper.GetString(rdr, "Record_Type_Identifier");
                            gasmodel.InitialContact = DbDataHelper.GetString(rdr, "Initiating_Organisation_ID");
                            gasmodel.IoContactName = DbDataHelper.GetString(rdr, "IO_Contact_Name");
                            gasmodel.ReferenceNumber = DbDataHelper.GetString(rdr, "Reference_Number");
                            gasmodel.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            gasmodel.Address1 = DbDataHelper.GetString(rdr, "House_Number");
                            gasmodel.Address2 = DbDataHelper.GetString(rdr, "Street_Name");
                            gasmodel.Address5 = DbDataHelper.GetString(rdr, "PostCode");
                            gasmodel.CustomerName = DbDataHelper.GetString(rdr, "Customer_Name");
                            gasmodel.ContactTel = DbDataHelper.GetString(rdr, "Customer_Telephone_Number");
                            gasmodel.CustomerRequestsNewSupplier = DbDataHelper.GetString(rdr, "Customer_Requests_NoContact_From_NewSupplier");
                            gasmodel.DateOfTransfer = DbDataHelper.GetNullableDateTime(rdr, "Date_Of_Transfer");
                            gasmodel.ICCD = DbDataHelper.GetNullableDateTime(rdr, "Initial_Customer_Contact_Date");
                            gasmodel.ReasonforReturn = DbDataHelper.GetString(rdr, "reason_for_return");
                            gasmodel.Status = DbDataHelper.GetString(rdr, "status_response");
                            gasmodel.AssociatedOrganisationId = DbDataHelper.GetString(rdr, "Responding_Associated_Organisation_ID");

                            gasmodel.RoContactName = DbDataHelper.GetString(rdr, "RO_Contact_Name");
                            gasmodel.MeterSerialNumber = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                            gasmodel.MeterReading = DbDataHelper.GetString(rdr, "Meter_Reading");
                            gasmodel.MeterReadingDate = DbDataHelper.GetString(rdr, "Meter_Reading_Date");
                            gasmodel.MeterReadingType = DbDataHelper.GetString(rdr, "Meter_Reading_Type");


                            gasmodel.RecordRejectionAcceptanceCode = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                            gasmodel.FileReceivedDate = DbDataHelper.GetNullableDateTime(rdr, "File_Received_Date");
                            gasmodel.FileName = DbDataHelper.GetString(rdr, "FileName");
                            gasmodel.StageCode = DbDataHelper.GetString(rdr, "StageCode");
                            gasmodel.Stage = DbDataHelper.GetString(rdr, "Stage");

                            lstgasdata.Add(gasmodel);
                        }
                    }
                    con.Close();

                }
                return lstgasdata;
            }
            catch
            {
                throw;
            }
        }

        public Status GetExcelDataCount()
        {
            Status output;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetProcessedCount, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    output = new Status();
                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            output.Count = DbDataHelper.GetInt(rdr, "RecCount");
                            output.RefIds = DbDataHelper.GetString(rdr, "RefIDs");
                        }
                    }
                    con.Close();
                }
                return output;
            }
            catch
            {
                throw;
            }

        }

        public RETData GenerateRetData()
        {
            RETData retData = new RETData();
            List<RETDataModel> lstgasdata = new List<RETDataModel>();
            RETDataDetail retCount = new RETDataDetail();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GenerateRetDataforOS, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            RETDataModel gasmodel = new RETDataModel();
                            gasmodel.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            gasmodel.InitialContact = DbDataHelper.GetString(rdr, "Initial_Contact");
                            gasmodel.IoContactName = DbDataHelper.GetString(rdr, "IO_Contact_Name");
                            gasmodel.ReferenceNo = DbDataHelper.GetString(rdr, "Reference_Number");
                            gasmodel.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            gasmodel.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            gasmodel.Address2 = DbDataHelper.GetString(rdr, "Address2");
                            gasmodel.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            gasmodel.ContactName = DbDataHelper.GetString(rdr, "ContactName");
                            gasmodel.ContactTel = DbDataHelper.GetString(rdr, "ContactTel");
                            gasmodel.ReqNewSupplier = DbDataHelper.GetString(rdr, "Customer_Requests_NewSupplier");
                            gasmodel.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                            gasmodel.RecivedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                            gasmodel.ReturnReason = DbDataHelper.GetString(rdr, "Reason_for_Return");
                            gasmodel.Status = DbDataHelper.GetString(rdr, "Status");
                            gasmodel.AscOrgId = DbDataHelper.GetString(rdr, "Associated_Organisation_ID");
                            gasmodel.RoContactName = DbDataHelper.GetString(rdr, "RO_Contact_Name");
                            gasmodel.MeterSlNo = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                            gasmodel.MeterReading = DbDataHelper.GetString(rdr, "Meter_Reading");
                            gasmodel.MeterReadDate = DbDataHelper.GetString(rdr, "Meter_Reading_Date");
                            gasmodel.MeterReadType = DbDataHelper.GetString(rdr, "Meter_Reading_Type");
                            gasmodel.RecordRjtActCode = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                            gasmodel.Comment = DbDataHelper.GetString(rdr, "Comment");
                            lstgasdata.Add(gasmodel);
                        }
                        rdr.NextResult();
                        while (rdr.Read())
                        {
                            retCount.Count = DbDataHelper.GetInt(rdr, "TotCount");
                            retCount.FileName = DbDataHelper.GetString(rdr, "FileName");
                            retCount.SupplierCode = DbDataHelper.GetString(rdr, "SupplierCode");
                            retCount.Type = DbDataHelper.GetString(rdr, "Type");
                            retCount.Registered = DbDataHelper.GetBoolean(rdr, "Registered");
                        }
                    }
                    con.Close();
                }
                retData.retDataDetail = lstgasdata;
                retData.retHeader = retCount;
                return retData;

            }
            catch
            {
                throw;
            }

        }

        public Status UpdateRetData(string RefIds, string fileName, string strType, int UserId)
        {
            Status _output = new Status();
            try
            {
                // string Valaues = value.Replace(@"\", ""); 
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_UpdateRetData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_RefIds", RefIds);
                    cmd.Parameters.AddWithValue("@P_FileName", fileName);
                    cmd.Parameters.AddWithValue("@P_Type", strType);
                    cmd.Parameters.AddWithValue("@P_UserId", UserId);
                    cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    _output.StatusMessage = cmd.Parameters["@P_StatusMsg"].Value.ToString();
                    con.Close();
                }
                return _output;
            }
            catch
            {
                throw;
            }
        }
    }
}

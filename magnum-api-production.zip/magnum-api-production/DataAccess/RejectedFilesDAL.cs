﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class RejectedFilesDAL : BaseDAL, IRejectedFiles
    {
        //private string connectionString;
        public RejectedFilesDAL(IConfiguration configuration) : base(configuration)
        {
        }

        /// <summary>
        /// GetRejectedData
        /// </summary>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        public IEnumerable<RejectedFiles> GetRejectedData(RejectedFileSearch objInput)
        {
            try
            {
                List<RejectedFiles> rejecteds = new List<RejectedFiles>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_RejectedFiles_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        RejectedFiles rejectedFiles = new RejectedFiles();
                        rejectedFiles.ID = DbDataHelper.GetInt(rdr, "ID");
                        rejectedFiles.FileName = DbDataHelper.GetString(rdr, "FileName");
                        rejectedFiles.ProcessDate = DbDataHelper.GetNullableDateTime(rdr, "DateTime");
                        rejectedFiles.FileData = DbDataHelper.GetString(rdr, "FileData");
                        rejectedFiles.ReasonOfReject = DbDataHelper.GetString(rdr, "ReasonOfReject");
                        rejecteds.Add(rejectedFiles);
                    }
                    con.Close();
                }
                return rejecteds;
            }
            catch
            {
                throw;
            }

        }

    }
}

using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class GSOPCDAL : BaseDAL, IGSOPC
    {
        // private string connectionString;
        public GSOPCDAL(IConfiguration configuration) : base(configuration)
        {
            //  connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }

        /// <summary>
        /// GetGasData
        /// </summary>
        /// <param name="MPXN"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        public IList<GSOPC> GetGsopCData(GsopCSearchModel objInput)
        {
            try
            {
                List<GSOPC> lstGsopC = new List<GSOPC>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetCompensation, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    con.Open();

                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            GSOPC objOutput = new GSOPC();
                            objOutput.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            objOutput.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                            objOutput.EnergySupply = DbDataHelper.GetString(rdr, "EnergySupply");
                            objOutput.InitiatedBy = DbDataHelper.GetString(rdr, "InitiatedBy");
                            objOutput.ReasonforReturn = DbDataHelper.GetString(rdr, "ReasonforReturn");
                            objOutput.Supplier = DbDataHelper.GetString(rdr, "Supplier");
                            objOutput.FileSendDate = DbDataHelper.GetNullableDateTime(rdr, "ResponseDate");
                            objOutput.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                            objOutput.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                            objOutput.NetworkingDaysAsperResponseDate = DbDataHelper.GetNullableInt(rdr, "NetworkingDaysAsperResponseDate");
                            objOutput.NetworkingDaysASPerSDAPDate = DbDataHelper.GetNullableInt(rdr, "NetworkingDaysASPerSDAPDate");
                            objOutput.Status = DbDataHelper.GetString(rdr, "Status");
                            objOutput.ContractAccount = DbDataHelper.GetString(rdr, "ContractAccount");
                            objOutput.BusinessPartner = DbDataHelper.GetString(rdr, "BusinessPartner");
                            objOutput.CustomerName = DbDataHelper.GetString(rdr, "ContactName");
                            objOutput.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                            objOutput.Comments = DbDataHelper.GetString(rdr, "Comments");
                            objOutput.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                            objOutput.CompensationGiven = DbDataHelper.GetString(rdr, "CompensationGiven");
                            objOutput.CompensationDate = DbDataHelper.GetNullableDateTime(rdr, "CompensationDate");
                            objOutput.SdepResponseDate = DbDataHelper.GetNullableDateTime(rdr, "SdepResponseRecd");
                            objOutput.SdepName = DbDataHelper.GetString(rdr, "SdepName");
                            objOutput.SdepAddress = DbDataHelper.GetString(rdr, "SdepAddress");
                            objOutput.Remarks = DbDataHelper.GetString(rdr, "Remarks");
                            objOutput.Title= DbDataHelper.GetString(rdr, "Title");
                            objOutput.SurName = DbDataHelper.GetString(rdr, "SurName");
                            objOutput.Initial = DbDataHelper.GetString(rdr, "Initial");
                            objOutput.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            objOutput.Address2 = DbDataHelper.GetString(rdr, "Address2");
                            objOutput.Address3 = DbDataHelper.GetString(rdr, "Address3");
                            objOutput.Address4 = DbDataHelper.GetString(rdr, "Address4");
                            objOutput.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            objOutput.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
                            objOutput.DuplicatePartner = DbDataHelper.GetString(rdr, "Duplicate");
                            lstGsopC.Add(objOutput);
                        }
                    }
                    con.Close();

                }
                return lstGsopC;
            }
            catch
            {
                throw;
            }

        }
    }
}

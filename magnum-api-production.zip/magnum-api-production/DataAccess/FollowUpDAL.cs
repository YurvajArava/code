using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class FollowUpDAL : BaseDAL, IFollowUp
    {
        //private string connectionString;
        public FollowUpDAL(IConfiguration configuration) : base(configuration)
        {
            // connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }

        /// <summary>
        /// Get FollowUp Data based on search Criteria
        /// </summary>
        /// <param name="objInput"></param>
        /// <returns>List of FollowUp Data</returns>
      public List<FollowUp> GetFollowUpData(FollowUpSearchAttribute objInput)
{
try
{
List<FollowUp> lstFollowUp = new List<FollowUp>();
using (SqlConnection con = new SqlConnection(connectionString))
{
SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetFollowUps, con);
cmd.CommandType = CommandType.StoredProcedure;
cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
cmd.Parameters.AddWithValue("@P_FollowUpType", objInput.FollowUpTypeId);
cmd.Parameters.AddWithValue("@P_EnergySupply", objInput.EnergySupplyId);
cmd.Parameters.AddWithValue("@P_UserId", objInput.UserId);
con.Open();
using (IDataReader rdr = cmd.ExecuteReader())
{
while (rdr.Read())
{
FollowUp objFollowUp = new FollowUp();
objFollowUp.RefId = DbDataHelper.GetInt64(rdr, "RefId");
objFollowUp.EnergySupply = DbDataHelper.GetString(rdr, "EnergySupply");
objFollowUp.MPXN = DbDataHelper.GetString(rdr, "MPAN");
objFollowUp.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
objFollowUp.SupplierTransferDate = DbDataHelper.GetNullableDateTime(rdr, "DOT");
objFollowUp.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
objFollowUp.FollowUpType = DbDataHelper.GetString(rdr, "FollowUp_Type");
objFollowUp.FileSendDate = DbDataHelper.GetNullableDateTime(rdr, "File_Send_Date");
objFollowUp.AscOrgId = DbDataHelper.GetString(rdr, "Associated_Organisation_ID");
objFollowUp.EtType = DbDataHelper.GetString(rdr, "ET_Type");
objFollowUp.Comments = DbDataHelper.GetString(rdr, "Comments");
objFollowUp.FollowUpDate = DbDataHelper.GetNullableDateTime(rdr, "FollowUp_Date");
objFollowUp.D5SendDate = DbDataHelper.GetNullableDateTime(rdr, "D5SendDate");
objFollowUp.D5SdepDate = DbDataHelper.GetNullableDateTime(rdr, "D5SdepDate");
objFollowUp.D10SendDate = DbDataHelper.GetNullableDateTime(rdr, "D10SendDate");
objFollowUp.D10SdepDate = DbDataHelper.GetNullableDateTime(rdr, "D10SdepDate");
objFollowUp.D15SendDate = DbDataHelper.GetNullableDateTime(rdr, "D15SendDate");
objFollowUp.D15SdepDate = DbDataHelper.GetNullableDateTime(rdr, "D15SdepDate");
objFollowUp.MraSendDate = DbDataHelper.GetNullableDateTime(rdr, "MraSendDate");
objFollowUp.DMRASdepDate = DbDataHelper.GetNullableDateTime(rdr, "MRASdepDate");
objFollowUp.WorkingDays = DbDataHelper.GetInt(rdr, "NetWorkingDays");
lstFollowUp.Add(objFollowUp);
}
}
con.Close();



}
return lstFollowUp;
}
catch
{
throw;
}



}
public List<FollowUp> GetOpsData()
{
try
{
List<FollowUp> lstFollowUp = new List<FollowUp>();
using (SqlConnection con = new SqlConnection(connectionString))
{



SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetFollowUpforOps, con);
cmd.CommandType = CommandType.StoredProcedure;
con.Open();




using (IDataReader rdr = cmd.ExecuteReader())
{
while (rdr.Read())
{
FollowUp objFollowUp = new FollowUp();
objFollowUp.RefId = DbDataHelper.GetInt64(rdr, "RefId");
objFollowUp.EnergySupply = DbDataHelper.GetString(rdr, "MPAN");
objFollowUp.MPXN = DbDataHelper.GetString(rdr, "EnergySupply");
objFollowUp.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
objFollowUp.SupplierTransferDate = DbDataHelper.GetNullableDateTime(rdr, "DOT");
objFollowUp.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
objFollowUp.FollowUpType = DbDataHelper.GetString(rdr, "FollowUp_Type");
objFollowUp.FileSendDate = DbDataHelper.GetDateTime(rdr, "File_Send_Date");
objFollowUp.AscOrgId = DbDataHelper.GetString(rdr, "Associated_Organisation_ID");
objFollowUp.EtType = DbDataHelper.GetString(rdr, "ET_Type");
objFollowUp.Comments = DbDataHelper.GetString(rdr, "Comments");
objFollowUp.FollowUpDate = DbDataHelper.GetNullableDateTime(rdr, "FollowUp_Date");
objFollowUp.WorkingDays = DbDataHelper.GetInt(rdr, "NetWorkingDays");
objFollowUp.FileRecievedDate = DbDataHelper.GetNullableDateTime(rdr, "File_Received_Date");
objFollowUp.TrackCode = DbDataHelper.GetString(rdr, "Track_Code");
objFollowUp.RecievedResponse = DbDataHelper.GetString(rdr, "Received_Response");
objFollowUp.Status = DbDataHelper.GetString(rdr, "Status");
objFollowUp.CancellationReason = DbDataHelper.GetString(rdr, "Cancellation_Reason");
objFollowUp.Stage = DbDataHelper.GetString(rdr, "Stage");



lstFollowUp.Add(objFollowUp);



}
}
con.Close();



}
return lstFollowUp;
}
catch
{
throw;
}



}


        /// <summary>
        /// Get followUp Types
        /// </summary>
        /// <returns>List of FollowUp Types</returns>
        public List<FollowUpTypes> GetFollowUpTypes()
        {
            try
            {
                List<FollowUpTypes> lstFollowUpType = new List<FollowUpTypes>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Calling_Type", "Followup_Type");
                    con.Open();


                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            FollowUpTypes objFollowupType = new FollowUpTypes();
                            objFollowupType.Id = DbDataHelper.GetInt(rdr, "Id");
                            objFollowupType.FollowUpType = DbDataHelper.GetString(rdr, "FollowUp_Type");
                            objFollowupType.Description = DbDataHelper.GetString(rdr, "Description");
                            objFollowupType.IsActive = DbDataHelper.GetBoolean(rdr, "IsActive");
                            lstFollowUpType.Add(objFollowupType);

                        }
                    }
                    con.Close();

                }
                return lstFollowUpType;
            }
            catch
            {
                throw;
            }
        }

        public Status UpdateFollowUpOps(string jsonData, int iUserId)
        {
            Status _output = new Status();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_UpdateRetData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Json", jsonData);
                    cmd.Parameters.AddWithValue("@P_UserId", iUserId);
                    cmd.Parameters.Add("@P_StatusCode", SqlDbType.Int);
                    cmd.Parameters["@P_StatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    _output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_StatusMsg"].Value);
                    _output.StatusMessage = cmd.Parameters["@P_StatusMsg"].Value.ToString();
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
            return _output;
        }
        
public string UpdateFollowUpRecords(List<FollowSdepUpdate> data, int userid)
{
try
{ var json = JsonConvert.SerializeObject(data);
using (SqlConnection con = new SqlConnection(connectionString))
{
// SqlCommand cmd = new SqlCommand("Usp_GSOPStandardA1_BulkUpDate", con);
SqlCommand cmd = new SqlCommand("Usp_BGFollowUP_BulkUpDate", con);
cmd.CommandType = CommandType.StoredProcedure;
cmd.Parameters.AddWithValue("@P_Json", json);
cmd.Parameters.AddWithValue("@P_UserId", userid);
cmd.Parameters.Add("@P_StatusCode", SqlDbType.Int);
cmd.Parameters["@P_StatusCode"].Direction = ParameterDirection.Output;
cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500);
cmd.Parameters["@P_StatusMsg"].Direction = ParameterDirection.Output;
con.Open();
cmd.ExecuteNonQuery();
int statuscode = Convert.ToInt16(cmd.Parameters["@P_StatusMsg"].Value);
string statusMsg = cmd.Parameters["@P_StatusMsg"].Value.ToString();
con.Close();
return null;
}
}
catch(Exception ex)
{
throw;
}
}


    }
}

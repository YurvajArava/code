﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace EXLETAPI.DataAccess
{
    public class ReportTableDAL: BaseDAL,IReportTable
    {
        public ReportTableDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        public IEnumerable<RetStagingFIelds> GetReportRETTables(ReportTablesSearch objInput)
        {
            try
            {
                List<RetStagingFIelds> reportTables = new List<RetStagingFIelds>();
           
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("usp_GetRetOPSDetails", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MPRN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@RecordType", objInput.RecordType);
                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate); 
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        RetStagingFIelds report = new RetStagingFIelds();
 
                        report.Record_type_Identifier = DbDataHelper.GetString(rdr, "Record_type_Identifier");
                        report.Initiating_Organisation_ID = DbDataHelper.GetString(rdr, "Initiating_Organisation_ID");
                        report.IO_Contact_Name = DbDataHelper.GetString(rdr, "IO_Contact_Name");
                        report.ReferenceNumber = DbDataHelper.GetString(rdr, "Reference_Number");
                        report.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                        report.House_Number = DbDataHelper.GetString(rdr, "House_Number");
                        report.Street_Name = DbDataHelper.GetString(rdr, "Street_Name"); 
                        report.Postcode = DbDataHelper.GetString(rdr, "Postcode"); 
                        report.Customer_Name = DbDataHelper.GetString(rdr, "Customer_Name"); 
                        report.Customer_Telephone_Number = DbDataHelper.GetString(rdr, "Customer_Telephone_Number"); 
                        report.Customer_Requests_NoContact_From_NewSupplier = DbDataHelper.GetString(rdr, "Customer_Requests_NoContact_From_NewSupplier");
                        report.Date_Of_Transfer = DbDataHelper.GetNullableDateTime(rdr, "Date_Of_Transfer");
                        report.Initial_Customer_Contact_Date = DbDataHelper.GetNullableDateTime(rdr, "Initial_Customer_Contact_Date");
                        report.Reason_For_Return = DbDataHelper.GetString(rdr, "Reason_For_Return");
                        report.Status_Response = DbDataHelper.GetString(rdr, "Status_Response");
                        report.Responding_Associated_Organisation_ID = DbDataHelper.GetString(rdr, "Responding_Associated_Organisation_ID");
                        report.RO_Contact_Name = DbDataHelper.GetString(rdr, "RO_Contact_Name");
                        report.Meter_Serial_Number = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                        report.Meter_Reading = DbDataHelper.GetString(rdr, "Meter_Reading");
                        report.Meter_Reading_Date = DbDataHelper.GetString(rdr, "Meter_Reading_Date");
                        report.Meter_Reading_Type = DbDataHelper.GetString(rdr, "Meter_Reading_Type");
                        report.Record_Rejection_Acceptance_Code = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                        report.Comments = DbDataHelper.GetString(rdr, "Comments");
                        report.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate"); 
                        report.FileName = DbDataHelper.GetString(rdr, "FileName"); 
                        report.FileType = DbDataHelper.GetString(rdr, "FileType"); 
                        report.GenratedFileName = DbDataHelper.GetString(rdr, "GenratedFileName"); 
                        report.GeneratedDate = DbDataHelper.GetNullableDateTime(rdr, "GeneratedDate"); 

                        reportTables.Add(report);
                    }
                    con.Close();
                }
                return reportTables;
            }
            catch(Exception ex)
            {
                throw;
            }

        }
            public IEnumerable<ReportCustomerLetter> GetCustomerLetterReport(ReportTablesSearch objInput)
{
try
{
List<ReportCustomerLetter> reportTables = new List<ReportCustomerLetter>();
using (SqlConnection con = new SqlConnection(connectionString))
{
//SqlCommand cmd = new SqlCommand("usp_GetCustomerLetterReport", con);
SqlCommand cmd = new SqlCommand("usp_GetCustomerLetters", con);
cmd.CommandType = CommandType.StoredProcedure;
cmd.Parameters.AddWithValue("@MPXN", objInput.MPXN);
cmd.Parameters.AddWithValue("@Energy", objInput.PEnergySupplyId.ToString());
//cmd.Parameters.AddWithValue("@RecordType", objInput.RecordType);
cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
con.Open();
SqlDataReader rdr = cmd.ExecuteReader();
while (rdr.Read())
{
ReportCustomerLetter report = new ReportCustomerLetter();
report.DDate = DbDataHelper.GetNullableDateTime(rdr, "Date");
report.MPXN = DbDataHelper.GetString(rdr, "MPXN");
//report.MPXN = DbDataHelper.GetString(rdr, "Product");
report.Energy = DbDataHelper.GetString(rdr, "Product");
report.Customer_Name = DbDataHelper.GetString(rdr, "CustomerName");
report.Customer_Name1 = DbDataHelper.GetString(rdr, "CustomerName1");
report.Address1 = DbDataHelper.GetString(rdr, "address1");
report.Address2 = DbDataHelper.GetString(rdr, "Address2");
report.Address3 = DbDataHelper.GetString(rdr, "Address3");
report.Address4 = DbDataHelper.GetString(rdr, "Address4");
report.Post_Code = DbDataHelper.GetString(rdr, "PostCode");
report.Letter_Type = DbDataHelper.GetString(rdr, "LetterType");
report.Region = DbDataHelper.GetString(rdr, "Region");
report.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
report.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "DateReceived");
reportTables.Add(report);
}
con.Close();
}
return reportTables;
}
catch (Exception ex)
{
throw;
}



}
        public IEnumerable<UsrStagingFields> GetReportUSRTables(ReportTablesSearch objInput)
        {
            try
            {
                List<UsrStagingFields> reportTables = new List<UsrStagingFields>();
              
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("usp_GetUSROPSDetails", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MPAN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@RecordType", objInput.RecordType);
                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        UsrStagingFields report = new UsrStagingFields();
                        report.BatchId = DbDataHelper.GetString(rdr, "BatchId");
                        report.File_Received_Date = DbDataHelper.GetNullableDateTime(rdr, "File_Received_Date");
                        report.Initial_Customer_Contact_Date = DbDataHelper.GetNullableDateTime(rdr, "Initial_Customer_Contact_Date");
                        report.Initiating_Supplier_ID = DbDataHelper.GetString(rdr, "Initiating_Supplier_ID");
                        report.Associated_Supplier_ID = DbDataHelper.GetString(rdr, "Associated_Supplier_ID");
                        report.MPAN_Core = DbDataHelper.GetString(rdr, "MPAN_Core");
                        report.Metering_Point_Address_Line_1 = DbDataHelper.GetString(rdr, "Metering_Point_Address_Line_1"); 
                        report.Metering_Point_Address_Line_2 = DbDataHelper.GetString(rdr, "Metering_Point_Address_Line_2"); 
                        report.Metering_Point_PostCode = DbDataHelper.GetString(rdr, "Address5"); 
                        report.Effective_Settlement_REGI_Date_NewSupplier = DbDataHelper.GetNullableDateTime(rdr, "Effective_Settlement_REGI_Date_NewSupplier"); 
                        report.Customer_Name = DbDataHelper.GetString(rdr, "Customer_Name");
                        report.Customer_Telephone_Number = DbDataHelper.GetString(rdr, "Customer_Telephone_Number");
                        report.Prohibit_Customer_Contact = DbDataHelper.GetString(rdr, "Prohibit_Customer_Contact");
                        report.Reason_for_Return = DbDataHelper.GetString(rdr, "Reason_for_Return");
                        report.Status_of_Erroneous_Transfer = DbDataHelper.GetString(rdr, "Status_of_Erroneous_Transfer");
                        report.Additional_Information = DbDataHelper.GetString(rdr, "Additional_Information");
                        report.Meter_ID = DbDataHelper.GetString(rdr, "Meter_ID");
                        report.Meter_Type = DbDataHelper.GetString(rdr, "Meter_Type");
                        report.Meter_Reading_Id = DbDataHelper.GetString(rdr, "Meter_Reading_Id");
                        report.Meter_Reading_DateTime = DbDataHelper.GetString(rdr, "Meter_Reading_DateTime");
                        report.Register_Reading = DbDataHelper.GetString(rdr, "Register_Reading");
                        report.GenratedFileName = DbDataHelper.GetString(rdr, "GenratedFileName");
                        report.GeneratedDate = DbDataHelper.GetNullableDateTime(rdr, "GeneratedDate");
                   

                        reportTables.Add(report);
                    }
                    con.Close();
                }
                return reportTables;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}

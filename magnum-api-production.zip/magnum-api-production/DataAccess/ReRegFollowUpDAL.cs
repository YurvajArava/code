﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class ReRegFollowUpDAL : BaseDAL, IReRegFollowUp
    {
        //private string connectionString;
        public ReRegFollowUpDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetReRegFollowUpData
        /// </summary>
        /// <param name="Mpan"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>

        public IEnumerable<ReRegFollowUp> GetReRegFollowUpData(ReRegSearch objInput)
        {
            try
            {
                List<ReRegFollowUp> lstReRegdata = new List<ReRegFollowUp>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("Usp_LetterGeneratation_Supplier_ReRegistration", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@MPXN", objInput.MPXN);
                    cmd.Parameters.AddWithValue("@Supply", objInput.EnergySupplyId);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        ReRegFollowUp reRegFollowUp = new ReRegFollowUp();
                        reRegFollowUp.RefId = Convert.ToInt32(rdr["RefID"]);
                        reRegFollowUp.MPXN = Convert.ToInt64(rdr["MPXN"]);
                        reRegFollowUp.EnergySupply = rdr["Energy_Supply"].ToString();
                        reRegFollowUp.Iccd = rdr["ICCD"].ToString();
                        reRegFollowUp.GainingSupplier = rdr["Gaining_Supplier"].ToString();
                        reRegFollowUp.OldSupplier = rdr["Old_Supplier"].ToString();
                        reRegFollowUp.AdditionalComments = rdr["Additional_Comments"].ToString();

                        reRegFollowUp.ReRegFollowUpType = rdr["ReReg_FollowUp_Type"].ToString();
                        reRegFollowUp.NetWorkingDay = rdr["Net_WorkingDays"].ToString();
                        reRegFollowUp.FirstWithdrawalStatus = rdr["First_WithdrawalStatus"].ToString();
                        reRegFollowUp.FirstSwitchDate = rdr["First_SwitchDate"].ToString();
                        reRegFollowUp.SecondWithdrawalStatus = rdr["Second_WithdrawalStatus"].ToString();
                        reRegFollowUp.SecondSwitchDate = rdr["Second_SwitchDate"].ToString();
                        reRegFollowUp.ThirdWithdrawalStatus = rdr["Third_WithdrawalStatus"].ToString();
                        reRegFollowUp.ThirdSwitchDate = rdr["Third_SwitchDate"].ToString();
                        reRegFollowUp.FinalStatus = rdr["Final_Status"].ToString();
                        reRegFollowUp.Aging = rdr["Aging"].ToString();
                        reRegFollowUp.RecievedDate = rdr["RecievedDate"].ToString();
                        reRegFollowUp.BgComments = rdr["BG_Comments"].ToString();
                        reRegFollowUp.DateWorked = rdr["dateworked"].ToString();


                        lstReRegdata.Add(reRegFollowUp);

                    }

                    con.Close();

                }
                return lstReRegdata;
            }
            catch
            {
                throw;
            }
        }

       public string UpdateReRegFollowUpData(List<ReRegFollowUpUpdate> data, int userid)
{
try
{



var json = JsonConvert.SerializeObject(data);
using (SqlConnection con = new SqlConnection(connectionString))
{
SqlCommand cmd = new SqlCommand("Usp_ReReg_Update_followup", con);
cmd.CommandType = CommandType.StoredProcedure;
cmd.Parameters.AddWithValue("@P_Json", json);
cmd.Parameters.AddWithValue("@P_UserId", userid);
cmd.Parameters.Add("@P_StatusMsg", SqlDbType.NVarChar, 500).Direction = ParameterDirection.Output;



con.Open();
cmd.ExecuteNonQuery();
con.Close();
return cmd.Parameters["@P_StatusMsg"].Value.ToString();
//return null;
}
}
catch
{
throw;
}
}

        public IEnumerable<ReRegFollowUp> GetReRegFollowUpData(string mpxn, string sdate, string edate, string energysupply)
        {
            try
            {
                List<ReRegFollowUp> lstReRegdata = new List<ReRegFollowUp>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("Usp_LetterGeneratation_Supplier_ReRegistration", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@StartDate", sdate);
                    cmd.Parameters.AddWithValue("@EndDate", edate);
                    cmd.Parameters.AddWithValue("@MPXN", mpxn);
                    cmd.Parameters.AddWithValue("@Supply", energysupply);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        ReRegFollowUp reRegFollowUp = new ReRegFollowUp();
                        reRegFollowUp.RefId = Convert.ToInt32(rdr["RefID"]);
                        reRegFollowUp.MPXN = Convert.ToInt64(rdr["MPXN"]);
                        reRegFollowUp.EnergySupply = rdr["Energy_Supply"].ToString();
                        reRegFollowUp.Iccd = rdr["ICCD"].ToString();
                        reRegFollowUp.GainingSupplier = rdr["Gaining_Supplier"].ToString();
                        reRegFollowUp.OldSupplier = rdr["Old_Supplier"].ToString();
                        reRegFollowUp.AdditionalComments = rdr["Additional_Comments"].ToString();

                        reRegFollowUp.ReRegFollowUpType = rdr["ReReg_FollowUp_Type"].ToString();
                        reRegFollowUp.NetWorkingDay = rdr["Net_WorkingDays"].ToString();
                        reRegFollowUp.FirstWithdrawalStatus = rdr["First_WithdrawalStatus"].ToString();
                        reRegFollowUp.FirstSwitchDate = rdr["First_SwitchDate"].ToString();
                        reRegFollowUp.SecondWithdrawalStatus = rdr["Second_WithdrawalStatus"].ToString();
                        reRegFollowUp.SecondSwitchDate = rdr["Second_SwitchDate"].ToString();
                        reRegFollowUp.ThirdWithdrawalStatus = rdr["Third_WithdrawalStatus"].ToString();
                        reRegFollowUp.ThirdSwitchDate = rdr["Third_SwitchDate"].ToString();
                        reRegFollowUp.FinalStatus = rdr["Final_Status"].ToString();
                        reRegFollowUp.Aging = rdr["Aging"].ToString();
                        reRegFollowUp.RecievedDate = rdr["RecievedDate"].ToString();
                        reRegFollowUp.BgComments = rdr["BG_Comments"].ToString();
                        reRegFollowUp.DateWorked = rdr["dateworked"].ToString();


                        lstReRegdata.Add(reRegFollowUp);

                    }

                    con.Close();

                }
                return lstReRegdata;
            }
            catch
            {
                throw;
            }
        }
    }
}

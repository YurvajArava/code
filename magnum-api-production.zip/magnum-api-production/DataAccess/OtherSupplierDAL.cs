﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class OtherSupplierDAL : BaseDAL, IOtherSupplier
    {
        // static string connectionString;

        List<OtherSupplier> othersupplierList = new List<OtherSupplier>();
        public OtherSupplierDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// AddOtherSupplier
        /// </summary>
        /// <param name="otherSupplier"></param>
        /// <returns></returns>
        public OtherSupplier AddOtherSupplier(OtherSupplier otherSupplier)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", "");
                cmd.Parameters.AddWithValue("@Code", otherSupplier.SupplierCode);
                //cmd.Parameters.AddWithValue("@Description", otherSupplier.Description);
                cmd.Parameters.AddWithValue("@SupplierName", otherSupplier.SupplierName);
                cmd.Parameters.AddWithValue("@EmailAddress", otherSupplier.EmailAddress);
                cmd.Parameters.AddWithValue("@RejectionEmail", otherSupplier.RejectionEmailAddress);
                cmd.Parameters.AddWithValue("@PhoneNumber", otherSupplier.PhoneNumber);
                cmd.Parameters.AddWithValue("@AltPhoneNumber", otherSupplier.AltPhoneNumber);
                cmd.Parameters.AddWithValue("@ContactName", otherSupplier.ContactName);
                cmd.Parameters.AddWithValue("@Owner", otherSupplier.Owner);
                cmd.Parameters.AddWithValue("@IsActive", otherSupplier.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", otherSupplier.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", otherSupplier.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Supplier");
                cmd.Parameters.AddWithValue("@IsClient_Active", otherSupplier.Active);
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return otherSupplier;
        }
        /// <summary>
        /// DeleteOtherSupplier
        /// </summary>
        /// <param name="otherSupplier"></param>
        /// <returns></returns>
        public OtherSupplier DeleteOtherSupplier(OtherSupplier otherSupplier)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", otherSupplier.SID);
                cmd.Parameters.AddWithValue("@Code", otherSupplier.SupplierCode);
                //cmd.Parameters.AddWithValue("@Description", otherSupplier.Description);
                cmd.Parameters.AddWithValue("@SupplierName", otherSupplier.SupplierName);
                cmd.Parameters.AddWithValue("@EmailAddress", otherSupplier.EmailAddress);
                cmd.Parameters.AddWithValue("@RejectionEmailAddress", otherSupplier.RejectionEmailAddress);
                cmd.Parameters.AddWithValue("@PhoneNumber", otherSupplier.PhoneNumber);
                cmd.Parameters.AddWithValue("@AltPhoneNumber", otherSupplier.AltPhoneNumber);
                cmd.Parameters.AddWithValue("@ContactName", otherSupplier.ContactName);
                cmd.Parameters.AddWithValue("@Owner", otherSupplier.Owner);
                cmd.Parameters.AddWithValue("@IsActive", otherSupplier.IsActive);
                cmd.Parameters.AddWithValue("@Energy_Supply", otherSupplier.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", otherSupplier.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Supplier");
                cmd.Parameters.AddWithValue("@IsClient_Active", otherSupplier.Active);
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();


            }
            return otherSupplier;

        }
        /// <summary>
        /// GetOtherSupplier
        /// </summary>
        /// <returns></returns>

        public IEnumerable<OtherSupplier> GetOtherSupplier()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "SUPPLIER");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        OtherSupplier otherSupplier = new OtherSupplier();
                        otherSupplier.SID = Convert.ToInt32(rdr["ID"].ToString());
                        otherSupplier.SupplierCode = rdr["SupplierCode"].ToString();
                        //otherSupplier.Description = rdr["Description"].ToString();
                        otherSupplier.SupplierName = rdr["SupplierName"].ToString();
                        otherSupplier.EmailAddress = rdr["EmailAddress"].ToString();
                        otherSupplier.RejectionEmailAddress = rdr["RejectionEmailAddress"].ToString();
                        otherSupplier.PhoneNumber = rdr["PhoneNumber"].ToString();
                        otherSupplier.AltPhoneNumber = rdr["AltPhoneNumber"].ToString();
                        otherSupplier.ContactName = rdr["ContactName"].ToString();
                        otherSupplier.Owner = rdr["Owner"].ToString();
                        otherSupplier.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        otherSupplier.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                        otherSupplier.Active = Convert.ToBoolean(rdr["IsClient_Active"]);
                        othersupplierList.Add(otherSupplier);

                    }
                    con.Close();



                }
                return othersupplierList;
            }
            catch
            {
                throw;
            }

        }
        /// <summary>
        /// GetOtherSupplierById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public OtherSupplier GetOtherSupplierById(int id)
        {
            OtherSupplier otherSupplier = new OtherSupplier();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_GetMasterData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@Calling_Type", "supplier");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {

                        otherSupplier.SID = Convert.ToInt32(rdr["ID"].ToString());
                        otherSupplier.SupplierCode = rdr["SupplierCode"].ToString();
                        //otherSupplier.Description = rdr["Description"].ToString();
                        otherSupplier.SupplierName = rdr["SupplierName"].ToString();
                        otherSupplier.EmailAddress = rdr["EmailAddress"].ToString();
                        otherSupplier.RejectionEmailAddress = rdr["RejectionEmailAddress"].ToString();
                        otherSupplier.PhoneNumber = rdr["PhoneNumber"].ToString();
                        otherSupplier.AltPhoneNumber = rdr["AltPhoneNumber"].ToString();
                        otherSupplier.ContactName = rdr["ContactName"].ToString();
                        otherSupplier.Owner = rdr["Owner"].ToString();
                        otherSupplier.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        otherSupplier.EnergySupply = Convert.ToInt32(rdr["Energy_Supply"].ToString());
                         otherSupplier.Active = Convert.ToBoolean(rdr["IsClient_Active"]);
                        othersupplierList.Add(otherSupplier);

                    }
                    con.Close();



                }
                return otherSupplier;
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// UpdateOtherSupplier
        /// </summary>
        /// <param name="otherSupplier"></param>
        /// <returns></returns>
        public OtherSupplier UpdateOtherSupplier(OtherSupplier otherSupplier)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(DbConstants.Sp_MasterAction, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", otherSupplier.SID);
                cmd.Parameters.AddWithValue("@Code", otherSupplier.SupplierCode);
                //cmd.Parameters.AddWithValue("@Description", otherSupplier.Description);
                cmd.Parameters.AddWithValue("@SupplierName", otherSupplier.SupplierName);
                cmd.Parameters.AddWithValue("@EmailAddress", otherSupplier.EmailAddress);
                cmd.Parameters.AddWithValue("@RejectionEmail", otherSupplier.RejectionEmailAddress);
                cmd.Parameters.AddWithValue("@PhoneNumber", otherSupplier.PhoneNumber);
                cmd.Parameters.AddWithValue("@AltPhoneNumber", otherSupplier.AltPhoneNumber);
                cmd.Parameters.AddWithValue("@ContactName", otherSupplier.ContactName);
                cmd.Parameters.AddWithValue("@Owner", otherSupplier.Owner);
                cmd.Parameters.AddWithValue("@IsActive", otherSupplier.IsActive);
                cmd.Parameters.AddWithValue("@IsClient_Active", otherSupplier.Active);
                cmd.Parameters.AddWithValue("@Energy_Supply", otherSupplier.EnergySupply);
                cmd.Parameters.AddWithValue("@UserId", otherSupplier.UserId);
                cmd.Parameters.AddWithValue("@Calling_Type", "Supplier");
                cmd.Parameters.Add("@result", SqlDbType.VarChar, 100);
                cmd.Parameters["@result"].Direction = ParameterDirection.Output;


                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
            return otherSupplier;
        }


    }
}


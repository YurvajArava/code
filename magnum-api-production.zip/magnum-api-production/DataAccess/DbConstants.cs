﻿namespace EXLETAPI.DataAccess
{
    public static class DbConstants
    {
        #region Multiple Use
        public const string Sp_UpdateStageCode = @"Usp_StageCode_Updation";
        public const string Sp_MasterAction = @"Usp_Master_Action";
        public const string Sp_GetMasterData = @"Usp_Master_GetData";
        #endregion

        #region GasWorkFlow
        //public const string Sp_GetGasData = @"Usp_RET_Getdata";
        public const string Sp_GetGasData = @"usp_GetElecGasOSROSIData";
        //public const string SP_UpdateGasFlowData = @"Usp_GasFlow_Updation";
        public const string Sp_GetProcessedGWFData = @"Usp_RET_GetDataExcel";
        public const string SP_GetProcessedCount = @"Usp_RET_GetDataExcelCount";
        //public const string SP_UpdateDataExcel = @"usp_RET_UpdateDataExcel";
        #endregion

        #region RetData Generation
        public const string Sp_GenerateRetDataforOS = @"usp_GenerateRetDataforOS";
        public const string Sp_UpdateRetData = @"usp_UpdateRetData";
        #endregion

        #region FollowUp

        public const string Sp_GetFollowUps = @"Usp_BG_Initiation_followup_records";
        public const string Sp_UpdateFollowUpDate = @"Usp_BG_Update_followup";
        public const string Sp_GetFollowUpforOps = @"Usp_BG_followup_records_forOps";
        public const string Sp_UpdateFollow_Ops = @"Usp_BG_Update_followup_ops";
        #endregion

        #region Gsop Compensation-C
        public const string SP_GetCompensation = @"usp_GSOP_GetStandardCData";

        #endregion

        #region OpsTask
        public const string Sp_OpsTaskSearchRecords = @"usp_OpsTask_Search";
        public const string Sp_OpsTaskRecordByMPRN = @"usp_OpsTask_GetRecordByMPRN";
        public const string Sp_OpsTaskUpdateETData = @"usp_OpsTask_UpdateET";
        #endregion

        #region Report
        public const string SP_MonthlyReport = @"usp_Monthly_Report";
       // public const string sp_GetElectricityData = @"Usp_USR_Getdata";
        public const string sp_GetElectricityData = @"usp_GetElecGasOSROSIData";
        public const string sp_CompensationData = @"Usp_Rpt_CompensationDetail";
        #endregion

        #region GSOP Standard A1
        public const string SP_GetGsopA1Data = @"Usp_GSOP_GetStandardA1Data";
        public const string SP_GetCompDetailbyRefId = @"usp_GetGsopcompDtl";
        public const string SP_UpdateCompDetailbyRefId = @"usp_UpdateGsopcompDtl";
        public const string SP_BulkImportStandardA1 = @"usp_BulkImport_StandardA1";
        #endregion

        #region GSOP Standard B
        public const string SP_GetGsopBData = @"Usp_GSOP_GetStandardBData";
        #endregion

        #region GSOP Standard BD
        public const string SP_GetGsopBDData = @"Usp_GSOP_GetStandardBDData";
        #endregion

        #region User Master
        public const string SP_AddUser = @"Usp_Usm_CreateUser";

        #endregion
    }
}

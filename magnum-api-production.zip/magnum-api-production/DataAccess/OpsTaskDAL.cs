﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class OpsTaskDAL : BaseDAL, IOpsTask
    {
        //private string connectionString;
        public OpsTaskDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }


        public IList<OpsTask> SearchRecords(OpsTaskSearch objInput)
        {
            try
            {
                List<OpsTask> lstOpsTask = new List<OpsTask>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_OpsTaskSearchRecords, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_MPRN", objInput.MPRN);
                    cmd.Parameters.AddWithValue("@P_SurName", objInput.SurName);
                    cmd.Parameters.AddWithValue("@P_PostCode", objInput.PostCode);
                    cmd.Parameters.AddWithValue("@P_HouseNo", objInput.HouseNo);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_UserId", objInput.UserId);
                    cmd.Parameters.AddWithValue("@P_ActivityStatus", objInput.OsActivity);

                    con.Open();

                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            OpsTask objRecords = new OpsTask();
                            objRecords.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            objRecords.EnergySupplyId = DbDataHelper.GetInt(rdr, "Energy_Supply");
                            objRecords.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            objRecords.CustomerName = DbDataHelper.GetString(rdr, "CustomerName");
                            objRecords.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            objRecords.Address3 = DbDataHelper.GetString(rdr, "Address3");
                            objRecords.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            objRecords.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                            objRecords.StageCode = DbDataHelper.GetString(rdr, "StageCode");
                            lstOpsTask.Add(objRecords);
                        }
                    }
                    con.Close();

                }
                return lstOpsTask;
            }
            catch
            {
                throw;
            }
        }

        public OpsTask GetByMPRN(long iRefId, int iEnergySupplyId, int iUserId)
        {
            try
            {
                OpsTask objRecords = new OpsTask();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_OpsTaskRecordByMPRN, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_RefId", iRefId);
                    cmd.Parameters.AddWithValue("@P_EnergySupplyId", iEnergySupplyId);
                    cmd.Parameters.AddWithValue("@P_UserId", iUserId);
                    con.Open();

                    using (IDataReader rdr = cmd.ExecuteReader())
                    {
                        while (rdr.Read())
                        {

                            objRecords.RefId = DbDataHelper.GetInt64(rdr, "RefID");
                            objRecords.EnergySupplyId = DbDataHelper.GetInt(rdr, "Energy_Supply");
                            objRecords.MPRN = DbDataHelper.GetString(rdr, "MPRN");
                            objRecords.EtType = DbDataHelper.GetString(rdr, "ET_Type");
                            objRecords.InitialContact = DbDataHelper.GetString(rdr, "Initial_Contact");
                            objRecords.Title = DbDataHelper.GetString(rdr, "Title");
                            objRecords.Initial = DbDataHelper.GetString(rdr, "Initial");
                            objRecords.SurName = DbDataHelper.GetString(rdr, "SurName");
                            objRecords.Address1 = DbDataHelper.GetString(rdr, "Address1");
                            objRecords.Address2 = DbDataHelper.GetString(rdr, "Address2");
                            objRecords.Address3 = DbDataHelper.GetString(rdr, "Address3");
                            objRecords.Address4 = DbDataHelper.GetString(rdr, "Address4");
                            objRecords.Address5 = DbDataHelper.GetString(rdr, "Address5");
                            objRecords.ContactTel = DbDataHelper.GetString(rdr, "ContactTel");
                            objRecords.Region = DbDataHelper.GetString(rdr, "Region");
                            objRecords.ReferenceNumber = DbDataHelper.GetString(rdr, "Reference_Number");
                            objRecords.DOT = DbDataHelper.GetDateTimeToString(rdr, "DOT");
                            objRecords.Iccd1 = DbDataHelper.GetDateTimeToString(rdr, "ICCD");
                            objRecords.RecordRejectionAcceptanceCode = DbDataHelper.GetString(rdr, "Record_Rejection_Acceptance_Code");
                            objRecords.Status = DbDataHelper.GetString(rdr, "Status");
                            objRecords.AssociatedOrganisationId = DbDataHelper.GetString(rdr, "Associated_Organisation_ID");
                            objRecords.RecievedDate1 = DbDataHelper.GetDateTimeToString(rdr, "RecievedDate");
                            objRecords.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
                            objRecords.ContactMethod = DbDataHelper.GetString(rdr, "Contact_Method");
                            objRecords.ReasonforReturn = DbDataHelper.GetString(rdr, "Reason_for_Return");
                            objRecords.TrackCode = DbDataHelper.GetString(rdr, "Track_Code");
                            objRecords.CancellationReasonId = DbDataHelper.GetNullableInt(rdr, "Cancellation_Reason");
                            objRecords.CancellationReasonSubCategoryId = DbDataHelper.GetNullableInt(rdr, "Cancellation_Reason_SubCategory");
                            objRecords.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                            objRecords.GasPreviousSupplier = DbDataHelper.GetString(rdr, "PrevSupplier");
                            objRecords.GasOtherPreviousSupplier = DbDataHelper.GetString(rdr, "OtherPrevSupplier");
                            objRecords.WithEffDate = DbDataHelper.GetString(rdr, "WithEffDate");
                            objRecords.FinalRead = DbDataHelper.GetString(rdr, "FinalRead");
                            objRecords.MeterSerialNumber = DbDataHelper.GetString(rdr, "Meter_Serial_Number");
                            objRecords.MeterReading = DbDataHelper.GetString(rdr, "Meter_Reading");
                            objRecords.MeterReadingType = DbDataHelper.GetString(rdr, "Meter_Reading_Type");
                            objRecords.BgComments = DbDataHelper.GetString(rdr, "BG_Comments");
                            objRecords.OsComments = DbDataHelper.GetString(rdr, "OS_Comments");
                            objRecords.PremiseNumber = DbDataHelper.GetString(rdr, "PremiseNumber");
                            objRecords.BusinessPartner = DbDataHelper.GetString(rdr, "Business_Partner");
                            objRecords.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                            objRecords.CompensationGiven = DbDataHelper.GetString(rdr, "Compensation_Given");
                            objRecords.CompensationDate = DbDataHelper.GetNullableDateTime(rdr, "Compensation_Date");
                            objRecords.StageCode = DbDataHelper.GetString(rdr, "StageCode");
                            objRecords.UpdatedOn1 = DbDataHelper.GetDateTimeToString(rdr, "UpdatedOn");
                            objRecords.ContractAccount = DbDataHelper.GetString(rdr, "Contract_Account");
                            objRecords.SalesOrderDesc = DbDataHelper.GetString(rdr, "SalesOrderDesc");
                            objRecords.MKTFileSendDate1 = DbDataHelper.GetDateTimeToString(rdr, "MKT_FileSendDate");
                            objRecords.RecordInError = DbDataHelper.GetBoolean(rdr, "RecordInError");
                            objRecords.LetterDate1 = DbDataHelper.GetDateTimeToString(rdr, "LetterDate");
                            objRecords.ThreadCode = DbDataHelper.GetString(rdr, "ThreadCode");
                        }
                    }
                    con.Close();

                }
                return objRecords;
            }
            catch
            {
                throw;
            }
        }

        public Status OpsTaskUpdateETData(string jsonData, int iUserId, int iEnergyId)
        {
            Status _output = new Status();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.Sp_OpsTaskUpdateETData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Data", jsonData);
                    cmd.Parameters.AddWithValue("@P_UserId", iUserId);
                    cmd.Parameters.AddWithValue("@P_EnergySupply", iEnergyId);
                    //cmd.Parameters.AddWithValue("@P_UpdateMode", iUpdateMode);
                    cmd.Parameters.Add("@P_UpdStatusCode", SqlDbType.Int);
                    cmd.Parameters["@P_UpdStatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_UpdStatusMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_UpdStatusMsg"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    _output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_UpdStatusCode"].Value);
                    _output.StatusMessage = cmd.Parameters["@P_UpdStatusMsg"].Value.ToString();
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
            return _output;
        }
    }
}

﻿using Microsoft.Extensions.Configuration;

namespace EXLETAPI.DataAccess
{
    public abstract class BaseDAL
    {

        public static string connectionString { get; private set; }
        //private IWebHostEnvironment _hostingEnvironment { get; set; }
        public BaseDAL(IConfiguration configuration)
        {

            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
            connectionString = configuration["sqlconnectionstringapi"];
        }
    }
}

﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class DataSanityDAL : BaseDAL, IDSDataSanity
    {


        //List<TodayCount> todayCounts = new List<TodayCount>();
        List<SapAction> dsMpanDownloadList = new List<SapAction>();
        List<DcfEmail> dcfEmails = new List<DcfEmail>();

        public DataSanityDAL(IConfiguration configuration) : base(configuration)
        {
            //connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }

        public string DeleteStaggingRecords(List<DataSanityUpdate> data, int UserId)
        {
            string ErrorOutputmsg = string.Empty;
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_DeleteRecords", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Value", json);
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.Add("@OutMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@OutMsg"].Direction = ParameterDirection.Output;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    ErrorOutputmsg = cmd.Parameters["@OutMsg"].Value.ToString();
                    con.Close();

                }
            }
            catch
            {
                throw;
            }
            return ErrorOutputmsg;
        }



        public IEnumerable<DataSanityModel> GetStaggingRecords()
        {
            List<DataSanityModel> dSDataSanityList = new List<DataSanityModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", "");
                    cmd.Parameters.AddWithValue("@StartDate", "");
                    cmd.Parameters.AddWithValue("@EndDate", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "DATASANITY");
                    //cmd.Parameters.Add("@Records", SqlDbType.Int);
                    //cmd.Parameters["@Records"].Direction = ParameterDirection.Output;
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    TodayCount count = new TodayCount();


                    while (rdr.Read())
                    {
                        DataSanityModel dSDataSanity = new DataSanityModel();
                      dSDataSanity.ID = Convert.ToInt32(rdr["ID"].ToString());
                      dSDataSanity.EnergySupplyId = Convert.ToInt32(rdr["EnergySupply_ID"].ToString());
                        dSDataSanity.EnergySupply = rdr["Energy_Supply"].ToString();
                      dSDataSanity.PaymentMethodId = Convert.ToInt32(rdr["Payment_Method_ID"].ToString());
                  dSDataSanity.CancellationReasonId = Convert.ToInt32(rdr["Cancellation_Reason_ID"].ToString());
                   dSDataSanity.CancellationReasonSubCategoryId = Convert.ToInt32(rdr["CancellationReason_SubCategory_ID"].ToString());
                        dSDataSanity.EtType = rdr["ET_Type"].ToString();
                        dSDataSanity.InitialContact = rdr["Initial_Contact"].ToString();
                        dSDataSanity.ContactMethod = rdr["Contact_Method"].ToString();
                        dSDataSanity.Address1 = rdr["Address1"].ToString();
                        dSDataSanity.Address2 = rdr["Address2"].ToString();
                        dSDataSanity.Address3 = rdr["Address3"].ToString();
                        dSDataSanity.Address4 = rdr["Address4"].ToString();
                        dSDataSanity.Address5 = rdr["Address5"].ToString();
                        dSDataSanity.AgentId = rdr["Agent_Id"].ToString();
                        dSDataSanity.C1Reference = rdr["C1_Reference"].ToString();
                        dSDataSanity.CallerName = rdr["Caller_Name"].ToString();
                        dSDataSanity.CancellationReason = rdr["Cancellation_Reason"].ToString();
                        dSDataSanity.CancellationReasonSubCategory = rdr["Cancellation_Reason_SubCategory"].ToString();
                        dSDataSanity.CancellationResonAdditionalInfo = rdr["Cancellation_Reason_Additional_Info"].ToString();
                        dSDataSanity.CompensationAgreed = rdr["Compensation_Agreed"].ToString();
                        dSDataSanity.ContactTel = rdr["ContactTel"].ToString();
                        dSDataSanity.CSENameVerbal = rdr["CSE_Name_Verbal"].ToString();
                       dSDataSanity.ElectricitySSD = DbDataHelper.GetNullableDateTime(rdr,"Electricity_SSD");
                        dSDataSanity.ElecOtherPreviousSupplier = rdr["Elec_Other_Previous_Supplier"].ToString();
                        dSDataSanity.ElecPreviousSupplier = rdr["Elec_Previous_Supplier"].ToString();
                        dSDataSanity.GasOtherPreviousSupplier = rdr["Gas_Other_Previous_Supplier"].ToString();
                        dSDataSanity.GasPreviousSupplier = rdr["Gas_Previous_Supplier"].ToString();
                        dSDataSanity.GASSSD =DbDataHelper.GetNullableDateTime(rdr,"GAS_SSD");
                        dSDataSanity.GasTransporter = rdr["Gas_Transporter"].ToString();
                        dSDataSanity.HomeTel = rdr["HomeTel"].ToString();
                        dSDataSanity.ICCD = DbDataHelper.GetNullableDateTime(rdr,"ICCD");
                        dSDataSanity.Initial = rdr["Initial"].ToString();
                        dSDataSanity.MPAN = rdr["MPAN"].ToString();
                        dSDataSanity.IsProcess = rdr["IsProcess"].ToString();
                        dSDataSanity.MPRN = rdr["MPRN"].ToString();
                        dSDataSanity.NSSAccRef = rdr["NSS_Acc_Ref"].ToString();
                        dSDataSanity.NSSInputDate =DbDataHelper.GetNullableDateTime(rdr, "NSS_Input_Date");
                        dSDataSanity.Origin = rdr["Origin"].ToString();
                        dSDataSanity.PaymentMethod = rdr["Payment_Method"].ToString();
                        dSDataSanity.ProhibitCustomerContact = rdr["Prohibit_Customer_Contact"].ToString();
                        dSDataSanity.PromotionalReference = rdr["Promotional_Reference"].ToString();
                       dSDataSanity.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        dSDataSanity.SalesChannel = rdr["Sales_Channel"].ToString();
                        dSDataSanity.SalesLocation = rdr["Sales_Location"].ToString();
                        dSDataSanity.SalesRepId = rdr["Sales_Rep_Id"].ToString();
                        dSDataSanity.SurName = rdr["SurName"].ToString();
                        dSDataSanity.System = rdr["System"].ToString();
                        dSDataSanity.TGBReference = rdr["TGBReference"].ToString();
                        dSDataSanity.Title = rdr["Title"].ToString();
                        dSDataSanity.UserId = rdr["User_Id"].ToString();
                        dSDataSanity.records = count.Records;
                        dSDataSanityList.Add(dSDataSanity);

                    }

                    con.Close();



                }

                return dSDataSanityList;
            }
            catch(Exception ex)
            {
                  using (SqlConnection con = new SqlConnection(connectionString))
                  {
                     InsertingLogs("CallingDataSanity:: Error" + ex.Message + " > Trace " + ex.StackTrace, "GetStagingRecords", con);
                  }
                throw;
            }
        }
        public void InsertingLogs(string Message, string events, SqlConnection con)
        {
            try
            {
                DataTable dt = new DataTable();
                //SqlConnection con = connection();
                SqlCommand cmd = new SqlCommand("[dbo].[Usp_InsertLogs]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@event", SqlDbType.Text).Value = events;
                cmd.Parameters.Add("@Message", SqlDbType.Text).Value = Message;
                con.Open();
                int sqlRows = cmd.ExecuteNonQuery();
                con.Close();
            }
            catch
            {
                         throw;
            }          
        }
        public IEnumerable<DataSanityModel> SearchStaggingRecords(string MPXN, string sdate, string edate)
        {
            List<DataSanityModel> dSDataSanityList = new List<DataSanityModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", MPXN);
                    cmd.Parameters.AddWithValue("@StartDate", sdate);
                    cmd.Parameters.AddWithValue("@EndDate", edate);
                    cmd.Parameters.AddWithValue("@Calling_Type", "DATASANITY");

                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        DataSanityModel dSDataSanity = new DataSanityModel();
                        dSDataSanity.ID = Convert.ToInt32(rdr["ID"].ToString());
                        dSDataSanity.EnergySupplyId = Convert.ToInt32(rdr["EnergySupply_ID"].ToString());
                        dSDataSanity.EnergySupply = rdr["Energy_Supply"].ToString();
                        dSDataSanity.PaymentMethodId = Convert.ToInt32(rdr["Payment_Method_ID"].ToString());
                        dSDataSanity.CancellationReasonId = Convert.ToInt32(rdr["Cancellation_Reason_ID"].ToString());
                        dSDataSanity.CancellationReasonSubCategoryId = Convert.ToInt32(rdr["CancellationReason_SubCategory_ID"].ToString());
                        dSDataSanity.EnergySupply = rdr["Energy_Supply"].ToString();
                        dSDataSanity.EtType = rdr["ET_Type"].ToString();
                        dSDataSanity.InitialContact = rdr["Initial_Contact"].ToString();
                        dSDataSanity.ContactMethod = rdr["Contact_Method"].ToString();
                        dSDataSanity.Address1 = rdr["Address1"].ToString();
                        dSDataSanity.Address2 = rdr["Address2"].ToString();
                        dSDataSanity.Address3 = rdr["Address3"].ToString();
                        dSDataSanity.Address4 = rdr["Address4"].ToString();
                        dSDataSanity.Address5 = rdr["Address5"].ToString();
                        dSDataSanity.AgentId = rdr["Agent_Id"].ToString();
                        dSDataSanity.C1Reference = rdr["C1_Reference"].ToString();
                        dSDataSanity.CallerName = rdr["Caller_Name"].ToString();
                        dSDataSanity.CancellationReason = rdr["Cancellation_Reason"].ToString();
                        dSDataSanity.CancellationReasonSubCategory = rdr["Cancellation_Reason_SubCategory"].ToString();
                        dSDataSanity.CancellationResonAdditionalInfo = rdr["Cancellation_Reason_Additional_Info"].ToString();
                        dSDataSanity.CompensationAgreed = rdr["Compensation_Agreed"].ToString();
                        dSDataSanity.ContactTel = rdr["ContactTel"].ToString();
                        dSDataSanity.CSENameVerbal = rdr["CSE_Name_Verbal"].ToString();
                        dSDataSanity.ElectricitySSD = DbDataHelper.GetNullableDateTime(rdr,"Electricity_SSD");
                        dSDataSanity.ElecOtherPreviousSupplier = rdr["Elec_Other_Previous_Supplier"].ToString();
                        dSDataSanity.ElecPreviousSupplier = rdr["Elec_Previous_Supplier"].ToString();
                        dSDataSanity.GasOtherPreviousSupplier = rdr["Gas_Other_Previous_Supplier"].ToString();
                        dSDataSanity.GasPreviousSupplier = rdr["Gas_Previous_Supplier"].ToString();
                        dSDataSanity.GASSSD = DbDataHelper.GetNullableDateTime(rdr,"GAS_SSD");
                        dSDataSanity.GasTransporter = rdr["Gas_Transporter"].ToString();
                        dSDataSanity.HomeTel = rdr["HomeTel"].ToString();
                        dSDataSanity.ICCD =DbDataHelper.GetNullableDateTime(rdr,"ICCD");
                        dSDataSanity.Initial = rdr["Initial"].ToString();
                        dSDataSanity.MPAN = rdr["MPAN"].ToString();
                        dSDataSanity.IsProcess = rdr["IsProcess"].ToString();
                        dSDataSanity.MPRN = rdr["MPRN"].ToString();
                        dSDataSanity.NSSAccRef = rdr["NSS_Acc_Ref"].ToString();
                        dSDataSanity.NSSInputDate = DbDataHelper.GetNullableDateTime(rdr, "NSS_Input_Date");
                        dSDataSanity.Origin = rdr["Origin"].ToString();
                        dSDataSanity.PaymentMethod = rdr["Payment_Method"].ToString();
                        dSDataSanity.ProhibitCustomerContact = rdr["Prohibit_Customer_Contact"].ToString();
                        dSDataSanity.PromotionalReference = rdr["Promotional_Reference"].ToString();
                        dSDataSanity.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        dSDataSanity.SalesChannel = rdr["Sales_Channel"].ToString();
                        dSDataSanity.SalesLocation = rdr["Sales_Location"].ToString();
                        dSDataSanity.SalesRepId = rdr["Sales_Rep_Id"].ToString();
                        dSDataSanity.SurName = rdr["SurName"].ToString();
                        dSDataSanity.System = rdr["System"].ToString();
                        dSDataSanity.TGBReference = rdr["TGBReference"].ToString();
                        dSDataSanity.Title = rdr["Title"].ToString();
                        dSDataSanity.UserId = rdr["User_Id"].ToString();
                        dSDataSanity.records = Convert.ToInt32(rdr["total"].ToString());
                        dSDataSanityList.Add(dSDataSanity);

                    }
                    con.Close();



                }
                return dSDataSanityList;
            }
             catch(Exception ex)
            {
              using (SqlConnection con = new SqlConnection(connectionString))
                  {
                     InsertingLogs("CallingDataSanity:: Error" + ex.Message + " > Trace " + ex.StackTrace, "SearchDataRecords", con);
                  }
                throw;
            }
        }



        public string UpdateStaggingRecords(List<DataSanityUpdate> data, int UserId)
        {
            string ErrorOutputmsg = string.Empty;
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_DataSanity", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Value", json);
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    cmd.Parameters.Add("@OutMsg", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@OutMsg"].Direction = ParameterDirection.Output;
                    //cmd.Parameters.AddWithValue("@Calling_Type", "DATASANITY");
                    con.Open();
                    cmd.ExecuteNonQuery();
                    ErrorOutputmsg = cmd.Parameters["@OutMsg"].Value.ToString();
                    con.Close();

                }
            }
            catch
            {
                throw;
            }
            return ErrorOutputmsg;
        }

        public IEnumerable<SapAction> SapActionRecords()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", "");
                    cmd.Parameters.AddWithValue("@StartDate", "");
                    cmd.Parameters.AddWithValue("@EndDate", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "DOWNLOADMPAN");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        SapAction dsSapAction = new SapAction();

                        dsSapAction.RefId = Convert.ToInt32(rdr["REFID"]);
                        dsSapAction.MPAN = rdr["DOWNLOADMPAN"].ToString();
                        dsSapAction.Status = rdr["STATUS"].ToString();
                        dsSapAction.ObjWindow = rdr["OBJWINDOW"].ToString();
                        dsSapAction.SSD = rdr["SSD"].ToString();
                        dsSapAction.SED = rdr["SED"].ToString();
                        dsSapAction.PreSupplier = rdr["PRE_SUPPLIER"].ToString();

                        dsMpanDownloadList.Add(dsSapAction);

                    }
                    con.Close();



                }
                return dsMpanDownloadList;
            }
            catch
            {
                throw;
            }
        }

        public string UpdateSapData(List<SapActionUpdate> data)
        {
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Sap_Action", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Value", json);
                    //cmd.Parameters.AddWithValue("@UserId", 101);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return null;
                }
            }
            catch
            {
                throw;
            }
        }



        public IEnumerable<DcfEmail> DcfEmailRecords()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", "");
                    cmd.Parameters.AddWithValue("@StartDate", "");
                    cmd.Parameters.AddWithValue("@EndDate", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "DCFEMAIL");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        DcfEmail dcfEmail = new DcfEmail();
                        dcfEmail.EnergySupply = rdr["EnergySupply"].ToString();
                        dcfEmail.CountOfEnergySupply = rdr["CountOfEnergySupply"].ToString();
                        dcfEmails.Add(dcfEmail);

                    }
                    con.Close();



                }
                return dcfEmails;
            }
            catch
            {
                throw;
            }
        }

        public TodayCount TodayRecords()
        {
            try
            {
                TodayCount todayCount = new TodayCount();
                using (SqlConnection con = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", "");
                    cmd.Parameters.AddWithValue("@StartDate", "");
                    cmd.Parameters.AddWithValue("@EndDate", "");
                    cmd.Parameters.AddWithValue("@Calling_Type", "TODAYCOUNT");
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {

                        todayCount.Records = Convert.ToInt32(rdr["Total"]);


                    }
                    con.Close();



                }
                return todayCount;
            }
            catch
            {
                throw;
            }
        }

       // public IEnumerable<DataSanityModel> GetCreateFileRecords()
        public IEnumerable<DataSanityModel> GetCreateFileRecords(string sdate, string edate)
        {
            List<DataSanityModel> dSDataSanityList = new List<DataSanityModel>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Dcf_Getdata", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mpxn", "");
                    cmd.Parameters.AddWithValue("@StartDate", sdate);
                    cmd.Parameters.AddWithValue("@EndDate", edate);
                    cmd.Parameters.AddWithValue("@Calling_Type", "CREATEBGFILE");
                    //cmd.Parameters.Add("@Result", SqlDbType.VarChar, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        DataSanityModel dSDataSanity = new DataSanityModel();

                        dSDataSanity.EnergySupply = rdr["Energy_Supply"].ToString();

                        dSDataSanity.EtType = rdr["ET_Type"].ToString();
                        dSDataSanity.InitialContact = rdr["Initial_Contact"].ToString();
                        dSDataSanity.ContactMethod = rdr["Contact_Method"].ToString();
                        dSDataSanity.Address1 = rdr["Address1"].ToString();
                        dSDataSanity.Address2 = rdr["Address2"].ToString();
                        dSDataSanity.Address3 = rdr["Address3"].ToString();
                        dSDataSanity.Address4 = rdr["Address4"].ToString();
                        dSDataSanity.Address5 = rdr["Address5"].ToString();
                        dSDataSanity.AgentId = rdr["Agent_Id"].ToString();
                        dSDataSanity.C1Reference = rdr["C1_Reference"].ToString();
                        dSDataSanity.CallerName = rdr["Caller_Name"].ToString();
                        dSDataSanity.CancellationReason = rdr["Cancellation_Reason"].ToString();
                        dSDataSanity.CancellationReasonSubCategory = rdr["Cancellation_Reason_SubCategory"].ToString();
                        dSDataSanity.CancellationResonAdditionalInfo = rdr["Cancellation_Reason_Additional_Info"].ToString();
                        dSDataSanity.CompensationAgreed = rdr["Compensation_Agreed"].ToString();
                        dSDataSanity.ContactTel = rdr["ContactTel"].ToString();
                        dSDataSanity.CSENameVerbal = rdr["CSE_Name_Verbal"].ToString();
                        dSDataSanity.ElectricitySSD = DbDataHelper.GetNullableDateTime(rdr,"Electricity_SSD");
                        dSDataSanity.ElecOtherPreviousSupplier = rdr["Elec_Other_Previous_Supplier"].ToString();
                        dSDataSanity.ElecPreviousSupplier = rdr["Elec_Previous_Supplier"].ToString();
                        dSDataSanity.GasOtherPreviousSupplier = rdr["Gas_Other_Previous_Supplier"].ToString();
                        dSDataSanity.GasPreviousSupplier = rdr["Gas_Previous_Supplier"].ToString();
                        dSDataSanity.GASSSD = DbDataHelper.GetNullableDateTime(rdr,"GAS_SSD");
                        dSDataSanity.GasTransporter = rdr["Gas_Transporter"].ToString();
                        dSDataSanity.HomeTel = rdr["HomeTel"].ToString();
                        dSDataSanity.ICCD =DbDataHelper.GetNullableDateTime(rdr,"ICCD");
                        dSDataSanity.Initial = rdr["Initial"].ToString();
                        dSDataSanity.MPAN = rdr["MPAN"].ToString();
                        //dSDataSanity.IsProcess = rdr["IsProcess"].ToString();
                        dSDataSanity.MPRN = rdr["MPRN"].ToString();
                        dSDataSanity.NSSAccRef = rdr["NSS_Acc_Ref"].ToString();
                        dSDataSanity.NSSInputDate = DbDataHelper.GetNullableDateTime(rdr, "NSS_Input_Date");
                        dSDataSanity.Origin = rdr["Origin"].ToString();
                        dSDataSanity.PaymentMethod = rdr["Payment_Method"].ToString();
                        dSDataSanity.ProhibitCustomerContact = rdr["Prohibit_Customer_Contact"].ToString();
                        dSDataSanity.PromotionalReference = rdr["Promotional_Reference"].ToString();
                        dSDataSanity.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        dSDataSanity.SalesChannel = rdr["Sales_Channel"].ToString();
                        dSDataSanity.SalesLocation = rdr["Sales_Location"].ToString();
                        dSDataSanity.SalesRepId = rdr["Sales_Rep_Id"].ToString();
                        dSDataSanity.SurName = rdr["SurName"].ToString();
                        dSDataSanity.System = rdr["System"].ToString();
                        dSDataSanity.TGBReference = rdr["TGBReference"].ToString();
                        dSDataSanity.Title = rdr["Title"].ToString();
                        dSDataSanity.UserId = rdr["User_Id"].ToString();
                        dSDataSanityList.Add(dSDataSanity);

                    }
                    con.Close();



                }
                return dSDataSanityList;
            }
            catch
            {
                throw;
            }
        }
    }


}



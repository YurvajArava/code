using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace EXLETAPI.DataAccess
{
    public class GSOPDAL : BaseDAL, IGSOP
    {
        // private string connectionString;
        public GSOPDAL(IConfiguration configuration) : base(configuration)
        {
        }

        #region Standard A1
        public IEnumerable<GSOPStandardAone> GetGSOPAoneData(GSOPA1Search objInput)
        {
            try
            {
                List<GSOPStandardAone> lstGsopA1Data = new List<GSOPStandardAone>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetGsopA1Data, con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    //Convert.ToDateTime(StartDate);
                    //Convert.ToDateTime(EndDate);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        GSOPStandardAone objOutput = new GSOPStandardAone();
                        objOutput.RefId = DbDataHelper.GetInt64(rdr, "RefId");
                        objOutput.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                        objOutput.Dot = DbDataHelper.GetNullableDateTime(rdr, "DOT");
                        objOutput.ContractAccount = DbDataHelper.GetString(rdr, "ContractAccount");
                        objOutput.BusinessPartner = DbDataHelper.GetString(rdr, "BusinessPartner");
                        objOutput.Title = DbDataHelper.GetString(rdr, "Title");
                        objOutput.Initial = DbDataHelper.GetString(rdr, "Initial");
                        objOutput.SurName = DbDataHelper.GetString(rdr, "SurName");
                        objOutput.Address1 = DbDataHelper.GetString(rdr, "Address1");
                        objOutput.Address2 = DbDataHelper.GetString(rdr, "Address2");
                        objOutput.Address3 = DbDataHelper.GetString(rdr, "Address3");
                        objOutput.Address4 = DbDataHelper.GetString(rdr, "Address4");
                        objOutput.Address5 = DbDataHelper.GetString(rdr, "Address5");
                        objOutput.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                        objOutput.AgreedDate = DbDataHelper.GetNullableDateTime(rdr, "AgreedDate");
                        objOutput.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        objOutput.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                        objOutput.GsopEligibleDate = DbDataHelper.GetNullableDateTime(rdr, "GSOPEligibleDate");
                        objOutput.SSD = DbDataHelper.GetString(rdr, "SSD");
                        objOutput.NetWorkingDays = DbDataHelper.GetNullableInt(rdr, "NetWorkingDays");
                        objOutput.InitiatedBy = DbDataHelper.GetString(rdr, "InitiatedBy");
                        objOutput.SalesOrderDesc = DbDataHelper.GetString(rdr, "SalesOrderDesc");
                        objOutput.CustomerName = DbDataHelper.GetString(rdr, "ContactName");
                        objOutput.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                        objOutput.CompensationGiven = DbDataHelper.GetString(rdr, "CompensationGiven");
                        objOutput.CompensationDate = DbDataHelper.GetNullableDateTime(rdr, "CompensationDate");
                        objOutput.Remarks = DbDataHelper.GetString(rdr, "Remarks");
                        objOutput.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
                     
objOutput.DuplicatePartner = DbDataHelper.GetString(rdr, "Duplicate");
                        lstGsopA1Data.Add(objOutput);
                    }

                    con.Close();
                }
                return lstGsopA1Data;
            }
            catch
            {
                throw;
            }

        }

        public CompensationDetail GetCompensationDetail(long RefId, string CompType)
        {
            try
            {
                CompensationDetail objOutput = new CompensationDetail();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetCompDetailbyRefId, con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    //Convert.ToDateTime(StartDate);
                    //Convert.ToDateTime(EndDate);
                    cmd.Parameters.AddWithValue("@P_RefId", RefId);
                    cmd.Parameters.AddWithValue("@P_CompType", CompType);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    if (rdr.Read())
                    {
                        objOutput.RefId = DbDataHelper.GetInt64(rdr, "RefId");
                        objOutput.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                        objOutput.OrderDescription = DbDataHelper.GetString(rdr, "OrderDescription");
                        objOutput.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                        objOutput.CompensationGiven = DbDataHelper.GetString(rdr, "Compensation_Given");
                        objOutput.SdepResponseRecdDate = DbDataHelper.GetDateTimeToString(rdr, "SdepResponseRecd");
                        objOutput.SdepName = DbDataHelper.GetString(rdr, "SdepName");
                        objOutput.SdepAddress = DbDataHelper.GetString(rdr, "SdepAddress");
                        objOutput.SSD = DbDataHelper.GetString(rdr, "SSD");
                        objOutput.CompensationDate = DbDataHelper.GetDateTimeToString(rdr, "Compensation_Date");
                    }
                    con.Close();
                }
                return objOutput;
            }
            catch
            {
                throw;
            }
        }

        public int UpdateCompensationDetail(CompensationDetail objInput)
        {
            try
            {
                int rowsAffected = 0;
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_UpdateCompDetailbyRefId, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_RefId", objInput.RefId);
                    cmd.Parameters.AddWithValue("@P_CompType", objInput.CompensationType);
                    cmd.Parameters.AddWithValue("@P_CompGiven", objInput.CompensationGiven);
                    cmd.Parameters.AddWithValue("@P_CompDate", objInput.CompensationDate);
                    cmd.Parameters.AddWithValue("@P_OrderDesc", objInput.OrderDescription);
                    cmd.Parameters.AddWithValue("@P_SSD", objInput.SSD);
                    cmd.Parameters.AddWithValue("@P_SdepDate", objInput.SdepResponseRecdDate);
                    cmd.Parameters.AddWithValue("@P_SdepName", objInput.SdepName);
                    cmd.Parameters.AddWithValue("@P_SdepAddress", objInput.SdepAddress);
                    cmd.Parameters.AddWithValue("@P_UserId", objInput.updateUserId);

                    con.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();
                }
                return rowsAffected;
            }
            catch
            {
                throw;
            }
        }

        public Status ImportGsopData(GsopStandardAUpdateViewModel objInput)
        {
            Status _output = new Status();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_BulkImportStandardA1, con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@P_FileName", objInput.fileDetail.FileName);
                    cmd.Parameters.AddWithValue("@P_NoOfRows", objInput.fileDetail.NoOfRows);
                    cmd.Parameters.AddWithValue("@P_FileData", JsonConvert.SerializeObject(objInput.lstA1Update));
                    cmd.Parameters.AddWithValue("@P_FileType", objInput.fileDetail.FileType);
                    cmd.Parameters.AddWithValue("@P_Type", objInput.StandardType);
                    cmd.Parameters.AddWithValue("@P_UserId", objInput.fileDetail.UserId);

                    //cmd.Parameters.AddWithValue("@P_UpdateMode", iUpdateMode);
                    //cmd.Parameters.Add("@P_UpdStatusCode", SqlDbType.Int);
                    //cmd.Parameters["@P_UpdStatusCode"].Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@P_UploadStatus", SqlDbType.NVarChar, 500);
                    cmd.Parameters["@P_UploadStatus"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    //_output.StatusCode = Convert.ToInt16(cmd.Parameters["@P_UpdStatusCode"].Value);
                    _output.StatusMessage = cmd.Parameters["@P_UploadStatus"].Value.ToString();
                    con.Close();
                }
            }
            catch
            {
                throw;
            }
            return _output;
        }
        #endregion

        public IEnumerable<GSOPStandardB> GetGSOPBData(GsopBSearch objInput)
        {
            try
            {
                List<GSOPStandardB> lstGsopB = new List<GSOPStandardB>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetGsopBData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    //Convert.ToDateTime(StartDate);
                    //Convert.ToDateTime(EndDate);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        GSOPStandardB objOutput = new GSOPStandardB();
                        objOutput.RefId = DbDataHelper.GetInt64(rdr, "RefId");
                        objOutput.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                        objOutput.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                        objOutput.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        objOutput.RecievedDaysFromICCD = DbDataHelper.GetNullableInt(rdr, "RecievedDaysFromICCD");
                        objOutput.SupplierCode = DbDataHelper.GetString(rdr, "SupplierCode");
                        objOutput.ETType = DbDataHelper.GetString(rdr, "ETType");
                        objOutput.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                        objOutput.ReasonforReturn = DbDataHelper.GetString(rdr, "ReasonforReturn");
                        objOutput.FileSendDate = DbDataHelper.GetNullableDateTime(rdr, "FileSendDate");
                        objOutput.Status = DbDataHelper.GetString(rdr, "Status");
                        objOutput.ResponseDaysFromICCD = DbDataHelper.GetNullableInt(rdr, "ResponseDaysFromICCD");
                        objOutput.ContractAccount = DbDataHelper.GetString(rdr, "ContractAccount");
                        objOutput.BusinessPartner = DbDataHelper.GetString(rdr, "BusinessPartner");
                        objOutput.Title = DbDataHelper.GetString(rdr, "Title");
                        objOutput.FirstName = DbDataHelper.GetString(rdr, "Initial");
                        objOutput.SurName = DbDataHelper.GetString(rdr, "SurName");
                        objOutput.Address1 = DbDataHelper.GetString(rdr, "Address1");
                        objOutput.Address2 = DbDataHelper.GetString(rdr, "Address2");
                        objOutput.Address3 = DbDataHelper.GetString(rdr, "Address3");
                        objOutput.Address4 = DbDataHelper.GetString(rdr, "Address4");
                        objOutput.PostageCode = DbDataHelper.GetString(rdr, "Address5");
                        objOutput.Standard = DbDataHelper.GetString(rdr, "Standard");
                        objOutput.Postage = DbDataHelper.GetString(rdr, "Postage");
                        objOutput.Comments = DbDataHelper.GetString(rdr, "BGComments");
                        objOutput.CustomerName = DbDataHelper.GetString(rdr, "ContactName");
                        objOutput.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                        objOutput.CompensationGiven = DbDataHelper.GetString(rdr, "CompensationGiven");
                        objOutput.CompensationDate = DbDataHelper.GetNullableDateTime(rdr, "CompensationDate");
                        objOutput.SdepResponseDate = DbDataHelper.GetNullableDateTime(rdr, "SdepResponseRecd");
                        objOutput.SdepName = DbDataHelper.GetString(rdr, "SdepName");
                        objOutput.SdepAddress = DbDataHelper.GetString(rdr, "SdepAddress");
                        objOutput.Remarks = DbDataHelper.GetString(rdr, "Remarks");
                       objOutput.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
objOutput.DuplicatePartner = DbDataHelper.GetString(rdr, "Duplicate");
                        lstGsopB.Add(objOutput);
                    }
                    con.Close();
                }
                return lstGsopB;
            }
            catch
            {
                throw;
            }

        }

        public IEnumerable<GSOPStandardBD> GetGSOPBDData(GsopBDSearch objInput)
        {
            try
            {
                List<GSOPStandardBD> lstBD = new List<GSOPStandardBD>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(DbConstants.SP_GetGsopBDData, con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    //Convert.ToDateTime(StartDate);
                    //Convert.ToDateTime(EndDate);
                    cmd.Parameters.AddWithValue("@P_StartDate", objInput.StartDate);
                    cmd.Parameters.AddWithValue("@P_EndDate", objInput.EndDate);
                    cmd.Parameters.AddWithValue("@P_MPXN", objInput.MPXN);
                    con.Open();

                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        GSOPStandardBD objOutput = new GSOPStandardBD();
                        objOutput.RefId = DbDataHelper.GetInt64(rdr, "RefId");
                        objOutput.MPXN = DbDataHelper.GetString(rdr, "MPXN");
                        objOutput.ICCD = DbDataHelper.GetNullableDateTime(rdr, "ICCD");
                        objOutput.RecievedDate = DbDataHelper.GetNullableDateTime(rdr, "RecievedDate");
                        objOutput.RecievedDaysFromICCD = DbDataHelper.GetNullableInt(rdr, "RecievedDaysFromICCD");
                        objOutput.FileSendDate = DbDataHelper.GetNullableDateTime(rdr, "FileSendDate");
                        objOutput.ResponseDaysFromICCD = DbDataHelper.GetNullableInt(rdr, "ResponseDaysFromICCD");
                        objOutput.CompDueDate = DbDataHelper.GetNullableDateTime(rdr, "CompDueDate");
                        objOutput.CompDueDays = DbDataHelper.GetNullableInt(rdr, "CompDueDays");
                        objOutput.ETType = DbDataHelper.GetString(rdr, "ETType");
                        objOutput.ReasonforReturn = DbDataHelper.GetString(rdr, "ReasonforReturn");
                        objOutput.ExclusionCode = DbDataHelper.GetString(rdr, "ExclusionCode");
                        objOutput.ContractAccount = DbDataHelper.GetString(rdr, "ContractAccount");
                        objOutput.BusinessPartner = DbDataHelper.GetString(rdr, "BusinessPartner");
                        objOutput.Title = DbDataHelper.GetString(rdr, "Title");
                        objOutput.FirstName = DbDataHelper.GetString(rdr, "Initial");
                        objOutput.SurName = DbDataHelper.GetString(rdr, "SurName");
                        objOutput.Address1 = DbDataHelper.GetString(rdr, "Address1");
                        objOutput.Address2 = DbDataHelper.GetString(rdr, "Address2");
                        objOutput.Address3 = DbDataHelper.GetString(rdr, "Address3");
                        objOutput.Address4 = DbDataHelper.GetString(rdr, "Address4");
                        objOutput.PostageCode = DbDataHelper.GetString(rdr, "Address5");
                        objOutput.Standard = DbDataHelper.GetString(rdr, "Standard");
                        objOutput.Postage = DbDataHelper.GetString(rdr, "Postage");
                        objOutput.Standard = rdr["Standard"].ToString();
                        objOutput.Postage = rdr["Postage"].ToString();
                        objOutput.D5followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D5_FollowUp_SendDate");
                        objOutput.D10followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D10_FollowUp_SendDate");
                        objOutput.D15followupSentDate = DbDataHelper.GetNullableDateTime(rdr, "D15_FollowUp_SendDate");
                        objOutput.Comments = DbDataHelper.GetString(rdr, "BGComments");
                        objOutput.CustomerName = DbDataHelper.GetString(rdr, "ContactName");
                        objOutput.CompensationType = DbDataHelper.GetString(rdr, "CompensationType");
                        objOutput.CompensationGiven = DbDataHelper.GetString(rdr, "CompensationGiven");
                        objOutput.CompensationDate = DbDataHelper.GetDateTimeToString(rdr, "CompensationDate");
                        objOutput.SdepResponseDate = DbDataHelper.GetString(rdr, "SdepResponseRecd");
                        objOutput.SdepName = DbDataHelper.GetString(rdr, "SdepName");
                        objOutput.SdepAddress = DbDataHelper.GetString(rdr, "SdepAddress");
                        objOutput.Remarks = DbDataHelper.GetString(rdr, "Remarks");
                        objOutput.LetterBranding = DbDataHelper.GetString(rdr, "LetterBranding");
                       
objOutput.DuplicatePartner = DbDataHelper.GetString(rdr, "Duplicate");
                        lstBD.Add(objOutput);
                    }
                    con.Close();
                }
                return lstBD;
            }
            catch
            {
                throw;
            }
        }

        public string UploadGSOPRecords(List<GSOPStandardAone> data)
        {
            try
            {
                var value = JsonConvert.SerializeObject(data);

                // string Valaues = value.Replace(@"\", ""); 
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_GSOP_UploadStandardA1", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@JsonData", value);
                    cmd.Parameters.AddWithValue("@UserId", 100);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return null;
                }

            }
            catch
            {
                throw;
            }
        }

        public string UpdateGSOPRecords(List<CompensationDetail> data, int userid)
        {
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_GSOPCommon_Update", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Json", json);
                    cmd.Parameters.AddWithValue("@P_UserId", userid);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return null;
                }
            }
            catch
            {
                throw;
            }
        }

        public string UpdateGSOPA1Records(List<CompensationDetail> data, int userid)
        {
            try
            {

                var json = JsonConvert.SerializeObject(data);
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_GSOPStandardA1_BulkUpDate", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@P_Json", json);
                    cmd.Parameters.AddWithValue("@P_UserId", userid);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return null;
                }
            }
            catch
            {
                throw;
            }
        }
        //return null;
    }
}

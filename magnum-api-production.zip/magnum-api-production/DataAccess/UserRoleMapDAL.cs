﻿using EXLETAPI.Models;
using EXLETAPI.Services;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace EXLETAPI.DataAccess
{
    public class UserRoleMapDAL : BaseDAL, IUserRoleMap
    {
        //private string connectionString;
        public UserRoleMapDAL(IConfiguration configuration) : base(configuration)
        {
            // connectionString = configuration["ConnectionStrings:DefaultConnection"];
        }
        /// <summary>
        /// GetAllUserRoles
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public IEnumerable<UserRoleMap> GetAllFunction(int Id, int UserId)
        {
            try
            {
                List<UserRoleMap> lstUserRole = new List<UserRoleMap>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    if (Id == 0)
                    {
                        Id = 1;
                    }
                    SqlCommand cmd = new SqlCommand("Usp_Usm_RoleMapping", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@RoleID", Id);
                    cmd.Parameters.AddWithValue("@ActionType", "Search");
                    cmd.Parameters.AddWithValue("@Value", null);
                    cmd.Parameters.AddWithValue("@UserId", UserId);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        UserRoleMap userrole = new UserRoleMap();
                        userrole.FunctionName = Convert.ToString(rdr["Function_Name"]);
                        userrole.RoleId = Convert.ToInt32(rdr["RoleId"]);
                        userrole.FuncId = Convert.ToInt32(rdr["FuncId"]);
                        userrole.UserId = Convert.ToInt32(rdr["UserId"]);
                        userrole.IsActive = Convert.ToBoolean(rdr["IsActive"]);
                        lstUserRole.Add(userrole);

                    }
                    con.Close();

                }
                return lstUserRole;
            }
            catch
            {

                throw;
            }
        }
        /// <summary>
        /// UpdateUserRoleMap
        /// </summary>
        /// <param name="RoleID"></param>
        /// <param name="userRoleMap"></param>
        /// <returns></returns>
        public string UpdateUserRoleMap(int RoleID, List<UserRoleMap> userRoleMap)
        {
            try
            {

                bool data = false;

                foreach (var item in userRoleMap)
                {
                    data = item.IsActive;

                }
                int roledata = userRoleMap.Select(x => x.RoleId).FirstOrDefault();


                List<int> listdata = userRoleMap.Where(x => x.IsActive == true).Select(x => x.FuncId).ToList();

                string nameOfString = (string.Join(",", listdata.Select(x => x.ToString()).ToArray()));

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("Usp_Usm_RoleMapping", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RoleID", roledata);
                    cmd.Parameters.AddWithValue("@ActionType", "Update");
                    cmd.Parameters.AddWithValue("@Value", nameOfString);
                    cmd.Parameters.AddWithValue("@UserId", 116);

                    //cmd.Parameters.Add("@Result", SqlDbType.Char, 100);
                    //cmd.Parameters["@Result"].Direction = ParameterDirection.Output;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    return null;
                }

            }
            catch
            {

                throw;
            }
        }

        public IEnumerable<UserRoleMap> GetAllFunction(int Id)
        {
            try
            {
                List<UserRoleMap> lstUserRole = new List<UserRoleMap>();
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    if (Id == 0)
                    {
                        Id = 1;
                    }
                    SqlCommand cmd = new SqlCommand("Usp_Usm_RoleMapping", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@RoleID", Id);
                    cmd.Parameters.AddWithValue("@ActionType", "Search");
                    cmd.Parameters.AddWithValue("@Value", null);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        UserRoleMap userrole = new UserRoleMap();
                        userrole.FunctionName = DbDataHelper.GetString(rdr, "Function_Name");
                        userrole.RoleId = DbDataHelper.GetInt(rdr, "RoleId");
                        userrole.FuncId = DbDataHelper.GetInt(rdr, "FuncId");
                        userrole.UserId = DbDataHelper.GetNullableInt(rdr, "UserId");
                        userrole.IsActive = DbDataHelper.GetBoolean(rdr, "IsActive");
                        lstUserRole.Add(userrole);

                    }
                    con.Close();

                }
                return lstUserRole;
            }
            catch
            {
                throw;
            }
        }
    }
}

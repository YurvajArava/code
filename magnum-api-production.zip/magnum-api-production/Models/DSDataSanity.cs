﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System;
using System.ComponentModel.DataAnnotations;
namespace EXLETAPI.Models
{
    public class DataSanityModel
    {


        [DataMember(Name = "ID")]
        public int ID { get; set; }
        [DataMember(Name = "EnergySupplyId")]
        public int EnergySupplyId { get; set; }
        [DataMember(Name = "PaymentMethodId")]
        public int PaymentMethodId { get; set; }
        [DataMember(Name = "CancellationReasonId")]
        public int CancellationReasonId { get; set; }
        [DataMember(Name = "CancellationReasonSubCategoryId")]
        public int CancellationReasonSubCategoryId { get; set; }


        [DataMember(Name = "EnergySupply")]
        public string EnergySupply { get; set; }
        public string EtType { get; set; }
        public string InitialContact { get; set; }
        public string ContactMethod { get; set; }
        public string Origin { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }
        public string CallerName { get; set; }
        public string HomeTel { get; set; }
        public string ContactTel { get; set; }
        public string TGBReference { get; set; }
        public string MPRN { get; set; }
        public string C1Reference { get; set; }
        public string MPAN { get; set; }
        public string NSSAccRef { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? NSSInputDate { get; set; }
        public string PaymentMethod { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ElectricitySSD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? GASSSD { get; set; }
        public string SalesRepId { get; set; }
        public string CancellationReason { get; set; }
        public string CancellationReasonSubCategory { get; set; }
        public string CancellationResonAdditionalInfo { get; set; }
        public string SalesChannel { get; set; }
        public string PromotionalReference { get; set; }
        public string SalesLocation { get; set; }
        public string AgentId { get; set; }
        public string CSENameVerbal { get; set; }
        public string System { get; set; }
        public string ElecPreviousSupplier { get; set; }
        public string ElecOtherPreviousSupplier { get; set; }
        public string ProhibitCustomerContact { get; set; }
        public string CompensationAgreed { get; set; }
        public string UserId { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        public string GasPreviousSupplier { get; set; }
        public string GasOtherPreviousSupplier { get; set; }
        public string GasTransporter { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        public string IsProcess { get; set; }
        public string MPXN { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
        public int records { get; set; }
        public IEnumerable<DataSanityViewModel> dataSanityViewModels { get; set; }
        public IEnumerable<TodayCount> todays { get; set; }


    }
    public class DataSanityViewModel
    {
        [DataMember(Name = "ID")]
        public int ID { get; set; }
        [DataMember(Name = "EnergySupplyId")]
        public int EnergySupplyId { get; set; }

        [DataMember(Name = "PaymentMethodId")]
        public int PaymentMethodId { get; set; }
        [DataMember(Name = "CancellationReasonId")]
        public int CancellationReasonId { get; set; }
        [DataMember(Name = "CancellationReasonSubCategoryId")]
        public int CancellationReasonSubCategoryId { get; set; }

        [DataMember(Name = "EnergySupply")]
        public string EnergySupply { get; set; }
        public string EtType { get; set; }
        public string InitialContact { get; set; }
        public string ContactMethod { get; set; }
        public string Origin { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }
        public string CallerName { get; set; }
        public string HomeTel { get; set; }
        public string ContactTel { get; set; }
        public string TGBReference { get; set; }
        public string MPRN { get; set; }
        public string C1Reference { get; set; }
        public string MPAN { get; set; }
        public string NSSAccRef { get; set; }
        public string NSSInputDate { get; set; }
        public string PaymentMethod { get; set; }
        public string ElectricitySSD { get; set; }
        public string GASSSD { get; set; }
        public string SalesRepId { get; set; }
        public string CancellationReason { get; set; }
        public string CancellationReasonSubCategory { get; set; }
        public string CancellationResonAdditionalInfo { get; set; }
        public string SalesChannel { get; set; }
        public string PromotionalReference { get; set; }
        public string SalesLocation { get; set; }
        public string AgentId { get; set; }
        public string CSENameVerbal { get; set; }
        public string System { get; set; }
        public string ElecPreviousSupplier { get; set; }
        public string ElecOtherPreviousSupplier { get; set; }
        public string ProhibitCustomerContact { get; set; }
        public string CompensationAgreed { get; set; }
        public string UserId { get; set; }
        public string ICCD { get; set; }
        public string GasPreviousSupplier { get; set; }
        public string GasOtherPreviousSupplier { get; set; }
        public string GasTransporter { get; set; }
        public string RecievedDate { get; set; }
        public string IsProcess { get; set; }
        public string MPXN { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
        public int records { get; set; }

    }
    public class Search
    {
        public string MPXN { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
    }
    public class DataSanityUpdate
    {
        public int Id { get; set; }
        public string Energy_Supply { get; set; }
        // public string Payment_Method { get; set; }
        public string Cancellation_Reason { get; set; }
        // public string Cancellation_Reason_SubCategory { get; set; }
        public string Cancellation_Reason_Additional_Info { get; set; }
        //public string UserId { get; set; }
    }

    public class SapActionViewModel
    {
        public int Id { get; set; }
        public string MPAN { get; set; }
        public string Status { get; set; }
        public string ObjWindow { get; set; }
        public string SSD { get; set; }
        public string SED { get; set; }
        public string Pre_Supplier { get; set; }
    }
    public class SapAction
    {
        public int Id { get; set; }
        public int RefId { get; set; }
        public string MPAN { get; set; }
        public string Status { get; set; }
        public string ObjWindow { get; set; }
        public string SSD { get; set; }
        public string SED { get; set; }
        public string PreSupplier { get; set; }
        public IEnumerable<SapActionViewModel> dataSapActionModel { get; set; }

    }
    public class SapActionUpdate
    {
        public int ID { get; set; }
        public int RefId { get; set; }
        public string MPAN { get; set; }
        public string Status { get; set; }
        public string ObjWindow { get; set; }
        public string SSD { get; set; }
        public string SED { get; set; }
        public string Pre_Supplier { get; set; }
    }
    public class DcfEmail
    {

        public string EnergySupply { get; set; }
        public string CountOfEnergySupply { get; set; }

    }

    public class TodayCount
    {
        public int Records { get; set; }
    }
}


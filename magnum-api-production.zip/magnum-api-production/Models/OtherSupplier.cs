﻿using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    [DataContract]
    public class OtherSupplier : BaseModel
    {
        [DataMember(Name = "SID")]
        public int SID { get; set; }

        [DataMember(Name = "SupplierCode")]
        public string SupplierCode { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }


        [DataMember(Name = "SupplierName")]
        public string SupplierName { get; set; }

        [DataMember(Name = "EmailAddress")]
        public string EmailAddress { get; set; }
        [DataMember(Name = "RejectionEmailAddress")]
        public string RejectionEmailAddress { get; set; }

        [DataMember(Name = "PhoneNumber")]
        public string PhoneNumber { get; set; }

        [DataMember(Name = "AltPhoneNumber")]
        public string AltPhoneNumber { get; set; }

        [DataMember(Name = "ContactName")]
        public string ContactName { get; set; }
        [DataMember(Name = "Owner")]
        public string Owner { get; set; }

        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }

        [DataMember(Name = "EnergySupply")]
        public int EnergySupply { get; set; }
        
        [DataMember(Name = "Active")]
        public bool Active { get; set; }

    }
    public class Energy_list

    {

        public int ID { get; set; }

        public string Value { get; set; }

    }

}

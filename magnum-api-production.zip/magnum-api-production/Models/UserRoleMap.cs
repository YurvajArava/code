﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace EXLETAPI.Models
{
    public class UserRoleMap
    {
        public string FunctionName { get; set; }
        public int RoleId { get; set; }
        public int FuncId { get; set; }
        public int? UserId { get; set; }
        public bool IsActive { get; set; }
        public IEnumerable<SelectListItem> Roles { get; set; }
    }
}

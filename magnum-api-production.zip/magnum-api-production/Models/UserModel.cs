﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;

namespace EXLETAPI.Models
{
    public class UserModel : BaseModel
    {

        public int ID { get; set; }
        public String FirstName { get; set; }
        public string LastName { get; set; }
        public string LanId { get; set; }
        public int RoleId { get; set; }
        public String Email { get; set; }
        public string Title { get; set; }
        public IEnumerable<SelectListItem> Titles { get; set; }
        public bool IsActive { get; set; }
        public IEnumerable<SelectListItem> Roles { get; set; }
        public IEnumerable<UserViewModel> userViewModels { get; set; }
        public string Message { get; set; }

    }

    public class UserViewModel
    {
        public int ID { get; set; }
        public String FirstName { get; set; }
        public string LastName { get; set; }
        public string LanId { get; set; }
        public int RoleId { get; set; }
        public String Email { get; set; }
        public string Title { get; set; }
        public bool IsActive { get; set; }
        public string RoleName { get; set; }
        public int UserID { get; set; }
    }
    public class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
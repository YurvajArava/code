﻿using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class AuthenticateRequest
    {
        [Required]
        public string LanId { get; set; }


    }
}

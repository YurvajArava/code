using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class GSOPStandardAone
    {
        public long RefId { get; set; }
        public string MPXN { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Dot { get; set; }
        public string ContractAccount { get; set; }
        public string BusinessPartner { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string DuplicatePartner { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }
        public string ExclusionCode { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? AgreedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? GsopEligibleDate { get; set; }
        public string SSD { get; set; }
        public int? NetWorkingDays { get; set; }
        public string InitiatedBy { get; set; }
        public string SalesOrderDesc { get; set; }
        public string CustomerName { get; set; }
        public string CompensationType { get; set; }
        public string CompensationGiven { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CompensationDate { get; set; }
        public string Remarks { get; set; }
        public string exclusion { get; set; }
        public string LetterBranding { get; set; }

    }

    public class CompensationDetail
    {
        public long RefId { get; set; }
        public string MPXN { get; set; }
        public string SSD { get; set; }
        public string OrderDescription { get; set; }
        public string CompensationType { get; set; }
        public string CompensationGiven { get; set; }
        public string CompensationDate { get; set; }
        public string Remarks { get; set; }
        public int updateUserId { get; set; }
        public string SdepResponseRecdDate { get; set; }
        public string SdepName { get; set; }
        public string SdepAddress { get; set; }
        public string exclusion { get; set; }
    }

    public class GsopStandardAUpdateViewModel
    {
        public string StandardType { get; set; }
        public List<CompensationDetail> lstA1Update { get; set; }
        public BaseUploadFile fileDetail { get; set; }
    }

    public class GSOPA1Search
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPXN { get; set; }
    }

}

﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    [DataContract]
    public class LetterMaster : BaseModel
    {
        [DataMember(Name = "ID")]
        public int ID { get; set; }

        [DataMember(Name = "LetterCode")]
        public string LetterCode { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }

        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }

        [DataMember(Name = "EnergySupply")]
        public int EnergySupply { get; set; }

        //public string EnergySupply { get; set; }
        public List<ViewModelLetterMaster> viewModelLetterMasters { get; set; }
    }
    public class ViewModelLetterMaster
    {
        [DataMember(Name = "ID")]
        public int ID { get; set; }

        [DataMember(Name = "LetterCode")]
        public string LetterCode { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }

        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }

        [DataMember(Name = "EnergySupply")]
        public int EnergySupply { get; set; }


        //public string EnergySupply { get; set; }

    }
    public class LetterCodes
    {
        public int id { get; set; }
        public string letterCode { get; set; }
    }
}
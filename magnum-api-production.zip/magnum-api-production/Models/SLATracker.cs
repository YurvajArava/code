﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class SLATracker
    {
        public long RefId { get; set; }
        public string MPXN { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Received { get; set; }
        public string Product { get; set; }
        public string Delay { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D5Sent { get; set; }
        public string D5Letter { get; set; }
        public string Remarks { get; set; }
        public string D5Comments { get; set; }
        public string D5DaysfromICCD { get; set; }
        public string D5DaysfromReceivedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D20InterimLettersentDate { get; set; }
        public string D20InterimLetterType { get; set; }
        public string SLA { get; set; }
        public string D20InterimComments { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D20LetterSentDate { get; set; }
        public string D20LetterType { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ResponseReceivedDate { get; set; }
        public string D20DaysfromICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string D20DaysfromReceivedDate { get; set; }
        public string D20Comments { get; set; }
        public string Sentfilename { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Filesentdate { get; set; }
        public string InitiationSLA { get; set; }
        public string FileRemarks { get; set; }
        public DateTime? InitiationReceivedDate { get; set; }  
             public DateTime? ReceivedDate { get; set; } 
        public string Fuel { get; set; }
        public string ETType { get; set; }
        public DateTime? ResponseSendDate { get; set; }
        public string DayfromInitiation { get; set; }
        public string InitiationSLARemarks { get; set; }
        public string InitiationSLAComments { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
        public int Responsesla { get; set; }
        public string energysupply { get; set; }
    }

    public class SLASearch
    {
        public int EnergySupplyId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Response { get; set; }
        public string ICCD { get; set; }
        public int InitiationTypeId { get; set; }
        public string MPXN { get; set; }
        public int LetterCategoryId { get; set; }
    }
    public class SLAUpdate
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
        public string SLARemark { get; set; }


        public string RefId { get; set; }
    }
}

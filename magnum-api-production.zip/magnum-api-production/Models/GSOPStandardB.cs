﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class GSOPStandardB
    {
        public long RefId { get; set; }
        public string DuplicatePartner { get; set; }
        public string MPXN { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        public int? RecievedDaysFromICCD { get; set; }
        public string SupplierCode { get; set; }
        public string ETType { get; set; }
        public string ExclusionCode { get; set; }
        public string ReasonforReturn { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileSendDate { get; set; }
        public string Status { get; set; }
        public int? ResponseDaysFromICCD { get; set; }
        public string ContractAccount { get; set; }
        public string BusinessPartner { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string PostageCode { get; set; }
        public string Standard { get; set; }
        public string Postage { get; set; }
        public string Comments { get; set; }
        public string CustomerName { get; set; }
        public string CompensationType { get; set; }
        public string CompensationGiven { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CompensationDate { get; set; }
        public string SalesOrderDesc { get; set; }
        public string SdepName { get; set; }
        public string SdepAddress { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? SdepResponseDate { get; set; }
        public string Remarks { get; set; }
        public string LetterBranding { get; set; }
    }

    public class GsopBSearch : BaseModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPXN { get; set; }
    }
}

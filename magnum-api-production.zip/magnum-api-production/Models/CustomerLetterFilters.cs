﻿using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    public class CustomerLetterFilters
    {
        public int EnergySupply { get; set; }
        public string LetterType { get; set; }
        public string RecordType { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
    public class CustomerLetterData
    {
        [DataMember(Name = "RefID")]
        public int RefID { get; set; }

        [DataMember(Name = "MPXN")]
        public string MPXN { get; set; }

        [DataMember(Name = "Energy_Supply")]
        public string Energy_Supply { get; set; }

        [DataMember(Name = "Initial_Contact")]
        public string Initial_Contact { get; set; }

        // [DataMember(Name = "RecievedDate")]
        //  [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string RecievedDate { get; set; }

        //[DataMember(Name = "ICCD")]
        public string ICCD { get; set; }

        [DataMember(Name = "Track_Code")]
        public string Track_Code { get; set; }

        [DataMember(Name = "Title")]
        public string Title { get; set; }

        [DataMember(Name = "initial")]
        public string initial { get; set; }

        [DataMember(Name = "Surname")]
        public string Surname { get; set; }

        [DataMember(Name = "Region")]
        public string Region { get; set; }

        [DataMember(Name = "Address1")]
        public string Address1 { get; set; }

        [DataMember(Name = "Address2")]
        public string Address2 { get; set; }

        [DataMember(Name = "Address3")]
        public string Address3 { get; set; }

        [DataMember(Name = "Address4")]
        public string Address4 { get; set; }

        [DataMember(Name = "Address5")]
        public string Address5 { get; set; }

        [DataMember(Name = "LetterCode")]
        public string LetterCode { get; set; }

        [DataMember(Name = "D5_Letter_Code")]
        public string D5_Letter_Code { get; set; }

        //[DataMember(Name = "D5_Sent_Date")]
        //public DateTime? D5_Sent_Date { get; set; }
        public string D5_Sent_Date { get; set; }

        [DataMember(Name = "D20_Letter_Code")]
        public string D20_Letter_Code { get; set; }

        //[DataMember(Name = "D20_Send_Date")]
        //public DateTime? D20_Send_Date { get; set; }
        public string D20_Send_Date { get; set; }

        [DataMember(Name = "D20_Interim_Letter_Code")]
        public string D20_Interim_Letter_Code { get; set; }

        //[DataMember(Name = "D20_Interim_Send_Date")]
        //public DateTime? D20_Interim_Send_Date { get; set; }
        public string D20_Interim_Send_Date { get; set; }
        [DataMember(Name = "Code")]
        public string Code { get; set; }

    }
}

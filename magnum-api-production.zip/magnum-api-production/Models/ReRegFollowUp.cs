﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class ReRegFollowUp
    {
        public int RefId { get; set; }
        public long MPXN { get; set; }
        public string EnergySupply { get; set; }
        public string EtType { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string WithEffDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string RecievedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string Iccd { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string FileReceivedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string InitialFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string SecondFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string FinalFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string MRAFollowUpSendDate { get; set; }
        public string TrackCode { get; set; }
        public string GainingSupplier { get; set; }
        public string OldSupplier { get; set; }
        public string AdditionalComments { get; set; }
        public string ReRegFollowUpType { get; set; }
        public string NetWorkingDay { get; set; }
        public string FirstWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string FirstSwitchDate { get; set; }
        public string SecondWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string SecondSwitchDate { get; set; }
        public string ThirdWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string ThirdSwitchDate { get; set; }
        public string FinalStatus { get; set; }
        public string Aging { get; set; }
        public string BgComments { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string DateWorked { get; set; }

    }
    public class ReRegFollowUpViewModel
    {
        public int RefId { get; set; }
        public long MPXN { get; set; }
        public string EnergySupply { get; set; }
        public string ETType { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? WithEffDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileReceivedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime InitialFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? SecondFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FinalFollowUpSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? MRAFollowUpSendDate { get; set; }
        public string TrackCode { get; set; }
        public string GainingSupplier { get; set; }
        public string OldSupplier { get; set; }
        public string AdditionalComments { get; set; }
        public string ReRegFollowUpType { get; set; }
        public string NetWorkingDay { get; set; }
        public string FirstWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string FirstSwitchDate { get; set; }
        public string SecondWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string SecondSwitchDate { get; set; }
        public string ThirdWithdrawalStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string ThirdSwitchDate { get; set; }
        public string FinalStatus { get; set; }
        public string Aging { get; set; }
        public string BGComments { get; set; }
        public string sdate { get; set; }
        public string edate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string DateWorked { get; set; }
    }
    public class ReRegFollowUpUpdate
    {
        public int RefId { get; set; }
        public long MPXN { get; set; }

        public string ReReg_FollowUp_Type { get; set; }
        public string First_WithdrawalStatus { get; set; }
        public string First_SwitchDate { get; set; }
        public string Second_WithdrawalStatus { get; set; }
        public string Second_SwitchDate { get; set; }
        public string Third_WithdrawalStatus { get; set; }
        public string Third_SwitchDate { get; set; }
        public string Final_Status { get; set; }
        public string BG_Comments { get; set; }


    }

    public class ReRegSearch
    {
        public int EnergySupplyId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPXN { get; set; }
    }

}

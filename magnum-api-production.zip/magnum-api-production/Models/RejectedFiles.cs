﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class RejectedFiles
    {

        public int ID { get; set; }
        public string FileName { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ProcessDate { get; set; }
        public string FileData { get; set; }
        public string ReasonOfReject { get; set; }

    }
    public class RejectedFileSearch
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }
}

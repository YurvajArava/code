﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class ETData
    {
        public long RefId { get; set; }
        public int EnergySupplyId { get; set; }
        public string EtType { get; set; }
        public string InitialContact { get; set; }
        public string ContactMethod { get; set; }
        public string Origin { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }
        public string CallerName { get; set; }
        public string HomeTel { get; set; }
        public string ContactTel { get; set; }
        public string TGBReference { get; set; }
        public string MPRN { get; set; }
        public string C1Reference { get; set; }
        public string MPAN { get; set; }
        public string NSSAccRef { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? NSSInputDate { get; set; }
        public string PaymentMethod { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ElectricitySSD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? GASSSD { get; set; }
        public string SalesRepId { get; set; }
        public int? CancellationReasonId { get; set; }
        public int? CancellationReasonSubCategoryId { get; set; }
        public string CancellationReasonAdditionalInfo { get; set; }
        public string SalesChannel { get; set; }
        public string PromotionalReference { get; set; }
        public string SalesLocation { get; set; }
        public string AgentId { get; set; }
        public string CSENameVerbal { get; set; }
        public string System { get; set; }
        public string ElecPreviousSupplier { get; set; }
        public string ElecOtherPreviousSupplier { get; set; }
        public string ProhibitCustomerContact { get; set; }
        public string CompensationAgreed { get; set; }
        public string UserId { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        public string GasPreviousSupplier { get; set; }
        public string GasOtherPreviousSupplier { get; set; }
        public string GasTransporter { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ContactDate { get; set; }
        public string IoContactName { get; set; }
        public string ReferenceNumber { get; set; }
        public string CustomerRequestsNewSupplier { get; set; }
        public string ReadingType { get; set; }
        public string ReasonforReturn { get; set; }
        public string Status { get; set; }
        public string AssociatedOrganisationId { get; set; }
        public string RoContactName { get; set; }
        public string MeterSerialNumber { get; set; }
        public string MeterReading { get; set; }
        public string MeterReadingDate { get; set; }
        public string MeterReadingType { get; set; }
        public string MeterRegisterId { get; set; }
        public string RecordRejectionAcceptanceCode { get; set; }
        public string BgComments { get; set; }
        public string OsComments { get; set; }
        public string LetterCode { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileReceivedDate { get; set; }
        public string FileName { get; set; }
        public string TrackCode { get; set; }
        public string WithEffDate { get; set; }
        public string Region { get; set; }
        public long? Partner { get; set; }
        public string ContractAccount { get; set; }
        public string BusinessPartner { get; set; }
        public string LetterBranding { get; set; }
       
public string DuplicatePartner { get; set; }
        public long ContractNo { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? EffSettDate { get; set; }
        public Boolean FailedQuality { get; set; }
        public Boolean Duplicate { get; set; }
        public string CustomerType { get; set; }
        public string ESRSStatus { get; set; }
        public string FinalRead { get; set; }
        public string ExclusionCode { get; set; }
        public string StageCode { get; set; }
        public string Stage { get; set; }
        public bool IsActive { get; set; }
        public string MKTFLAG { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? MKTFileSendDate { get; set; }
        public string MKTFileName { get; set; }
        public string ThreadCode { get; set; }
        public string ResponseReceived { get; set; }
        public string CompensationType { get; set; }
        public string SWMInOutFlag { get; set; }
        public string UpdatedBy { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? UpdatedOn { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? SdepResponseDate { get; set; }
        public string EnergySupply { get; set; }
        public string CancellationReason { get; set; }
        public string CancellationReasonSubCategory { get; set; }
        public string PremiseNumber { get; set; }
        public string CompensationGiven { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CompensationDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ResponseRecdDate { get; set; }
        public string SalesOrderDesc { get; set; }
        public bool RecordInError { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? LetterDate { get; set; }
        public string HouseNumber { get; set; }

        public string InitsuppId { get; set; }
        public string InitOrgId { get; set; }

    }
}

﻿namespace EXLETAPI.Models
{
    public class GasWorkFlowModelUpdate
    {
        public int RefID { get; set; }
        public int Energy_Supply { get; set; }
        public long MPXN { get; set; }
        public string StageCode { get; set; }
        //public string UserId { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class FollowUp
    {
        public long Id { get; set; }
        public long RefId { get; set; }
        public string MPXN { get; set; }
        public string EnergySupply { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? SupplierTransferDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        public string FollowUpType { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FollowUpDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileSendDate { get; set; }
        public string AscOrgId { get; set; }
        public string EtType { get; set; }
        public string Comments { get; set; }
        public int WorkingDays { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileRecievedDate { get; set; }
        public string TrackCode { get; set; }
        public string RecievedResponse { get; set; }
        public string Status { get; set; }
        public string CancellationReason { get; set; }
        public string Stage { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D5SendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D10SendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D15SendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? MraSendDate { get; set; }
        
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? D5SdepDate { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? D10SdepDate { get; set; }



[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? D15SdepDate { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? DMRASdepDate { get; set; }

    }
public class FollowSdepUpdate
{
public long RefId { get; set; }
public string MPXN { get; set; }
public string AscOrgId { get; set; }
public string ETType { get; set; }



[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public string D5SdepDate { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public string D10SdepDate { get; set; }



[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public string D15SdepDate { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public string DMRASdepDate { get; set; }
}
    public class FollowUpSearchAttribute : BaseModel
    {
        public string StartDate { get; set; }

        public string EndDate { get; set; }
        public string MPXN { get; set; }
        public string FollowUpTypeId { get; set; }
        public int? EnergySupplyId { get; set; }
    }

    public class FollowUpTypes
    {
        public int Id { get; set; }
        public string FollowUpType { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
    }
}

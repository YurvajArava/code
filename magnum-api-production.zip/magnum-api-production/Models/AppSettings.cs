﻿namespace EXLETAPI.Models
{
    public class AppSettings
    {
        public string Key { get; set; }
    }
}

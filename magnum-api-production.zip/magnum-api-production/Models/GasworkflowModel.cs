﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class GasworkflowModel : ETData
    {
        public string RecordTypeIdentifier { get; set; }
        public string CustomerName { get; set; }
        public string Et_Type { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? DateOfTransfer { get; set; }
        public string CreatedBy { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CreatedOn { get; set; }

    }

    public class GasWorkFlowUpdateModel
    {
        public long RefID { get; set; }
        public string Energy_Supply { get; set; }
        public string MPXN { get; set; }
        public string StageCode { get; set; }
        //public string UserId { get; set; }
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }

    public class Status
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public int Count { get; set; }
        public string RefIds { get; set; }
    }

    public class RETData
    {
        public List<RETDataModel> retDataDetail { get; set; }
        public RETDataDetail retHeader { get; set; }
    }
    public class RETDataModel
    {
        public long RefId { get; set; }
        public string InitialContact { get; set; }
        public string IoContactName { get; set; }
        public string ReferenceNo { get; set; }
        public string MPRN { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address5 { get; set; }
        public string ContactName { get; set; }
        public string ContactTel { get; set; }
        public string ReqNewSupplier { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecivedDate { get; set; }
        public string ReturnReason { get; set; }
        public string Status { get; set; }
        public string AscOrgId { get; set; }
        public string RoContactName { get; set; }
        public string MeterSlNo { get; set; }
        public string MeterReading { get; set; }
        public string MeterReadDate { get; set; }
        public string MeterReadType { get; set; }
        public string RecordRjtActCode { get; set; }
        public string Comment { get; set; }
    }
    public class RETDataDetail
    {
        public int Count { get; set; }
        public string FileName { get; set; }
        public string SupplierCode { get; set; }
        public string Type { get; set; }
        public bool Registered { get; set; }
    }

    public class GasSearchCriteria : BaseModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPRN { get; set; }
           public string Energy { get; set; }
        public string ICCD { get; set; }
        public string SupplierCode { get; set; }
        public string StageCode { get; set; }
    }
}

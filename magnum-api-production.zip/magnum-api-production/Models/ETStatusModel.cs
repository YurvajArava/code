﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace EXLETAPI.Models
{
    public class ETStatusModel : BaseModel
    {
        public int ID { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public int EnergySupply { get; set; }
        public IEnumerable<SelectListItem> EnergySupplies { get; set; }
    }


    public class ETStatusViewModel
    {
        public int ID { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public int EnergySupply { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    [DataContract]
    public class CommonMaster : BaseModel
    {

        [DataMember(Name = "Id")]
        public int ID { get; set; }

        [DataMember(Name = "Type")]
        public string Type { get; set; }
        public IEnumerable<SelectListItem> Types { get; set; }

        [DataMember(Name = "Value")]
        public string Value { get; set; }
        [DataMember(Name = "Description")]
        public string Description { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }
        [DataMember(Name = "Energy_Supply")]
        public int EnergySupply { get; set; }
        public List<CommonMasterViewModel> commonMasterViewModels { get; set; }


    }
    public class CommonMasterViewModel
    {
        public int Id { get; set; }

        [DataMember(Name = "Type")]
        public string Type { get; set; }
        [DataMember(Name = "Value")]
        public string Value { get; set; }
        [DataMember(Name = "Description")]
        public string Description { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }
        [DataMember(Name = "Energy_Supply")]
        public int EnergySupply { get; set; }


    }
}

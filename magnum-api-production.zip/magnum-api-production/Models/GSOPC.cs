using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class GSOPC : ETData
    {
        public string MPXN { get; set; }
        public string CustomerName { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? DOT { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
         public DateTime? ICCD { get; set; }
        public int? RecievedDaysFromICCD { get; set; }
        public string Supplier { get; set; }
        public int? ResponseDaysFromRcvd { get; set; }
        public int? ResponseDaysFromICCD { get; set; }
        public string Comments { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CommentDate { get; set; }
        public int? AcceptanceDays { get; set; }
        public int? DelayedComment { get; set; }
        public int? NetworkingDaysAsperResponseDate { get; set; }
        public int? NetworkingDaysASPerSDAPDate { get; set; }
        public string InitiatedBy { get; set; }
        public string SdepName { get; set; }
        public string SdepAddress { get; set; }
        public string Remarks { get; set; }
       [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? CompensationDate1 { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? SdepResponseDate1 { get; set; }
    }
    public class GsopCSearchModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPXN { get; set; }
    }
}

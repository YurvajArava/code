﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EXLETAPI.Models
{
     
    

    public class UsrStagingFields
    {
        public string Customer_Name { get; set; }
        public string Street_Name { get; set; } 
        public string Initiating_Organisation_ID { get; set; }
        public string GenratedFileName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? GeneratedDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Initial_Customer_Contact_Date { get; set; }
        public string Customer_Telephone_Number { get; set; }
        public string BatchId { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? File_Received_Date { get; set; }
        public string Initiating_Supplier_ID { get; set; }
        public string Associated_Supplier_ID { get; set; }
        public string MPAN_Core { get; set; }
        public string Metering_Point_Address_Line_1 { get; set; }
        public string Metering_Point_Address_Line_2 { get; set; }
        public string Metering_Point_PostCode { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Effective_Settlement_REGI_Date_NewSupplier { get; set; }       
        public string Prohibit_Customer_Contact { get; set; }
        public string Reason_for_Return { get; set; }
        public string Status_of_Erroneous_Transfer { get; set; }
        public string Additional_Information { get; set; }
        public string Meter_ID { get; set; }
        public string Meter_Type { get; set; }
        public string Meter_Reading_Id { get; set; }
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public string Meter_Reading_DateTime { get; set; }
        public string Register_Reading { get; set; }

    }

    public class RetStagingFIelds  
    {
        public string Customer_Name { get; set; }
        public string FileName { get; set; }
        public string MPRN { get; set; }
        public string Street_Name { get; set; }
        public string ReferenceNumber { get; set; }
        public string Record_type_Identifier { get; set; }
        public string Initiating_Organisation_ID { get; set; }
        public string GenratedFileName { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? GeneratedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Initial_Customer_Contact_Date { get; set; }
        public string Customer_Telephone_Number { get; set; }
        public string IO_Contact_Name { get; set; }
        public string Reference_Number { get; set; }
        public string House_Number { get; set; }
        public string Postcode { get; set; }
        
        public string Customer_Requests_NoContact_From_NewSupplier { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? Date_Of_Transfer { get; set; }
        public string Reason_For_Return { get; set; }
        public string Status_Response { get; set; }
        public string Responding_Associated_Organisation_ID { get; set; }
        public string RO_Contact_Name { get; set; }
        public string Meter_Serial_Number { get; set; }
        public string Meter_Reading { get; set; }      
        public string Meter_Reading_Date { get; set; }

        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        // public DateTime? Meter_Reading_Date { get; set; }
        public string Meter_Reading_Type { get; set; }
        public string Record_Rejection_Acceptance_Code { get; set; }
        public string Comments { get; set; }
        public string FileType { get; set; }
    }

public class ReportCustomerLetter
{
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? DDate { get; set; }
public string MPXN { get; set; }
public string Energy { get; set; }
public string Customer_Name { get; set; }
public string Customer_Name1 { get; set; }
public string Address1 { get; set; }
public string Address2 { get; set; }
public string Address3 { get; set; }
public string Address4 { get; set; }

public string Post_Code { get; set; }
public string Letter_Type { get; set; }
public string Region { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? ICCD { get; set; }
[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
public DateTime? RecievedDate { get; set; }
}
public class ReportTablesSearch
{
public string MPXN { get; set; }
public string StartDate { get; set; }
public string EndDate { get; set; }
public string RecordType { get; set; }
public int PEnergySupplyId { get; set; }
public int PType { get; set; }



}
  
}

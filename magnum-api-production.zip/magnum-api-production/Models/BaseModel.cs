﻿namespace EXLETAPI.Models
{
    public abstract class BaseModel
    {
        public int UserId { get; set; }
    }
    public class BaseUploadFile : BaseModel
    {
        public string FileName { get; set; }
        public int NoOfRows { get; set; }
        public string FileData { get; set; }
        public string FileType { get; set; }
        public bool IsProcessed { get; set; }
        public string FileRemarks { get; set; }
    }
}
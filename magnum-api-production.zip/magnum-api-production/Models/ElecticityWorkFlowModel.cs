﻿using System;

namespace EXLETAPI.Models
{
    /* public class ElecticityWorkFlowModel
    {
       public int RefId { get; set; }
        public string EnergySupply { get; set; }
        public string BatchIdentifier { get; set; }
        public string MPAN { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string PostCode { get; set; }
        public string EffectiveFromSettlementDateForNewSupplier { get; set; }
        public string InitialCustomerContactDate { get; set; }
        public string InitiatingSupplierId { get; set; }
        public string AssociatedSupplierId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerTelephoneNumber { get; set; }
        public string CustomerRequestsNoContact { get; set; }
        public string ReasonForReturn { get; set; }
        public string StatusForErroneousTransfer { get; set; }
        public string AdditionalInformation { get; set; }
        public string MeterSerialNumber { get; set; }
        public string MeterReadingType { get; set; }
        public string MeterReadingId { get; set; }
        public string MeterReadingDate { get; set; }
        public string MeterReading { get; set; }

        public string FileReceivedDate { get; set; }
        public string StageCode { get; set; }
        public string Stage { get; set; }
        public bool Duplicate { get; set; }
        public string CreatedBy { get; set; }

        public string CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public bool IsActive { get; set; }
        
        public int RefId { get; set; }
        public string EnergySupply { get; set; }
        public string BatchIdentifier { get; set; }
        public string MPAN { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string PostCode { get; set; }
        public DateTime? EffectiveFromSettlementDateForNewSupplier { get; set; }
        public DateTime? InitialCustomerContactDate { get; set; }
        public string InitiatingSupplierId { get; set; }
        public string AssociatedSupplierId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerTelephoneNumber { get; set; }
        public string CustomerRequestsNoContact { get; set; }
        public string ReasonForReturn { get; set; }
        public string StatusForErroneousTransfer { get; set; }
        public string AdditionalInformation { get; set; }
        public string MeterSerialNumber { get; set; }
        public string MeterReadingType { get; set; }
        public string MeterReadingId { get; set; }
        public DateTime? MeterReadingDate { get; set; }
        public string MeterReading { get; set; }
     
        public DateTime? FileReceivedDate { get; set; }
        public string StageCode { get; set; }
        public string Stage { get; set; }
        public bool Duplicate { get; set; }
        public string CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }*/
    
    public class ElecticityWorkFlowModel
{
public int RefId { get; set; }
public string EnergySupply { get; set; }
public string BatchIdentifier { get; set; }
public string MPAN { get; set; }
        public string Et_Type { get; set; }
public string HouseNumber { get; set; }
public string StreetName { get; set; }
public string PostCode { get; set; }
public string EffectiveFromSettlementDateForNewSupplier { get; set; }
public string InitialCustomerContactDate { get; set; }
public string InitiatingSupplierId { get; set; }
public string AssociatedSupplierId { get; set; }
public string CustomerName { get; set; }
public string CustomerTelephoneNumber { get; set; }
public string CustomerRequestsNoContact { get; set; }
public string ReasonForReturn { get; set; }
public string StatusForErroneousTransfer { get; set; }
public string AdditionalInformation { get; set; }
public string MeterSerialNumber { get; set; }
public string MeterReadingType { get; set; }
public string MeterReadingId { get; set; }
public string MeterReadingDate { get; set; }
public string MeterReading { get; set; }



public string FileReceivedDate { get; set; }
public string StageCode { get; set; }
public string Stage { get; set; }
public bool Duplicate { get; set; }
public string CreatedBy { get; set; }



public string CreatedOn { get; set; }
public string UpdatedBy { get; set; }
public string UpdatedOn { get; set; }
public bool IsActive { get; set; }
}

    public class ElectircityWorkFlowViewModel
    {
        public int RefId { get; set; }
        public string EnergySupply { get; set; }
        public string BatchIdentifier { get; set; }
        public string MPAN { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string PostCode { get; set; }
        public string EffectiveFromSettlementDateForNewSupplier { get; set; }
        public string InitialCustomerContactDate { get; set; }
        public string InitiatingSupplierId { get; set; }
        public string AssociatedSupplierId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerTelephoneNumber { get; set; }
        public string CustomerRequestsNoContact { get; set; }
        public string ReasonForReturn { get; set; }
        public string StatusForErroneousTransfer { get; set; }
        public string AdditionalInformation { get; set; }
        public string MeterSerialNumber { get; set; }
        public string MeterReadingType { get; set; }
        public string MeterReadingId { get; set; }
        public string MeterReadingDate { get; set; }
        public string MeterReading { get; set; }

        public string FileReceivedDate { get; set; }
        public string StageCode { get; set; }
        public string Stage { get; set; }
        public bool Duplicate { get; set; }
        public string CreatedBy { get; set; }

        public string CreatedOn { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public bool IsActive { get; set; }
    }

    public class ElectircityWorkFlowUpdate
    {
        public int RefId { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }

        public string Address5 { get; set; }
        public string InitiatingSupplierId { get; set; }
        public string AssociatedSupplierId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerTelephoneNumber { get; set; }
        public string ReasonForReturn { get; set; }
        public string StatusForErroneousTransfer { get; set; }

    }
    public class ElecSearchCriteria : BaseModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPAN { get; set; }
        public string ICCD { get; set; }
        public string Energy { get; set; }
        public string SupplierCode { get; set; }
        public string StageCode { get; set; }
    }
}


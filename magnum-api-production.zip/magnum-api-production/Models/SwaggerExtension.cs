﻿namespace EXLETAPI.Models
{
    public class SwaggerExtension
    {
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EXLETAPI.Models
{
    public class MonthlyReport : ETData
    {
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? DOT { get; set; }
        public string CustomerName { get; set; }
        
        public string Address { get; set; }
        public string CanCategory { get; set; }
        public string SubCanCategory { get; set; }
        public string Supplier { get; set; }
        
         public string OtherSupplier { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D20SendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D20InterimSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D5SendDate { get; set; }
    }

    public class MonthlyRptSearchModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
         public string ICCDStartDate { get; set; }
        public string ICCDEndDate { get; set; }
        public int EnergySupplyId { get; set; }
        public string LetterTypeId { get; set; }
        public string MPXN { get; set; }
    }

   public class WeeklyReport
    {
    public string ThreadCode { get; set; }
    public string MPXN { get; set; }
public int TotalEt { get; set; }


    [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
    public DateTime? WReceivedDate { get; set; }
    }



    public class WeeklyRptSearchModel
    {
    public string StartDate { get; set; }
    public string EndDate { get; set; }
    public string ThreadType { get; set; }
    }

    public class CompensationReport
    {
        public long RefId { get; set; }
        public string MPXN { get; set; }
        public string EnergySupply { get; set; }
        public string InitiatedBy { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? ICCD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? RecievedDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? FileSendDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? DOT { get; set; }
        public string Status { get; set; }
        public string ExclusionCode { get; set; }
        public string ContractAccount { get; set; }
        public string BusinessPartner { get; set; }
        public string SupplierCode { get; set; }
        public string ETType { get; set; }
        public string ReasonforReturn { get; set; }
        public string CompensationType { get; set; }
        public string SalesOrderDesc { get; set; }
        public string SSD { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? CompensationDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? SdepResponseRecd { get; set; }
        public string SdepName { get; set; }
        public string SdepAddress { get; set; }
        public string CompGivenStatus { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D5followupSentDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D10followupSentDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? D15followupSentDate { get; set; }
        public string Title { get; set; }
        public string Initial { get; set; }
        public string SurName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string Address5 { get; set; }

        public string UpdatedBy { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime UpdatedOn { get; set; }
    }
    public class CompSearch
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string MPXN { get; set; }
        public string CompType { get; set; }
    }
}

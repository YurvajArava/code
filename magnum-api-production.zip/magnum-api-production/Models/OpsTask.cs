﻿namespace EXLETAPI.Models
{
    public class OpsTask : ETData
    {
        public string DOT { get; set; }
        public string Iccd1 { get; set; }
        public string UpdatedOn1 { get; set; }
        public string RecievedDate1 { get; set; }
        public string CustomerName { get; set; }
        public string MKTFileSendDate1 { get; set; }
        public string LetterDate1 { get; set; }

    }

    public class OpsTaskSearch : BaseModel
    {
        public string MPRN { get; set; }
        public string SurName { get; set; }
        public string HouseNo { get; set; }
        public string PostCode { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string OsActivity { get; set; }
    }
}

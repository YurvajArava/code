﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    public class Mst_CancelReason
    {
        public int ID { get; set; }

        [DataMember(Name = "Type")]
        public string Type { get; set; }

        [DataMember(Name = "Code")]
        public string Code { get; set; }
        [DataMember(Name = "Description")]
        public string Description { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }
        [DataMember(Name = "EnergySupply")]
        public int EnergySupply { get; set; }
        public IEnumerable<SelectListItem> EnergySupplies { get; set; }
        public IEnumerable<SelectListItem> Types { get; set; }
    }
}

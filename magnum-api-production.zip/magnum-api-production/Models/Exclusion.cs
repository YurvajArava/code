﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    public class Exclusion : BaseModel
    {
        public int ID { get; set; }

        [DataMember(Name = "code")]
        public string code { get; set; }

        [DataMember(Name = "Exclusion")]
        public string Exclusions { get; set; }

        [DataMember(Name = "Example")]
        public string Example { get; set; }
        [DataMember(Name = "Standard")]
        public string Standard { get; set; }
        public IEnumerable<SelectListItem> Standards { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }
        public List<ExclusionModel> exclusionModels { get; set; }

    }
    public class ExclusionModel
    {
        public int ID { get; set; }

        [DataMember(Name = "code")]
        public string code { get; set; }

        [DataMember(Name = "Exclusion")]
        public string Exclusions { get; set; }

        [DataMember(Name = "Example")]
        public string Example { get; set; }
        [DataMember(Name = "Standard")]
        public string Standard { get; set; }
        public IEnumerable<SelectListItem> Standards { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }

    }
}

﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace EXLETAPI.Models
{
    public class User
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LanId { get; set; }
        public IEnumerable<ModelUser> modelUser { get; set; }
        //[JsonIgnore]
        //public string Password { get; set; }

        [JsonIgnore]
        public List<RefreshToken> RefreshTokens { get; set; }


    }
    public class ModelUser
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LanId { get; set; }

        //[JsonIgnore]
        //public string Password { get; set; }

        [JsonIgnore]
        public List<RefreshToken> RefreshTokens { get; set; }

    }

}

﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EXLETAPI.Models
{
    public class HolidaysMaster
    {

        [DataMember(Name = "Id")]
        public int ID { get; set; }

        [DataMember(Name = "Date")]
        public DateTime Date { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }
        public List<ViewModelHolidays> viewModelHolidays { get; set; }


    }
    public class ViewModelHolidays
    {
        [DataMember(Name = "Id")]
        public int ID { get; set; }

        [DataMember(Name = "Date")]
        public DateTime Date { get; set; }

        [DataMember(Name = "Description")]
        public string Description { get; set; }
        [DataMember(Name = "IsActive")]
        public bool IsActive { get; set; }

    }
}


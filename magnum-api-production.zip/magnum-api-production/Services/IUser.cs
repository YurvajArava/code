﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IUser
    {
        List<UserModel> GetAllUser();
        UserModel GetUserById(int Id);
        UserModel AddUserMaster(UserModel userMaster);
        UserModel UpdateUserMaster(UserModel userMaster);
        string DeleteUserMaster(string LanId);
        UserModel GetByLanId(string LanId);
    }
}

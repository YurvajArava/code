﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface ILetterMasters
    {
        IEnumerable<LetterMaster> GetLetterMaster();
        LetterMaster GetLetterMasterById(int Id);
        LetterMaster AddLetterMaster(LetterMaster letterMaster);
        LetterMaster UpdateLetterMaster(LetterMaster letterMaster);
        LetterMaster DeleteLetterMaster(LetterMaster letterMaster);
        IEnumerable<CustomerLetterData> GetDataForCustomerLetter(CustomerLetterFilters CLetterFilter);
    }
}

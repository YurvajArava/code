﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IFollowUp
    {
        /// <summary>
        /// Get FollowUp Data based on search Criteria
        /// </summary>
        /// <param name="objInput"></param>
        /// <returns></returns>
        List<FollowUp> GetFollowUpData(FollowUpSearchAttribute objInput);

        /// <summary>
        /// Get followup data for operation Team
        /// </summary>
        /// <returns>List of FollowUp Data</returns>
        List<FollowUp> GetOpsData();

        /// <summary>
        /// Get followUp Types
        /// </summary>
        /// <returns>List of FollowUp Types</returns>
        List<FollowUpTypes> GetFollowUpTypes();

        Status UpdateFollowUpOps(string jsonData, int iUserId);
        string UpdateFollowUpRecords(List<FollowSdepUpdate> data, int userid);
    }
}

﻿using EXLETAPI.Models;
using System;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface IHolidayMaster
    {
        IEnumerable<HolidaysMaster> GetHolidays();
        HolidaysMaster GetHolidaysByYear(DateTime year);
    }
}

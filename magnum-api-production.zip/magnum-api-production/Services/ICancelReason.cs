﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface ICancelReason
    {
        IEnumerable<CancelReason> GetCancelReason();
        CancelReason GetCancelReasonById(int id);
        CancelReason AddCancelReason(CancelReason CancelReason);
        CancelReason UpdateCancelReason(CancelReason CancelReason);
        CancelReason DeleteCancelReason(CancelReason CancelReason);
    }
}

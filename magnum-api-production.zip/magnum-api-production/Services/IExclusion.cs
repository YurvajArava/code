﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IExclusion
    {
        IEnumerable<Exclusion> GetExclusion();
        Exclusion GetExclusionById(int id);
        Exclusion AddExclusion(Exclusion exclusion);
        Exclusion UpdateExclusion(Exclusion exclusion);
    }
}

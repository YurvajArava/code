﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IGSOPC
    {
        IList<GSOPC> GetGsopCData(GsopCSearchModel objInput);
    }
}

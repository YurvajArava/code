﻿using System;
using EXLETAPI.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EXLETAPI.Services
{
    public interface IReportTable
    {
        IEnumerable<RetStagingFIelds> GetReportRETTables(ReportTablesSearch objsearch);
        IEnumerable<UsrStagingFields> GetReportUSRTables(ReportTablesSearch objInput);
        IEnumerable<ReportCustomerLetter> GetCustomerLetterReport(ReportTablesSearch objInput);
    }
}

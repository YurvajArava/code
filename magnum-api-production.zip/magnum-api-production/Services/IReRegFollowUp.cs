﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface IReRegFollowUp
    {
        IEnumerable<ReRegFollowUp> GetReRegFollowUpData(ReRegSearch objInput);
        string UpdateReRegFollowUpData(List<ReRegFollowUpUpdate> data, int userid);

        IEnumerable<ReRegFollowUp> GetReRegFollowUpData(string mpxn, string sdate, string edate, string energysupply);
    }
}

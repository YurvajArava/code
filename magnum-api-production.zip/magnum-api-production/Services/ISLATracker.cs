﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface ISLATracker
    {
        IEnumerable<SLATracker> SearchSLARecords(SLASearch objInput);
        SLAUpdate SLATrackerUpdateETData(string jsonData, int iUserId);
    }
}

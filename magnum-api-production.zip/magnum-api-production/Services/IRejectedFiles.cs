﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface IRejectedFiles
    {
        IEnumerable<RejectedFiles> GetRejectedData(RejectedFileSearch objInput);
    }
}

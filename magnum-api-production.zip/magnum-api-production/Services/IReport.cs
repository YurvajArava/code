﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IReport
    {
        IList<MonthlyReport> GetMonthlyReportData(MonthlyRptSearchModel objInput);
        IList<WeeklyReport> GetWeeklyReportDataOutstanding(WeeklyRptSearchModel objInput);
        IList<WeeklyReport> GetWeeklyReportData(WeeklyRptSearchModel objInput);
        IList<CompensationReport> CompensationReport(CompSearch objInput);
    }
}

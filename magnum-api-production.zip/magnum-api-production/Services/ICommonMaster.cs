﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface ICommonMaster
    {
        IEnumerable<CommonMaster> GetCommonMaster();
        CommonMaster GetCommonMasterById(int id);
        CommonMaster AddCommonMaster(CommonMaster commonMaster);
        CommonMaster UpdateCommonMaster(CommonMaster commonMaster);
        CommonMaster DeleteCommonMaster(CommonMaster commonMaster);

    }
}

﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IGasWorkflow
    {
        IEnumerable<GasworkflowModel> GetGasData(GasSearchCriteria model);
        //IEnumerable<GasworkflowModel> SearchStaggingRecords(string mpxn, string sdate, string edate);
        //Status UpdatewfgData(List<GasWorkFlowUpdateModel> data);
        Status UpdateStageCode(List<GasWorkFlowUpdateModel> data);

        Status GetExcelDataCount();
        IEnumerable<GasworkflowModel> GenerateDataforOps(string RefIds, int UserId);
        //IEnumerable<GasworkflowModel> GetRetData();
        RETData GenerateRetData();
        Status UpdateRetData(string RefIds, string fileName, string strType, int UserId);
    }
}

﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IGSOP
    {
        IEnumerable<GSOPStandardAone> GetGSOPAoneData(GSOPA1Search objInput);
        int UpdateCompensationDetail(CompensationDetail objInput);
        CompensationDetail GetCompensationDetail(long RefId, string CompType);
        Status ImportGsopData(GsopStandardAUpdateViewModel objInput);
        IEnumerable<GSOPStandardB> GetGSOPBData(GsopBSearch objInput);

        IEnumerable<GSOPStandardBD> GetGSOPBDData(GsopBDSearch objInput);

        public string UploadGSOPRecords(List<GSOPStandardAone> data);
        string UpdateGSOPRecords(List<CompensationDetail> data, int userid);
        string UpdateGSOPA1Records(List<CompensationDetail> data, int userid);
    }
}

﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IReasonMaster
    {
        IEnumerable<ReasonMaster> GetReasonMaster();
        ReasonMaster GetReasonMasterById(int id);
        ReasonMaster AddReasonMaster(ReasonMaster reasonMaster);
        ReasonMaster UpdateReasonMaster(ReasonMaster reasonMaster);
        ReasonMaster DeleteReasonMaster(ReasonMaster reasonMaster);
    }
}

﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IUserRoleMap
    {
        IEnumerable<UserRoleMap> GetAllFunction(int Id, int UserId);
        string UpdateUserRoleMap(int RoleID, List<UserRoleMap> UserRoleMap);
        IEnumerable<UserRoleMap> GetAllFunction(int Id);
    }
}


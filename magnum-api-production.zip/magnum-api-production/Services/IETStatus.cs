﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IETStatus
    {
        List<ETStatusModel> GetAllETStatus();
        ETStatusModel GetETStatusById(int Id);
        ETStatusModel AddETStatus(ETStatusModel eTStatusModel);
        ETStatusModel UpdateETStatus(ETStatusModel eTStatusModel);

    }
}

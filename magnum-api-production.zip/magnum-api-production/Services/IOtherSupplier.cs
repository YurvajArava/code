﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IOtherSupplier
    {
        IEnumerable<OtherSupplier> GetOtherSupplier();
        OtherSupplier GetOtherSupplierById(int Id);
        OtherSupplier AddOtherSupplier(OtherSupplier otherSupplier);
        OtherSupplier UpdateOtherSupplier(OtherSupplier otherSupplier);
        OtherSupplier DeleteOtherSupplier(OtherSupplier otherSupplier);
    }
}

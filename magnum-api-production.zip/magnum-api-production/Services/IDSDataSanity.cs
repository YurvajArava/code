﻿using EXLETAPI.Models;
using System.Collections.Generic;
namespace EXLETAPI.Services
{
    public interface IDSDataSanity
    {
        IEnumerable<DataSanityModel> GetStaggingRecords();
        IEnumerable<DataSanityModel> SearchStaggingRecords(string mpxn, string sdate, string edate);
        //DataSanityModel GetRecordsByMPXN(int Id);
        string UpdateStaggingRecords(List<DataSanityUpdate> data, int UserId);
        //DataSanityModel UpdateStaggingRecords(DataSanityModel dSDataSanity);
        string DeleteStaggingRecords(List<DataSanityUpdate> data, int UserId);
        IEnumerable<SapAction> SapActionRecords();
        string UpdateSapData(List<SapActionUpdate> data);
        IEnumerable<DcfEmail> DcfEmailRecords();
        TodayCount TodayRecords();
        //IEnumerable<DataSanityModel> GetCreateFileRecords();
        IEnumerable<DataSanityModel> GetCreateFileRecords(string sdate, string edate);

    }
}

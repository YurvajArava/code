﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IRoles
    {
        IEnumerable<Roles> GetAllRoles();
        string AddRoles(Roles tbl_Roles);
        string UpdateRoles(Roles tbl_Roles);
        string DeleteRoles(int RoleId);
    }
}

﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IOpsTask
    {
        IList<OpsTask> SearchRecords(OpsTaskSearch objInput);
        OpsTask GetByMPRN(long iRefId, int iEnergySupplyId, int iUserId);
        Status OpsTaskUpdateETData(string jsonData, int iUserId, int iEnergyId);
    }
}

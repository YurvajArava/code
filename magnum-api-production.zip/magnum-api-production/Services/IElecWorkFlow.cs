﻿using EXLETAPI.Models;
using System.Collections.Generic;

namespace EXLETAPI.Services
{
    public interface IElecWorkFlow
    {
        IEnumerable<ElecticityWorkFlowModel> GetElecData(ElecSearchCriteria objInput);
        string UpdateElecticityWorkFlow(List<ElectircityWorkFlowUpdate> data);

    }
}
